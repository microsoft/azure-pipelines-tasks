"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
describe('AzureWebAppV1 Suite', function () {
    before(() => {
    });
    after(() => {
    });
    it('Does a basic hello world test', function (done) {
        // TODO - add real tests
        done();
    });
});

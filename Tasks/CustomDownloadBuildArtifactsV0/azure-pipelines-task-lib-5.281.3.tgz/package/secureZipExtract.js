"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SecureZipExtractor = exports.extractZipSecure = void 0;
var events = require("events");
var fs = require("fs");
var path = require("path");
var stream = require("stream");
var util = require("util");
var im = require("./internal");
var secureZipCommon_1 = require("./secureZipCommon");
var MAX_SYMLINK_TARGET_BYTES = 4096;
var S_IFMT = 0xF000;
// O_NOFOLLOW makes the open fail if the final path component is a symlink, closing the
// window between the lstat check and the open. It does not exist on Windows.
var NO_FOLLOW_FLAG = fs.constants.O_NOFOLLOW || 0;
var WRITE_FLAGS = fs.constants.O_WRONLY | fs.constants.O_CREAT | fs.constants.O_TRUNC | NO_FOLLOW_FLAG;
var pipeline = util.promisify(stream.pipeline);
function getEntryPath(root, entryName) {
    var entryPath = path.resolve.apply(path, __spreadArray([root], entryName.split('/'), false));
    if (!(0, secureZipCommon_1.isWithinDirectory)(root, entryPath)) {
        throw new Error(im._loc('LIB_ArchiveEntryOutsideDestination', entryName));
    }
    return entryPath;
}
function ensureExistingAncestorIsSafe(root, candidate) {
    return __awaiter(this, void 0, void 0, function () {
        var existingPath, realPath, error_1, parentPath;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    existingPath = candidate;
                    _a.label = 1;
                case 1:
                    if (!true) return [3 /*break*/, 6];
                    _a.label = 2;
                case 2:
                    _a.trys.push([2, 4, , 5]);
                    return [4 /*yield*/, fs.promises.realpath(existingPath)];
                case 3:
                    realPath = _a.sent();
                    if (!(0, secureZipCommon_1.isWithinDirectory)(root, realPath)) {
                        throw new Error(im._loc('LIB_ArchivePathOutsideDestination', candidate));
                    }
                    return [2 /*return*/];
                case 4:
                    error_1 = _a.sent();
                    if (error_1.code !== 'ENOENT') {
                        throw error_1;
                    }
                    parentPath = path.dirname(existingPath);
                    if (parentPath === existingPath) {
                        throw error_1;
                    }
                    existingPath = parentPath;
                    return [3 /*break*/, 5];
                case 5: return [3 /*break*/, 1];
                case 6: return [2 /*return*/];
            }
        });
    });
}
function ensureSafeDirectory(root, directoryPath, mode) {
    return __awaiter(this, void 0, void 0, function () {
        var realDirectoryPath;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, ensureExistingAncestorIsSafe(root, directoryPath)];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, fs.promises.mkdir(directoryPath, { recursive: true, mode: mode })];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, fs.promises.realpath(directoryPath)];
                case 3:
                    realDirectoryPath = _a.sent();
                    if (!(0, secureZipCommon_1.isWithinDirectory)(root, realDirectoryPath)) {
                        throw new Error(im._loc('LIB_ArchiveDirectoryOutsideDestination', directoryPath));
                    }
                    return [2 /*return*/];
            }
        });
    });
}
function ensureDestinationIsNotSymlink(entryPath) {
    return __awaiter(this, void 0, void 0, function () {
        var stats, error_2;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, fs.promises.lstat(entryPath)];
                case 1:
                    stats = _a.sent();
                    if (stats.isSymbolicLink()) {
                        throw new Error(im._loc('LIB_ArchiveEntryWouldOverwriteSymlink', entryPath));
                    }
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    if (error_2.code !== 'ENOENT') {
                        throw error_2;
                    }
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    });
}
function getUnixMode(entry) {
    return (entry.externalFileAttributes >>> 16) & 0xFFFF;
}
function isDirectory(entry) {
    return (getUnixMode(entry) & S_IFMT) === secureZipCommon_1.S_IFDIR || entry.fileName.endsWith('/') ||
        ((entry.versionMadeBy >>> 8) === 0 && entry.externalFileAttributes === 16);
}
function isSymbolicLink(entry) {
    return (getUnixMode(entry) & S_IFMT) === secureZipCommon_1.S_IFLNK;
}
function getMode(entry, directory, options) {
    var entryMode = getUnixMode(entry) & 511;
    if (entryMode) {
        return entryMode;
    }
    var defaultMode = directory ? options.defaultDirMode : options.defaultFileMode;
    var fallbackMode = directory ? 493 : 420;
    return (defaultMode === undefined || defaultMode === null ? fallbackMode : Number(defaultMode)) & 511;
}
function readSymlinkTarget(zipFile, entry) {
    var _a, e_1, _b, _c;
    return __awaiter(this, void 0, void 0, function () {
        var readStream, chunks, size, _d, readStream_1, readStream_1_1, chunk, bytes, e_1_1;
        return __generator(this, function (_e) {
            switch (_e.label) {
                case 0:
                    // A symlink target is a path, so anything beyond PATH_MAX-ish sizes is hostile.
                    if (entry.uncompressedSize > MAX_SYMLINK_TARGET_BYTES) {
                        throw new Error(im._loc('LIB_ArchiveSymlinkTargetTooLarge', entry.fileName));
                    }
                    return [4 /*yield*/, zipFile.openReadStreamPromise(entry)];
                case 1:
                    readStream = _e.sent();
                    chunks = [];
                    size = 0;
                    _e.label = 2;
                case 2:
                    _e.trys.push([2, 7, 8, 13]);
                    _d = true, readStream_1 = __asyncValues(readStream);
                    _e.label = 3;
                case 3: return [4 /*yield*/, readStream_1.next()];
                case 4:
                    if (!(readStream_1_1 = _e.sent(), _a = readStream_1_1.done, !_a)) return [3 /*break*/, 6];
                    _c = readStream_1_1.value;
                    _d = false;
                    try {
                        chunk = _c;
                        bytes = Uint8Array.from(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
                        size += bytes.length;
                        if (size > MAX_SYMLINK_TARGET_BYTES) {
                            throw new Error(im._loc('LIB_ArchiveSymlinkTargetTooLarge', entry.fileName));
                        }
                        chunks.push(bytes);
                    }
                    finally {
                        _d = true;
                    }
                    _e.label = 5;
                case 5: return [3 /*break*/, 3];
                case 6: return [3 /*break*/, 13];
                case 7:
                    e_1_1 = _e.sent();
                    e_1 = { error: e_1_1 };
                    return [3 /*break*/, 13];
                case 8:
                    _e.trys.push([8, , 11, 12]);
                    if (!(!_d && !_a && (_b = readStream_1.return))) return [3 /*break*/, 10];
                    return [4 /*yield*/, _b.call(readStream_1)];
                case 9:
                    _e.sent();
                    _e.label = 10;
                case 10: return [3 /*break*/, 12];
                case 11:
                    if (e_1) throw e_1.error;
                    return [7 /*endfinally*/];
                case 12: return [7 /*endfinally*/];
                case 13: return [2 /*return*/, Buffer.concat(chunks).toString()];
            }
        });
    });
}
function extractSymlink(zipFile, root, entry, destinationPath) {
    return __awaiter(this, void 0, void 0, function () {
        var linkTarget, normalizedTarget, resolvedTarget;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, readSymlinkTarget(zipFile, entry)];
                case 1:
                    linkTarget = _a.sent();
                    if (path.posix.isAbsolute(linkTarget) || path.win32.isAbsolute(linkTarget)) {
                        throw new Error(im._loc('LIB_ArchiveSymlinkAbsoluteTarget', entry.fileName));
                    }
                    normalizedTarget = linkTarget.replace(/\\/g, '/');
                    resolvedTarget = path.resolve.apply(path, __spreadArray([path.dirname(destinationPath)], normalizedTarget.split('/'), false));
                    if (!(0, secureZipCommon_1.isWithinDirectory)(root, resolvedTarget)) {
                        throw new Error(im._loc('LIB_ArchiveSymlinkTargetOutsideDestination', entry.fileName));
                    }
                    return [4 /*yield*/, ensureExistingAncestorIsSafe(root, resolvedTarget)];
                case 2:
                    _a.sent();
                    return [4 /*yield*/, ensureDestinationIsNotSymlink(destinationPath)];
                case 3:
                    _a.sent();
                    return [4 /*yield*/, fs.promises.symlink(linkTarget, destinationPath)];
                case 4:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function extractFile(zipFile, entry, destinationPath, mode) {
    return __awaiter(this, void 0, void 0, function () {
        var readStream, writeStream, error_3;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, ensureDestinationIsNotSymlink(destinationPath)];
                case 1:
                    _a.sent();
                    return [4 /*yield*/, zipFile.openReadStreamPromise(entry)];
                case 2:
                    readStream = _a.sent();
                    _a.label = 3;
                case 3:
                    _a.trys.push([3, 5, , 6]);
                    writeStream = fs.createWriteStream(destinationPath, { flags: WRITE_FLAGS, mode: mode });
                    return [4 /*yield*/, pipeline(readStream, writeStream)];
                case 4:
                    _a.sent();
                    return [3 /*break*/, 6];
                case 5:
                    error_3 = _a.sent();
                    if (error_3.code === 'ELOOP') {
                        throw new Error(im._loc('LIB_ArchiveEntryWouldOverwriteSymlink', destinationPath));
                    }
                    throw error_3;
                case 6: return [2 /*return*/];
            }
        });
    });
}
function extractEntry(zipFile, root, entry, options) {
    return __awaiter(this, void 0, void 0, function () {
        var destinationPath, directory;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    destinationPath = getEntryPath(root, entry.fileName);
                    directory = isDirectory(entry);
                    if (!directory) return [3 /*break*/, 2];
                    return [4 /*yield*/, ensureSafeDirectory(root, destinationPath, getMode(entry, true, options))];
                case 1:
                    _a.sent();
                    return [2 /*return*/];
                case 2: return [4 /*yield*/, ensureSafeDirectory(root, path.dirname(destinationPath))];
                case 3:
                    _a.sent();
                    if (!isSymbolicLink(entry)) return [3 /*break*/, 5];
                    return [4 /*yield*/, extractSymlink(zipFile, root, entry, destinationPath)];
                case 4:
                    _a.sent();
                    return [2 /*return*/];
                case 5: return [4 /*yield*/, extractFile(zipFile, entry, destinationPath, getMode(entry, false, options))];
                case 6:
                    _a.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function isMacOSMetadataEntry(entry) {
    return entry.fileName.startsWith('__MACOSX/');
}
/**
 * Securely extracts a ZIP archive. Drop-in replacement for the extract-zip package:
 *
 *     await extractZipSecure(zipPath, { dir: '/absolute/target' });
 *
 * A plain destination string is also accepted. The archive is detected by content rather than
 * by file extension, so any ZIP container (.zip, .nupkg, .vsix, .jar, ...) can be extracted.
 * Entries can neither escape the destination through '..' segments nor through symbolic links.
 *
 * @param file                  path of the ZIP archive
 * @param destinationOrOptions  absolute destination directory, or extraction options
 * @returns                     canonical (symlink-resolved) path of the destination directory
 */
function extractZipSecure(file, destinationOrOptions) {
    var _a, e_2, _b, _c;
    return __awaiter(this, void 0, void 0, function () {
        var options, root, yauzl, zipFile, entryCount, totalSize, _d, _e, _f, entry, e_2_1;
        return __generator(this, function (_g) {
            switch (_g.label) {
                case 0:
                    (0, secureZipCommon_1.assertSupportedNode)();
                    options = typeof destinationOrOptions === 'string'
                        ? { dir: destinationOrOptions }
                        : (destinationOrOptions || {});
                    if (!file) {
                        throw new Error(im._loc('LIB_ArchiveFileRequired'));
                    }
                    if (!options.dir || !path.isAbsolute(options.dir)) {
                        throw new Error(im._loc('LIB_ArchiveDestinationAbsolute'));
                    }
                    return [4 /*yield*/, fs.promises.mkdir(options.dir, { recursive: true })];
                case 1:
                    _g.sent();
                    return [4 /*yield*/, fs.promises.realpath(options.dir)];
                case 2:
                    root = _g.sent();
                    yauzl = require('yauzl');
                    return [4 /*yield*/, yauzl.openPromise(file, { lazyEntries: true })];
                case 3:
                    zipFile = _g.sent();
                    entryCount = 0;
                    totalSize = 0;
                    _g.label = 4;
                case 4:
                    _g.trys.push([4, , 22, 23]);
                    _g.label = 5;
                case 5:
                    _g.trys.push([5, 15, 16, 21]);
                    _d = true, _e = __asyncValues(zipFile.eachEntry());
                    _g.label = 6;
                case 6: return [4 /*yield*/, _e.next()];
                case 7:
                    if (!(_f = _g.sent(), _a = _f.done, !_a)) return [3 /*break*/, 14];
                    _c = _f.value;
                    _d = false;
                    _g.label = 8;
                case 8:
                    _g.trys.push([8, , 12, 13]);
                    entry = _c;
                    if (isMacOSMetadataEntry(entry)) {
                        return [3 /*break*/, 13];
                    }
                    entryCount++;
                    if (options.maxEntries !== undefined && entryCount > options.maxEntries) {
                        throw new Error(im._loc('LIB_ArchiveTooManyEntries', options.maxEntries));
                    }
                    totalSize += entry.uncompressedSize;
                    if (options.maxTotalSize !== undefined && totalSize > options.maxTotalSize) {
                        throw new Error(im._loc('LIB_ArchiveTooLarge', options.maxTotalSize));
                    }
                    if (!options.onEntry) return [3 /*break*/, 10];
                    return [4 /*yield*/, options.onEntry(entry, zipFile)];
                case 9:
                    _g.sent();
                    _g.label = 10;
                case 10: return [4 /*yield*/, extractEntry(zipFile, root, entry, options)];
                case 11:
                    _g.sent();
                    return [3 /*break*/, 13];
                case 12:
                    _d = true;
                    return [7 /*endfinally*/];
                case 13: return [3 /*break*/, 6];
                case 14: return [3 /*break*/, 21];
                case 15:
                    e_2_1 = _g.sent();
                    e_2 = { error: e_2_1 };
                    return [3 /*break*/, 21];
                case 16:
                    _g.trys.push([16, , 19, 20]);
                    if (!(!_d && !_a && (_b = _e.return))) return [3 /*break*/, 18];
                    return [4 /*yield*/, _b.call(_e)];
                case 17:
                    _g.sent();
                    _g.label = 18;
                case 18: return [3 /*break*/, 20];
                case 19:
                    if (e_2) throw e_2.error;
                    return [7 /*endfinally*/];
                case 20: return [7 /*endfinally*/];
                case 21: return [3 /*break*/, 23];
                case 22:
                    zipFile.close();
                    return [7 /*endfinally*/];
                case 23: return [2 /*return*/, root];
            }
        });
    });
}
exports.extractZipSecure = extractZipSecure;
/**
 * Event based wrapper over extractZipSecure for code written against decompress-zip:
 *
 *     const unzipper = new SecureZipExtractor(zipPath);
 *     unzipper.on('error', reject);
 *     unzipper.on('extract', log => resolve());
 *     unzipper.extract({ path: targetDirectory });
 *
 * Emits 'extract' with the list of extracted entries on success, or 'error' on failure.
 */
var SecureZipExtractor = /** @class */ (function (_super) {
    __extends(SecureZipExtractor, _super);
    function SecureZipExtractor(file) {
        var _this = _super.call(this) || this;
        _this._file = file;
        return _this;
    }
    SecureZipExtractor.prototype.extract = function (options) {
        var _this = this;
        var log = [];
        extractZipSecure(this._file, {
            dir: options && options.path,
            onEntry: function (entry) {
                log.push({
                    path: entry.fileName,
                    type: isSymbolicLink(entry) ? 'symlink' : (isDirectory(entry) ? 'directory' : 'file')
                });
            }
        }).then(function () { _this.emit('extract', log); }, function (error) { _this.emit('error', error); });
    };
    return SecureZipExtractor;
}(events.EventEmitter));
exports.SecureZipExtractor = SecureZipExtractor;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertSupportedNode = exports.isWithinDirectory = exports.S_IFLNK = exports.S_IFDIR = void 0;
var path = require("path");
var im = require("./internal");
var MIN_NODE_MAJOR = 12;
exports.S_IFDIR = 0x4000;
exports.S_IFLNK = 0xA000;
function isWithinDirectory(root, candidate) {
    var relativePath = path.relative(root, candidate);
    return relativePath === '' ||
        (!path.isAbsolute(relativePath) && relativePath.split(path.sep).indexOf('..') < 0);
}
exports.isWithinDirectory = isWithinDirectory;
function assertSupportedNode() {
    if (parseInt(process.versions.node.split('.')[0], 10) < MIN_NODE_MAJOR) {
        throw new Error(im._loc('LIB_ArchiveUnsupportedNode', process.versions.node));
    }
}
exports.assertSupportedNode = assertSupportedNode;

/// <reference types="node" />
/// <reference types="node" />
/** Decides whether a local file or folder is added. Receives the path relative to the source folder, using '/' separators. */
export type ZipEntryFilter = (relativePath: string, isDirectory: boolean) => boolean;
/** How symbolic links found while adding a local folder are handled. */
export type ZipSymlinkMode = 'preserve' | 'skip';
export interface ZipArchiveOptions {
    /**
     * 'preserve' (default) stores symbolic links as links, 'skip' leaves them out. Links are never
     * followed, so content outside the source folder cannot be added by accident. A link with an
     * absolute target, or a target outside the source folder, fails the operation.
     */
    symlinks?: ZipSymlinkMode;
}
export interface AddFileOptions {
    /** Unix permission bits. Defaults to 0o644. */
    mode?: number;
    /** Last modification time. Defaults to now. */
    mtime?: Date;
}
export interface CreateZipOptions extends ZipArchiveOptions {
    /** Folder inside the archive that receives the contents of the source folder. Defaults to the archive root. */
    zipPath?: string;
    /** Excludes files and folders. Excluding a folder excludes everything below it. */
    filter?: ZipEntryFilter;
}
/**
 * Builds a ZIP archive from files, buffers and local folders. Replacement for the archive creating
 * part of adm-zip (addFile, addLocalFile, addLocalFolder, writeZip, toBuffer). Entries are collected
 * first and written together, so adding an entry name twice keeps the last one. All operations that
 * touch the file system are asynchronous. Archives and entries larger than 4 GiB are not supported.
 *
 *     const archive = new SecureZipArchive();
 *     await archive.addLocalFolder(contentsDirectory);
 *     await archive.writeZip(zipFile);
 */
export declare class SecureZipArchive {
    private _entries;
    private _symlinks;
    constructor(options?: ZipArchiveOptions);
    /**
     * Adds a file whose content is held in memory.
     *
     * @param entryName  path of the file inside the archive
     * @param data       file content
     * @param options    optional permissions and modification time
     */
    addFile(entryName: string, data: Buffer | string, options?: AddFileOptions): void;
    /**
     * Adds a file from disk.
     *
     * @param localPath  path of the file
     * @param zipPath    folder inside the archive. Defaults to the archive root.
     * @param zipName    name inside the archive. Defaults to the name of the file.
     */
    addLocalFile(localPath: string, zipPath?: string, zipName?: string): Promise<void>;
    /**
     * Adds the contents of a folder recursively, including empty folders.
     *
     * @param localPath  path of the folder
     * @param zipPath    folder inside the archive. Defaults to the archive root.
     * @param filter     optional filter deciding which files and folders are added
     */
    addLocalFolder(localPath: string, zipPath?: string, filter?: ZipEntryFilter): Promise<void>;
    /**
     * Writes the archive to a file. The archive is written to a temporary file next to the target
     * and then moved into place, so a failure never leaves a partial archive behind.
     *
     * @param targetFile  path of the zip file to create or replace
     * @returns           absolute path of the zip file
     */
    writeZip(targetFile: string): Promise<string>;
    /** Returns the archive as a buffer. Prefer writeZip for large archives. */
    toBuffer(): Promise<Buffer>;
    private _getPermissions;
    private _addSourceFile;
    private _addFolder;
    private _addSymlink;
    private _assertTargetIsNotAnEntry;
}
/**
 * Creates a ZIP archive from the contents of a folder. Replacement for the common adm-zip sequence
 * addLocalFolder followed by writeZip:
 *
 *     await createZipSecure(contentsDirectory, zipFile);
 *
 * @param sourceDirectory  folder whose contents are archived
 * @param destinationZip   path of the zip file to create or replace. It must not be inside the archived contents.
 * @param options          optional archive folder, filter and symbolic link handling
 * @returns                absolute path of the zip file
 */
export declare function createZipSecure(sourceDirectory: string, destinationZip: string, options?: CreateZipOptions): Promise<string>;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createZipSecure = exports.SecureZipArchive = void 0;
var crypto = require("crypto");
var fs = require("fs");
var path = require("path");
var stream = require("stream");
var util = require("util");
var zlib = require("zlib");
var im = require("./internal");
var secureZipCommon_1 = require("./secureZipCommon");
var S_IFREG = 0x8000;
var pipeline = util.promisify(stream.pipeline);
var ZIP_UTF8_FLAG = 0x0800;
var ZIP_DESCRIPTOR_FLAG = 0x0008;
var ZIP_METHOD_STORE = 0;
var ZIP_METHOD_DEFLATE = 8;
var ZIP_VERSION_UNIX = 3 << 8;
// Entries and offsets are written in the classic 32 bit format. Only the entry count can exceed
// its classic limit, which the ZIP64 end of central directory records cover.
var ZIP_MAX_SIZE = 0xFFFFFFFE;
var ZIP_MAX_CLASSIC_ENTRIES = 0xFFFE;
var ZIP_WRITE_BLOCK_SIZE = 64 * 1024;
var crcTable;
function updateCrc32(crc, data) {
    var native = zlib.crc32;
    if (native) {
        return native(data, crc);
    }
    if (!crcTable) {
        crcTable = new Uint32Array(256);
        for (var index = 0; index < 256; index++) {
            var value = index;
            for (var bit = 0; bit < 8; bit++) {
                value = (value & 1) ? (0xEDB88320 ^ (value >>> 1)) : (value >>> 1);
            }
            crcTable[index] = value >>> 0;
        }
    }
    var result = (crc ^ 0xFFFFFFFF) >>> 0;
    for (var index = 0; index < data.length; index++) {
        result = crcTable[(result ^ data[index]) & 0xFF] ^ (result >>> 8);
    }
    return (result ^ 0xFFFFFFFF) >>> 0;
}
function toDosDateTime(value) {
    var year = value.getFullYear();
    // The DOS format only covers 1980 through 2107.
    if (isNaN(value.getTime()) || year < 1980) {
        return { time: 0, date: 0x21 };
    }
    if (year > 2107) {
        return { time: 0xBF7D, date: 0xFF9F };
    }
    return {
        time: (value.getHours() << 11) | (value.getMinutes() << 5) | (value.getSeconds() >> 1),
        date: ((year - 1980) << 9) | ((value.getMonth() + 1) << 5) | value.getDate()
    };
}
function writeUInt64LE(buffer, value, offset) {
    buffer.writeUInt32LE(value % 0x100000000, offset);
    buffer.writeUInt32LE(Math.floor(value / 0x100000000), offset + 4);
}
function createZipRecord(name, entry, offset) {
    var nameBuffer = Buffer.from(name, 'utf8');
    if (nameBuffer.length > 0xFFFF) {
        throw new Error(im._loc('LIB_ArchiveEntryNameInvalid', name));
    }
    var dos = toDosDateTime(entry.mtime);
    return {
        compressedSize: 0,
        crc: 0,
        date: dos.date,
        flags: ZIP_UTF8_FLAG,
        method: ZIP_METHOD_STORE,
        mode: entry.mode,
        name: nameBuffer,
        offset: offset,
        time: dos.time,
        uncompressedSize: 0
    };
}
function buildLocalHeader(record) {
    var header = Buffer.alloc(30 + record.name.length);
    header.writeUInt32LE(0x04034b50, 0);
    header.writeUInt16LE(20, 4);
    header.writeUInt16LE(record.flags, 6);
    header.writeUInt16LE(record.method, 8);
    header.writeUInt16LE(record.time, 10);
    header.writeUInt16LE(record.date, 12);
    header.writeUInt32LE(record.crc, 14);
    header.writeUInt32LE(record.compressedSize, 18);
    header.writeUInt32LE(record.uncompressedSize, 22);
    header.writeUInt16LE(record.name.length, 26);
    header.writeUInt16LE(0, 28);
    record.name.copy(header, 30);
    return header;
}
function buildDataDescriptor(record) {
    var descriptor = Buffer.alloc(16);
    descriptor.writeUInt32LE(0x08074b50, 0);
    descriptor.writeUInt32LE(record.crc, 4);
    descriptor.writeUInt32LE(record.compressedSize, 8);
    descriptor.writeUInt32LE(record.uncompressedSize, 12);
    return descriptor;
}
function buildCentralHeader(record) {
    var header = Buffer.alloc(46 + record.name.length);
    header.writeUInt32LE(0x02014b50, 0);
    header.writeUInt16LE(ZIP_VERSION_UNIX | 20, 4);
    header.writeUInt16LE(20, 6);
    header.writeUInt16LE(record.flags, 8);
    header.writeUInt16LE(record.method, 10);
    header.writeUInt16LE(record.time, 12);
    header.writeUInt16LE(record.date, 14);
    header.writeUInt32LE(record.crc, 16);
    header.writeUInt32LE(record.compressedSize, 20);
    header.writeUInt32LE(record.uncompressedSize, 24);
    header.writeUInt16LE(record.name.length, 28);
    header.writeUInt32LE((record.mode << 16) >>> 0, 38);
    header.writeUInt32LE(record.offset, 42);
    record.name.copy(header, 46);
    return header;
}
function buildEndRecords(entryCount, centralSize, centralOffset) {
    var zip64 = entryCount > ZIP_MAX_CLASSIC_ENTRIES;
    var parts = [];
    if (zip64) {
        var record = Buffer.alloc(56);
        record.writeUInt32LE(0x06064b50, 0);
        writeUInt64LE(record, 44, 4);
        record.writeUInt16LE(ZIP_VERSION_UNIX | 45, 12);
        record.writeUInt16LE(45, 14);
        writeUInt64LE(record, entryCount, 24);
        writeUInt64LE(record, entryCount, 32);
        writeUInt64LE(record, centralSize, 40);
        writeUInt64LE(record, centralOffset, 48);
        var locator = Buffer.alloc(20);
        locator.writeUInt32LE(0x07064b50, 0);
        writeUInt64LE(locator, centralOffset + centralSize, 8);
        locator.writeUInt32LE(1, 16);
        parts.push(record, locator);
    }
    var end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(zip64 ? 0xFFFF : entryCount, 8);
    end.writeUInt16LE(zip64 ? 0xFFFF : entryCount, 10);
    end.writeUInt32LE(centralSize, 12);
    end.writeUInt32LE(centralOffset, 16);
    parts.push(end);
    return Buffer.concat(parts);
}
// Entries whose content is held in memory know their checksum and sizes before the header is written.
function prepareInMemoryEntry(record, entry) {
    var data = entry.data || Buffer.alloc(0);
    var compress = entry.kind === 'buffer' && data.length > 0;
    var payload = compress ? zlib.deflateRawSync(data) : data;
    record.crc = updateCrc32(0, data);
    record.method = compress ? ZIP_METHOD_DEFLATE : ZIP_METHOD_STORE;
    record.compressedSize = payload.length;
    record.uncompressedSize = data.length;
    return payload;
}
// Files are streamed, so their checksum and sizes are only known afterwards and go into a data descriptor.
function writeFileContent(sourcePath, record, write) {
    return __awaiter(this, void 0, void 0, function () {
        var crc, compressedSize, uncompressedSize, measure, sink;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    crc = 0;
                    compressedSize = 0;
                    uncompressedSize = 0;
                    measure = new stream.Transform({
                        transform: function (chunk, encoding, callback) {
                            crc = updateCrc32(crc, chunk);
                            uncompressedSize += chunk.length;
                            callback(uncompressedSize > ZIP_MAX_SIZE ? new Error(im._loc('LIB_ArchiveZip64Unsupported')) : null, chunk);
                        }
                    });
                    sink = new stream.Writable({
                        write: function (chunk, encoding, callback) {
                            compressedSize += chunk.length;
                            write(chunk).then(function () { return callback(); }, callback);
                        }
                    });
                    return [4 /*yield*/, pipeline(fs.createReadStream(sourcePath), measure, zlib.createDeflateRaw(), sink)];
                case 1:
                    _a.sent();
                    record.crc = crc;
                    record.compressedSize = compressedSize;
                    record.uncompressedSize = uncompressedSize;
                    return [2 /*return*/];
            }
        });
    });
}
function writeZipArchive(entries, write) {
    return __awaiter(this, void 0, void 0, function () {
        var offset, pending, pendingSize, flush, emit, records, _i, _a, name_1, entry, record, payload, centralOffset, _b, records_1, record;
        var _this = this;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    offset = 0;
                    pending = [];
                    pendingSize = 0;
                    flush = function () { return __awaiter(_this, void 0, void 0, function () {
                        var block;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (!(pendingSize > 0)) return [3 /*break*/, 2];
                                    block = Buffer.concat(pending);
                                    pending = [];
                                    pendingSize = 0;
                                    return [4 /*yield*/, write(block)];
                                case 1:
                                    _a.sent();
                                    _a.label = 2;
                                case 2: return [2 /*return*/];
                            }
                        });
                    }); };
                    emit = function (chunk) { return __awaiter(_this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    offset += chunk.length;
                                    if (offset > ZIP_MAX_SIZE) {
                                        throw new Error(im._loc('LIB_ArchiveZip64Unsupported'));
                                    }
                                    pending.push(chunk);
                                    pendingSize += chunk.length;
                                    if (!(pendingSize >= ZIP_WRITE_BLOCK_SIZE)) return [3 /*break*/, 2];
                                    return [4 /*yield*/, flush()];
                                case 1:
                                    _a.sent();
                                    _a.label = 2;
                                case 2: return [2 /*return*/];
                            }
                        });
                    }); };
                    records = [];
                    _i = 0, _a = Array.from(entries.keys()).sort();
                    _c.label = 1;
                case 1:
                    if (!(_i < _a.length)) return [3 /*break*/, 10];
                    name_1 = _a[_i];
                    entry = entries.get(name_1);
                    record = createZipRecord(name_1, entry, offset);
                    if (!(entry.kind === 'file')) return [3 /*break*/, 5];
                    record.flags |= ZIP_DESCRIPTOR_FLAG;
                    record.method = ZIP_METHOD_DEFLATE;
                    return [4 /*yield*/, emit(buildLocalHeader(record))];
                case 2:
                    _c.sent();
                    return [4 /*yield*/, writeFileContent(entry.sourcePath, record, emit)];
                case 3:
                    _c.sent();
                    return [4 /*yield*/, emit(buildDataDescriptor(record))];
                case 4:
                    _c.sent();
                    return [3 /*break*/, 8];
                case 5:
                    payload = prepareInMemoryEntry(record, entry);
                    return [4 /*yield*/, emit(buildLocalHeader(record))];
                case 6:
                    _c.sent();
                    if (!(payload.length > 0)) return [3 /*break*/, 8];
                    return [4 /*yield*/, emit(payload)];
                case 7:
                    _c.sent();
                    _c.label = 8;
                case 8:
                    records.push(record);
                    _c.label = 9;
                case 9:
                    _i++;
                    return [3 /*break*/, 1];
                case 10:
                    centralOffset = offset;
                    _b = 0, records_1 = records;
                    _c.label = 11;
                case 11:
                    if (!(_b < records_1.length)) return [3 /*break*/, 14];
                    record = records_1[_b];
                    return [4 /*yield*/, emit(buildCentralHeader(record))];
                case 12:
                    _c.sent();
                    _c.label = 13;
                case 13:
                    _b++;
                    return [3 /*break*/, 11];
                case 14: return [4 /*yield*/, emit(buildEndRecords(records.length, offset - centralOffset, centralOffset))];
                case 15:
                    _c.sent();
                    return [4 /*yield*/, flush()];
                case 16:
                    _c.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function writeChunk(output, chunk) {
    return new Promise(function (resolve, reject) {
        output.write(chunk, function (error) { return error ? reject(error) : resolve(); });
    });
}
function compareByName(first, second) {
    return first.name < second.name ? -1 : (first.name > second.name ? 1 : 0);
}
/**
 * Normalizes a path inside an archive to '/' separators without leading, trailing or empty segments.
 * Returns an empty string for the archive root.
 */
function normalizeEntryName(name) {
    var segments = name.replace(/\\/g, '/').split('/').filter(function (segment) { return segment !== '' && segment !== '.'; });
    if (segments.some(function (segment) { return segment === '..'; }) || /^[A-Za-z]:$/.test(segments[0] || '')) {
        throw new Error(im._loc('LIB_ArchiveEntryNameInvalid', name));
    }
    return segments.join('/');
}
function toEntryName(zipPath, relativePath, directory) {
    var name = normalizeEntryName(zipPath ? zipPath + '/' + relativePath : relativePath);
    if (!name) {
        throw new Error(im._loc('LIB_ArchiveEntryNameInvalid', relativePath));
    }
    return directory ? name + '/' : name;
}
function statSource(sourcePath) {
    return __awaiter(this, void 0, void 0, function () {
        var error_1;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, fs.promises.stat(sourcePath)];
                case 1: return [2 /*return*/, _a.sent()];
                case 2:
                    error_1 = _a.sent();
                    if (error_1.code === 'ENOENT') {
                        throw new Error(im._loc('LIB_ArchiveSourceNotFound', sourcePath));
                    }
                    throw error_1;
                case 3: return [2 /*return*/];
            }
        });
    });
}
/**
 * Builds a ZIP archive from files, buffers and local folders. Replacement for the archive creating
 * part of adm-zip (addFile, addLocalFile, addLocalFolder, writeZip, toBuffer). Entries are collected
 * first and written together, so adding an entry name twice keeps the last one. All operations that
 * touch the file system are asynchronous. Archives and entries larger than 4 GiB are not supported.
 *
 *     const archive = new SecureZipArchive();
 *     await archive.addLocalFolder(contentsDirectory);
 *     await archive.writeZip(zipFile);
 */
var SecureZipArchive = /** @class */ (function () {
    function SecureZipArchive(options) {
        this._entries = new Map();
        (0, secureZipCommon_1.assertSupportedNode)();
        this._symlinks = (options && options.symlinks) || 'preserve';
    }
    /**
     * Adds a file whose content is held in memory.
     *
     * @param entryName  path of the file inside the archive
     * @param data       file content
     * @param options    optional permissions and modification time
     */
    SecureZipArchive.prototype.addFile = function (entryName, data, options) {
        var name = toEntryName('', entryName || '', false);
        this._entries.set(name, {
            kind: 'buffer',
            data: Buffer.isBuffer(data) ? data : Buffer.from(data || ''),
            mode: S_IFREG | this._getPermissions(options && options.mode, 420),
            mtime: (options && options.mtime) || new Date()
        });
    };
    /**
     * Adds a file from disk.
     *
     * @param localPath  path of the file
     * @param zipPath    folder inside the archive. Defaults to the archive root.
     * @param zipName    name inside the archive. Defaults to the name of the file.
     */
    SecureZipArchive.prototype.addLocalFile = function (localPath, zipPath, zipName) {
        return __awaiter(this, void 0, void 0, function () {
            var sourcePath, stats, name;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!localPath) {
                            throw new Error(im._loc('LIB_ParameterIsRequired', 'localPath'));
                        }
                        sourcePath = path.resolve(localPath);
                        return [4 /*yield*/, statSource(sourcePath)];
                    case 1:
                        stats = _a.sent();
                        if (!stats.isFile()) {
                            throw new Error(im._loc('LIB_ArchiveSourceNotFile', sourcePath));
                        }
                        name = toEntryName(normalizeEntryName(zipPath || ''), zipName || path.basename(sourcePath), false);
                        this._addSourceFile(name, sourcePath, stats);
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Adds the contents of a folder recursively, including empty folders.
     *
     * @param localPath  path of the folder
     * @param zipPath    folder inside the archive. Defaults to the archive root.
     * @param filter     optional filter deciding which files and folders are added
     */
    SecureZipArchive.prototype.addLocalFolder = function (localPath, zipPath, filter) {
        return __awaiter(this, void 0, void 0, function () {
            var root, stats;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!localPath) {
                            throw new Error(im._loc('LIB_ParameterIsRequired', 'localPath'));
                        }
                        root = path.resolve(localPath);
                        return [4 /*yield*/, statSource(root)];
                    case 1:
                        stats = _a.sent();
                        if (!stats.isDirectory()) {
                            throw new Error(im._loc('LIB_ArchiveSourceNotDirectory', root));
                        }
                        return [4 /*yield*/, this._addFolder(root, root, '', normalizeEntryName(zipPath || ''), filter)];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Writes the archive to a file. The archive is written to a temporary file next to the target
     * and then moved into place, so a failure never leaves a partial archive behind.
     *
     * @param targetFile  path of the zip file to create or replace
     * @returns           absolute path of the zip file
     */
    SecureZipArchive.prototype.writeZip = function (targetFile) {
        return __awaiter(this, void 0, void 0, function () {
            var target, temporaryFile, output, closed, error_2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!targetFile) {
                            throw new Error(im._loc('LIB_ParameterIsRequired', 'targetFile'));
                        }
                        target = path.resolve(targetFile);
                        this._assertTargetIsNotAnEntry(target);
                        return [4 /*yield*/, fs.promises.mkdir(path.dirname(target), { recursive: true })];
                    case 1:
                        _a.sent();
                        temporaryFile = target + '.' + crypto.randomBytes(6).toString('hex') + '.tmp';
                        output = fs.createWriteStream(temporaryFile, { flags: 'wx' });
                        closed = new Promise(function (resolve, reject) {
                            output.once('close', resolve);
                            output.once('error', reject);
                        });
                        // The promise is awaited later; this keeps an early stream error from surfacing as unhandled.
                        closed.catch(function () { return undefined; });
                        _a.label = 2;
                    case 2:
                        _a.trys.push([2, 6, , 9]);
                        return [4 /*yield*/, writeZipArchive(this._entries, function (chunk) { return writeChunk(output, chunk); })];
                    case 3:
                        _a.sent();
                        output.end();
                        return [4 /*yield*/, closed];
                    case 4:
                        _a.sent();
                        return [4 /*yield*/, fs.promises.rename(temporaryFile, target)];
                    case 5:
                        _a.sent();
                        im._debug("secure zip: Successfully wrote zip to ".concat(target));
                        return [3 /*break*/, 9];
                    case 6:
                        error_2 = _a.sent();
                        im._debug("secure zip: Failed to write zip to ".concat(target, ": ").concat(error_2));
                        output.destroy();
                        return [4 /*yield*/, closed.catch(function () { return undefined; })];
                    case 7:
                        _a.sent();
                        return [4 /*yield*/, fs.promises.unlink(temporaryFile).catch(function () { return undefined; })];
                    case 8:
                        _a.sent();
                        throw error_2;
                    case 9: return [2 /*return*/, target];
                }
            });
        });
    };
    /** Returns the archive as a buffer. Prefer writeZip for large archives. */
    SecureZipArchive.prototype.toBuffer = function () {
        return __awaiter(this, void 0, void 0, function () {
            var chunks;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        chunks = [];
                        return [4 /*yield*/, writeZipArchive(this._entries, function (chunk) {
                                chunks.push(chunk);
                                return Promise.resolve();
                            })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/, Buffer.concat(chunks)];
                }
            });
        });
    };
    SecureZipArchive.prototype._getPermissions = function (mode, fallback) {
        return mode === undefined || mode === null ? fallback : (mode & 511);
    };
    SecureZipArchive.prototype._addSourceFile = function (name, sourcePath, stats) {
        this._entries.set(name, {
            kind: 'file',
            sourcePath: sourcePath,
            mode: S_IFREG | (stats.mode & 511),
            mtime: stats.mtime
        });
    };
    SecureZipArchive.prototype._addFolder = function (root, directory, relativePath, zipPath, filter) {
        return __awaiter(this, void 0, void 0, function () {
            var children, _i, children_1, child, sourcePath, childPath, isSymlink, isFolder, stats, name_2, _a, _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0: return [4 /*yield*/, fs.promises.readdir(directory, { withFileTypes: true })];
                    case 1:
                        children = _c.sent();
                        children.sort(compareByName);
                        _i = 0, children_1 = children;
                        _c.label = 2;
                    case 2:
                        if (!(_i < children_1.length)) return [3 /*break*/, 9];
                        child = children_1[_i];
                        sourcePath = path.join(directory, child.name);
                        childPath = relativePath ? relativePath + '/' + child.name : child.name;
                        isSymlink = child.isSymbolicLink();
                        isFolder = child.isDirectory();
                        // Sockets, pipes and devices cannot be stored.
                        if (!isSymlink && !isFolder && !child.isFile()) {
                            return [3 /*break*/, 8];
                        }
                        if (isSymlink && this._symlinks === 'skip') {
                            return [3 /*break*/, 8];
                        }
                        if (filter && !filter(childPath, isFolder)) {
                            return [3 /*break*/, 8];
                        }
                        return [4 /*yield*/, fs.promises.lstat(sourcePath)];
                    case 3:
                        stats = _c.sent();
                        name_2 = toEntryName(zipPath, childPath, isFolder);
                        if (!isSymlink) return [3 /*break*/, 5];
                        _a = this._addSymlink;
                        _b = [root, name_2, sourcePath];
                        return [4 /*yield*/, fs.promises.readlink(sourcePath)];
                    case 4:
                        _a.apply(this, _b.concat([_c.sent(), stats]));
                        return [3 /*break*/, 8];
                    case 5:
                        if (!isFolder) return [3 /*break*/, 7];
                        this._entries.set(name_2, { kind: 'directory', mode: secureZipCommon_1.S_IFDIR | (stats.mode & 511), mtime: stats.mtime });
                        return [4 /*yield*/, this._addFolder(root, sourcePath, childPath, zipPath, filter)];
                    case 6:
                        _c.sent();
                        return [3 /*break*/, 8];
                    case 7:
                        this._addSourceFile(name_2, sourcePath, stats);
                        _c.label = 8;
                    case 8:
                        _i++;
                        return [3 /*break*/, 2];
                    case 9: return [2 /*return*/];
                }
            });
        });
    };
    SecureZipArchive.prototype._addSymlink = function (root, name, sourcePath, target, stats) {
        if (path.posix.isAbsolute(target) || path.win32.isAbsolute(target)) {
            throw new Error(im._loc('LIB_ArchiveSymlinkAbsoluteTarget', sourcePath));
        }
        var normalizedTarget = target.replace(/\\/g, '/');
        var resolvedTarget = path.resolve.apply(path, __spreadArray([path.dirname(sourcePath)], normalizedTarget.split('/'), false));
        if (!(0, secureZipCommon_1.isWithinDirectory)(root, resolvedTarget)) {
            throw new Error(im._loc('LIB_ArchiveSymlinkTargetOutsideSource', sourcePath));
        }
        this._entries.set(name, {
            kind: 'symlink',
            data: Buffer.from(normalizedTarget),
            mode: secureZipCommon_1.S_IFLNK | 511,
            mtime: stats.mtime
        });
    };
    // An existing zip inside a folder that is being zipped would otherwise be added to itself.
    SecureZipArchive.prototype._assertTargetIsNotAnEntry = function (target) {
        this._entries.forEach(function (entry) {
            if (entry.sourcePath && path.relative(entry.sourcePath, target) === '') {
                throw new Error(im._loc('LIB_ArchiveDestinationInsideSource', target));
            }
        });
    };
    return SecureZipArchive;
}());
exports.SecureZipArchive = SecureZipArchive;
/**
 * Creates a ZIP archive from the contents of a folder. Replacement for the common adm-zip sequence
 * addLocalFolder followed by writeZip:
 *
 *     await createZipSecure(contentsDirectory, zipFile);
 *
 * @param sourceDirectory  folder whose contents are archived
 * @param destinationZip   path of the zip file to create or replace. It must not be inside the archived contents.
 * @param options          optional archive folder, filter and symbolic link handling
 * @returns                absolute path of the zip file
 */
function createZipSecure(sourceDirectory, destinationZip, options) {
    return __awaiter(this, void 0, void 0, function () {
        var archive;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    archive = new SecureZipArchive(options);
                    return [4 /*yield*/, archive.addLocalFolder(sourceDirectory, options && options.zipPath, options && options.filter)];
                case 1:
                    _a.sent();
                    return [2 /*return*/, archive.writeZip(destinationZip)];
            }
        });
    });
}
exports.createZipSecure = createZipSecure;

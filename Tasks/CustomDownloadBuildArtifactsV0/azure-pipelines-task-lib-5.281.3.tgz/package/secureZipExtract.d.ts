/// <reference types="node" />
/// <reference types="node" />
import events = require('events');
/** Subset of a yauzl entry used by the extractor. */
export interface ZipEntry {
    externalFileAttributes: number;
    fileName: string;
    uncompressedSize: number;
    versionMadeBy: number;
}
/** Subset of a yauzl ZipFile used by the extractor. */
export interface ZipFile {
    close(): void;
    eachEntry(): AsyncIterable<ZipEntry>;
    openReadStreamPromise(entry: ZipEntry): Promise<NodeJS.ReadableStream>;
}
/**
 * Options accepted by extractZipSecure. dir, defaultDirMode, defaultFileMode and onEntry
 * mirror the options of the extract-zip package; the remaining options are additional guards.
 */
export interface ExtractZipOptions {
    /** Absolute path of the directory to extract into. Created if missing. */
    dir: string;
    /** Mode applied to directories that carry no Unix permissions. Defaults to 0o755. */
    defaultDirMode?: number;
    /** Mode applied to files that carry no Unix permissions. Defaults to 0o644. */
    defaultFileMode?: number;
    /** Called for every entry (except __MACOSX metadata) before it is extracted. */
    onEntry?: (entry: ZipEntry, zipFile: ZipFile) => void | Promise<void>;
    /** Optional. Fails extraction when the archive holds more entries than this. */
    maxEntries?: number;
    /** Optional. Fails extraction when the declared uncompressed size exceeds this many bytes. */
    maxTotalSize?: number;
}
/** Entry description reported by SecureZipExtractor's 'extract' event. */
export interface ExtractedEntry {
    path: string;
    type: 'file' | 'directory' | 'symlink';
}
/** Options accepted by SecureZipExtractor.extract. */
export interface ZipExtractorOptions {
    /** Absolute path of the directory to extract into. */
    path: string;
}
/**
 * Securely extracts a ZIP archive. Drop-in replacement for the extract-zip package:
 *
 *     await extractZipSecure(zipPath, { dir: '/absolute/target' });
 *
 * A plain destination string is also accepted. The archive is detected by content rather than
 * by file extension, so any ZIP container (.zip, .nupkg, .vsix, .jar, ...) can be extracted.
 * Entries can neither escape the destination through '..' segments nor through symbolic links.
 *
 * @param file                  path of the ZIP archive
 * @param destinationOrOptions  absolute destination directory, or extraction options
 * @returns                     canonical (symlink-resolved) path of the destination directory
 */
export declare function extractZipSecure(file: string, destinationOrOptions: string | ExtractZipOptions): Promise<string>;
/**
 * Event based wrapper over extractZipSecure for code written against decompress-zip:
 *
 *     const unzipper = new SecureZipExtractor(zipPath);
 *     unzipper.on('error', reject);
 *     unzipper.on('extract', log => resolve());
 *     unzipper.extract({ path: targetDirectory });
 *
 * Emits 'extract' with the list of extracted entries on success, or 'error' on failure.
 */
export declare class SecureZipExtractor extends events.EventEmitter {
    private _file;
    constructor(file: string);
    extract(options: ZipExtractorOptions): void;
}

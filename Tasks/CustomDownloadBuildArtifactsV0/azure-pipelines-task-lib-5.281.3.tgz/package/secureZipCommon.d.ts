export declare const S_IFDIR = 16384;
export declare const S_IFLNK = 40960;
export declare function isWithinDirectory(root: string, candidate: string): boolean;
export declare function assertSupportedNode(): void;

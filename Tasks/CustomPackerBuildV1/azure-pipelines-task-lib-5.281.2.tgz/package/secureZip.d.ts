/// <reference types="node" />
/// <reference types="node" />
/// <reference types="node" />
import events = require('events');
/** Subset of a yauzl entry used by the extractor. */
export interface ZipEntry {
    externalFileAttributes: number;
    fileName: string;
    uncompressedSize: number;
    versionMadeBy: number;
}
/** Subset of a yauzl ZipFile used by the extractor. */
export interface ZipFile {
    close(): void;
    eachEntry(): AsyncIterable<ZipEntry>;
    openReadStreamPromise(entry: ZipEntry): Promise<NodeJS.ReadableStream>;
}
/**
 * Options accepted by extractZipSecure. dir, defaultDirMode, defaultFileMode and onEntry
 * mirror the options of the extract-zip package; the remaining options are additional guards.
 */
export interface ExtractZipOptions {
    /** Absolute path of the directory to extract into. Created if missing. */
    dir: string;
    /** Mode applied to directories that carry no Unix permissions. Defaults to 0o755. */
    defaultDirMode?: number;
    /** Mode applied to files that carry no Unix permissions. Defaults to 0o644. */
    defaultFileMode?: number;
    /** Called for every entry (except __MACOSX metadata) before it is extracted. */
    onEntry?: (entry: ZipEntry, zipFile: ZipFile) => void | Promise<void>;
    /** Optional. Fails extraction when the archive holds more entries than this. */
    maxEntries?: number;
    /** Optional. Fails extraction when the declared uncompressed size exceeds this many bytes. */
    maxTotalSize?: number;
}
/** Entry description reported by SecureZipExtractor's 'extract' event. */
export interface ExtractedEntry {
    path: string;
    type: 'file' | 'directory' | 'symlink';
}
/** Options accepted by SecureZipExtractor.extract. */
export interface ZipExtractorOptions {
    /** Absolute path of the directory to extract into. */
    path: string;
}
/**
 * Securely extracts a ZIP archive. Drop-in replacement for the extract-zip package:
 *
 *     await extractZipSecure(zipPath, { dir: '/absolute/target' });
 *
 * A plain destination string is also accepted. The archive is detected by content rather than
 * by file extension, so any ZIP container (.zip, .nupkg, .vsix, .jar, ...) can be extracted.
 * Entries can neither escape the destination through '..' segments nor through symbolic links.
 *
 * @param file                  path of the ZIP archive
 * @param destinationOrOptions  absolute destination directory, or extraction options
 * @returns                     canonical (symlink-resolved) path of the destination directory
 */
export declare function extractZipSecure(file: string, destinationOrOptions: string | ExtractZipOptions): Promise<string>;
/**
 * Event based wrapper over extractZipSecure for code written against decompress-zip:
 *
 *     const unzipper = new SecureZipExtractor(zipPath);
 *     unzipper.on('error', reject);
 *     unzipper.on('extract', log => resolve());
 *     unzipper.extract({ path: targetDirectory });
 *
 * Emits 'extract' with the list of extracted entries on success, or 'error' on failure.
 */
export declare class SecureZipExtractor extends events.EventEmitter {
    private _file;
    constructor(file: string);
    extract(options: ZipExtractorOptions): void;
}
/** Decides whether a local file or folder is added. Receives the path relative to the source folder, using '/' separators. */
export type ZipEntryFilter = (relativePath: string, isDirectory: boolean) => boolean;
/** How symbolic links found while adding a local folder are handled. */
export type ZipSymlinkMode = 'preserve' | 'skip';
export interface ZipArchiveOptions {
    /**
     * 'preserve' (default) stores symbolic links as links, 'skip' leaves them out. Links are never
     * followed, so content outside the source folder cannot be added by accident. A link with an
     * absolute target, or a target outside the source folder, fails the operation.
     */
    symlinks?: ZipSymlinkMode;
}
export interface AddFileOptions {
    /** Unix permission bits. Defaults to 0o644. */
    mode?: number;
    /** Last modification time. Defaults to now. */
    mtime?: Date;
}
export interface CreateZipOptions extends ZipArchiveOptions {
    /** Folder inside the archive that receives the contents of the source folder. Defaults to the archive root. */
    zipPath?: string;
    /** Excludes files and folders. Excluding a folder excludes everything below it. */
    filter?: ZipEntryFilter;
}
/**
 * Builds a ZIP archive from files, buffers and local folders. Replacement for the archive creating
 * part of adm-zip (addFile, addLocalFile, addLocalFolder, writeZip, toBuffer). Entries are collected
 * first and written together, so adding an entry name twice keeps the last one. All operations that
 * touch the file system are asynchronous. Archives and entries larger than 4 GiB are not supported.
 *
 *     const archive = new SecureZipArchive();
 *     await archive.addLocalFolder(contentsDirectory);
 *     await archive.writeZip(zipFile);
 */
export declare class SecureZipArchive {
    private _entries;
    private _symlinks;
    constructor(options?: ZipArchiveOptions);
    /**
     * Adds a file whose content is held in memory.
     *
     * @param entryName  path of the file inside the archive
     * @param data       file content
     * @param options    optional permissions and modification time
     */
    addFile(entryName: string, data: Buffer | string, options?: AddFileOptions): void;
    /**
     * Adds a file from disk.
     *
     * @param localPath  path of the file
     * @param zipPath    folder inside the archive. Defaults to the archive root.
     * @param zipName    name inside the archive. Defaults to the name of the file.
     */
    addLocalFile(localPath: string, zipPath?: string, zipName?: string): Promise<void>;
    /**
     * Adds the contents of a folder recursively, including empty folders.
     *
     * @param localPath  path of the folder
     * @param zipPath    folder inside the archive. Defaults to the archive root.
     * @param filter     optional filter deciding which files and folders are added
     */
    addLocalFolder(localPath: string, zipPath?: string, filter?: ZipEntryFilter): Promise<void>;
    /**
     * Writes the archive to a file. The archive is written to a temporary file next to the target
     * and then moved into place, so a failure never leaves a partial archive behind.
     *
     * @param targetFile  path of the zip file to create or replace
     * @returns           absolute path of the zip file
     */
    writeZip(targetFile: string): Promise<string>;
    /** Returns the archive as a buffer. Prefer writeZip for large archives. */
    toBuffer(): Promise<Buffer>;
    private _getPermissions;
    private _addSourceFile;
    private _addFolder;
    private _addSymlink;
    private _assertTargetIsNotAnEntry;
}
/**
 * Creates a ZIP archive from the contents of a folder. Replacement for the common adm-zip sequence
 * addLocalFolder followed by writeZip:
 *
 *     await createZipSecure(contentsDirectory, zipFile);
 *
 * @param sourceDirectory  folder whose contents are archived
 * @param destinationZip   path of the zip file to create or replace. It must not be inside the archived contents.
 * @param options          optional archive folder, filter and symbolic link handling
 * @returns                absolute path of the zip file
 */
export declare function createZipSecure(sourceDirectory: string, destinationZip: string, options?: CreateZipOptions): Promise<string>;

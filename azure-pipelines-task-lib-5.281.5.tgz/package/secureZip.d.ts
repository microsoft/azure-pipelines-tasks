export declare function extractZipSecure(file: string, destination: string): Promise<string>;

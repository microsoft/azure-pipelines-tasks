"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const constants_1 = require("azure-arm-rest/constants");
const webClient = require("azure-arm-rest/webClient");
var deployUtility = require('webdeployment-common/utility.js');
var zipUtility = require('webdeployment-common/ziputility.js');
const physicalRootPath = '/site/wwwroot';
const deploymentFolder = 'site/deployments';
const manifestFileName = 'manifest';
const VSTS_ZIP_DEPLOY = 'VSTS_ZIP_DEPLOY';
class KuduServiceUtility {
    constructor(kuduService) {
        this._appServiceKuduService = kuduService;
    }
    createPathIfRequired(phsyicalPath) {
        return __awaiter(this, void 0, void 0, function* () {
            var listDir = yield this._appServiceKuduService.listDir(phsyicalPath);
            if (listDir == null) {
                yield this._appServiceKuduService.createPath(phsyicalPath);
            }
        });
    }
    updateDeploymentStatus(taskResult, DeploymentID, customMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let requestBody = this._getUpdateHistoryRequest(taskResult, DeploymentID, customMessage);
                return yield this._appServiceKuduService.updateDeployment(requestBody);
            }
            catch (error) {
                tl.warning(error);
            }
        });
    }
    runPostDeploymentScript(taskParams, directoryPath) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                directoryPath = (!!directoryPath) ? directoryPath : physicalRootPath.substring(1);
                if (taskParams.TakeAppOfflineFlag) {
                    yield this._appOfflineKuduService(directoryPath, true);
                }
                var scriptFile = this._getPostDeploymentScript(taskParams.ScriptType, taskParams.InlineScript, taskParams.ScriptPath, taskParams.isLinuxApp);
                var uniqueID = this.getDeploymentID();
                var fileExtension = taskParams.isLinuxApp ? '.sh' : '.cmd';
                var mainCmdFilePath = path.join(__dirname, '..', 'postDeploymentScript', 'mainCmdFile' + fileExtension);
                yield this._appServiceKuduService.uploadFile(directoryPath, 'mainCmdFile_' + uniqueID + fileExtension, mainCmdFilePath);
                yield this._appServiceKuduService.uploadFile(directoryPath, 'kuduPostDeploymentScript_' + uniqueID + fileExtension, scriptFile.filePath);
                console.log(tl.loc('ExecuteScriptOnKudu'));
                yield this.runCommand(directoryPath, 'mainCmdFile_' + uniqueID + fileExtension + ' ' + uniqueID, 30, 'script_result_' + uniqueID + '.txt');
                yield this._printPostDeploymentLogs(directoryPath, uniqueID);
            }
            catch (error) {
                throw Error(tl.loc('FailedToRunScriptOnKuduError', error));
            }
            finally {
                try {
                    yield this._appServiceKuduService.uploadFile(directoryPath, 'delete_log_file_' + uniqueID + fileExtension, path.join(__dirname, '..', 'postDeploymentScript', 'deleteLogFile' + fileExtension));
                    yield this.runCommand(directoryPath, 'delete_log_file_' + uniqueID + fileExtension + ' ' + uniqueID, 0, null);
                }
                catch (error) {
                    tl.debug('Unable to delete log files : ' + error);
                }
                if (taskParams.TakeAppOfflineFlag) {
                    yield this._appOfflineKuduService(directoryPath, false);
                }
            }
        });
    }
    getDeploymentID() {
        if (this._deploymentID) {
            return this._deploymentID;
        }
        var buildUrl = tl.getVariable('build.buildUri');
        var releaseUrl = tl.getVariable('release.releaseUri');
        var buildId = tl.getVariable('build.buildId');
        var releaseId = tl.getVariable('release.releaseId');
        var buildNumber = tl.getVariable('build.buildNumber');
        var releaseName = tl.getVariable('release.releaseName');
        var collectionUrl = tl.getVariable('system.TeamFoundationCollectionUri');
        var teamProject = tl.getVariable('system.teamProjectId');
        var commitId = tl.getVariable('build.sourceVersion');
        var repoName = tl.getVariable('build.repository.name');
        var repoProvider = tl.getVariable('build.repository.provider');
        var buildOrReleaseUrl = "";
        var deploymentID = (releaseId ? releaseId : buildId) + Date.now().toString();
        return deploymentID;
    }
    deployWebPackage(packagePath, physicalPath, virtualPath, appOffline) {
        return __awaiter(this, void 0, void 0, function* () {
            physicalPath = physicalPath ? physicalPath : physicalRootPath;
            try {
                if (appOffline) {
                    yield this._appOfflineKuduService(physicalPath, true);
                    tl.debug('Wait for 10 seconds for app_offline to take effect');
                    yield webClient.sleepFor(10);
                }
                if (tl.stats(packagePath).isDirectory()) {
                    let tempPackagePath = deployUtility.generateTemporaryFolderOrZipPath(tl.getVariable('AGENT.TEMPDIRECTORY'), false);
                    packagePath = yield zipUtility.archiveFolder(packagePath, "", tempPackagePath);
                    tl.debug("Compressed folder " + packagePath + " into zip : " + packagePath);
                }
                else if (packagePath.toLowerCase().endsWith('.war')) {
                    physicalPath = yield this._warFileDeployment(packagePath, physicalPath, virtualPath);
                }
                yield this._appServiceKuduService.extractZIP(packagePath, physicalPath);
                if (appOffline) {
                    yield this._appOfflineKuduService(physicalPath, false);
                }
                console.log(tl.loc("Successfullydeployedpackageusingkuduserviceat", packagePath, physicalPath));
            }
            catch (error) {
                tl.error(tl.loc('PackageDeploymentFailed'));
                throw Error(error);
            }
        });
    }
    zipDeploy(packagePath, appOffline, customMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                console.log(tl.loc('PackageDeploymentInitiated'));
                yield this._preZipDeployOperation();
                if (tl.stats(packagePath).isDirectory()) {
                    let tempPackagePath = deployUtility.generateTemporaryFolderOrZipPath(tl.getVariable('AGENT.TEMPDIRECTORY'), false);
                    packagePath = yield zipUtility.archiveFolder(packagePath, "", tempPackagePath);
                    tl.debug("Compressed folder " + packagePath + " into zip : " + packagePath);
                }
                if (appOffline) {
                    yield this._appOfflineKuduService(physicalRootPath, true);
                    tl.debug('Wait for 10 seconds for app_offline to take effect');
                    yield webClient.sleepFor(10);
                }
                let queryParameters = [
                    'isAsync=true',
                    'deployer=' + VSTS_ZIP_DEPLOY
                ];
                let deploymentDetails = yield this._appServiceKuduService.zipDeploy(packagePath, queryParameters);
                try {
                    var kuduDeploymentDetails = yield this._appServiceKuduService.getDeploymentDetails(deploymentDetails.id);
                    tl.debug(`logs from ZIP deploy: ${kuduDeploymentDetails.log_url}`);
                    yield this._printZipDeployLogs(kuduDeploymentDetails.log_url);
                }
                catch (error) {
                    tl.debug(`Unable to fetch logs for kudu ZIP Deploy: ${JSON.stringify(error)}`);
                }
                if (deploymentDetails.status == constants_1.KUDU_DEPLOYMENT_CONSTANTS.FAILED) {
                    throw tl.loc('PackageDeploymentUsingZipDeployFailed');
                }
                if (appOffline) {
                    yield this._appOfflineKuduService(physicalRootPath, false);
                }
                console.log(tl.loc('PackageDeploymentSuccess'));
                return deploymentDetails.id;
            }
            catch (error) {
                tl.error(tl.loc('PackageDeploymentFailed'));
                throw Error(error);
            }
        });
    }
    postZipDeployOperation(oldDeploymentID, activeDeploymentID) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                tl.debug(`ZIP DEPLOY - Performing post zip-deploy operation: ${oldDeploymentID} => ${activeDeploymentID}`);
                let manifestFileContent = yield this._appServiceKuduService.getFileContent(`${deploymentFolder}/${oldDeploymentID}`, manifestFileName);
                if (!!manifestFileContent) {
                    let tempManifestFile = path.join(tl.getVariable('AGENT.TEMPDIRECTORY'), manifestFileName);
                    tl.writeFile(tempManifestFile, manifestFileContent);
                    yield this._appServiceKuduService.uploadFile(`${deploymentFolder}/${activeDeploymentID}`, manifestFileName, tempManifestFile);
                }
                tl.debug('ZIP DEPLOY - Performed post-zipdeploy operation.');
            }
            catch (error) {
                tl.debug(`Failed to execute post zip-deploy operation: ${JSON.stringify(error)}.`);
            }
        });
    }
    _printZipDeployLogs(log_url) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!log_url) {
                return;
            }
            var deploymentLogs = yield this._appServiceKuduService.getDeploymentLogs(log_url);
            for (var deploymentLog of deploymentLogs) {
                console.log(`${deploymentLog.message}`);
                if (deploymentLog.details_url) {
                    yield this._printZipDeployLogs(deploymentLog.details_url);
                }
            }
        });
    }
    _preZipDeployOperation() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                tl.debug('ZIP DEPLOY - Performing pre-zipdeploy operation.');
                let activeDeploymentID = yield this._appServiceKuduService.getFileContent(deploymentFolder, 'active');
                if (!!activeDeploymentID) {
                    let activeDeploymentFolder = `${deploymentFolder}/${activeDeploymentID}`;
                    tl.debug(`Active Deployment ID: '${activeDeploymentID}'. Deployment Folder: '${activeDeploymentFolder}'`);
                    let manifestFileContent = yield this._appServiceKuduService.getFileContent(activeDeploymentFolder, manifestFileName);
                    if (!manifestFileContent) {
                        tl.debug(`No Manifest file present. Creating a empty manifest file in '${activeDeploymentFolder}' directory.`);
                        var tempManifestFile = path.join(tl.getVariable('AGENT.TEMPDIRECTORY'), manifestFileName);
                        tl.writeFile(tempManifestFile, '');
                        yield this._appServiceKuduService.uploadFile(`${activeDeploymentFolder}`, manifestFileName, tempManifestFile);
                        tl.debug(`Manifest file created in '${activeDeploymentFolder}' directory.`);
                    }
                    else {
                        tl.debug('Manifest file present in active deployment directory. Skip creating a new one.');
                    }
                    tl.debug('ZIP DEPLOY - Performed pre-zipdeploy operation.');
                }
            }
            catch (error) {
                tl.debug(`Failed to execute pre zip-deploy operation: ${JSON.stringify(error)}.`);
            }
        });
    }
    _printPostDeploymentLogs(physicalPath, uniqueID) {
        return __awaiter(this, void 0, void 0, function* () {
            var stdoutLog = yield this._appServiceKuduService.getFileContent(physicalPath, 'stdout_' + uniqueID + '.txt');
            var stderrLog = yield this._appServiceKuduService.getFileContent(physicalPath, 'stderr_' + uniqueID + '.txt');
            var scriptReturnCode = yield this._appServiceKuduService.getFileContent(physicalPath, 'script_result_' + uniqueID + '.txt');
            if (scriptReturnCode == null) {
                throw new Error('File not found in Kudu Service. ' + 'script_result_' + uniqueID + '.txt');
            }
            if (stdoutLog) {
                console.log(tl.loc('stdoutFromScript'));
                console.log(stdoutLog);
            }
            if (stderrLog) {
                console.log(tl.loc('stderrFromScript'));
                if (scriptReturnCode != '0') {
                    tl.error(stderrLog);
                    throw Error(tl.loc('ScriptExecutionOnKuduFailed', scriptReturnCode, stderrLog));
                }
                else {
                    console.log(stderrLog);
                }
            }
        });
    }
    runCommand(physicalPath, command, timeOutInMinutes, pollFile) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this._appServiceKuduService.runCommand(physicalPath, command);
            }
            catch (error) {
                if (timeOutInMinutes > 0 && error.toString().indexOf('Request timeout: /api/command') != -1) {
                    tl.debug('Request timeout occurs. Trying to poll for file: ' + pollFile);
                    yield this._pollForFile(physicalPath, pollFile, timeOutInMinutes);
                }
                else {
                    if (typeof error.valueOf() == 'string') {
                        throw error;
                    }
                    throw `${error.statusCode} - ${error.statusMessage}`;
                }
            }
        });
    }
    _getPostDeploymentScript(scriptType, inlineScript, scriptPath, isLinux) {
        if (scriptType === 'Inline Script') {
            tl.debug('creating kuduPostDeploymentScript_local file');
            var scriptFilePath = path.join(tl.getVariable('AGENT.TEMPDIRECTORY'), isLinux ? 'kuduPostDeploymentScript_local.sh' : 'kuduPostDeploymentScript_local.cmd');
            tl.writeFile(scriptFilePath, inlineScript);
            tl.debug('Created temporary script file : ' + scriptFilePath);
            return {
                "filePath": scriptFilePath,
                "isCreated": true
            };
        }
        if (!tl.exist(scriptPath)) {
            throw Error(tl.loc('ScriptFileNotFound', scriptPath));
        }
        var scriptExtension = path.extname(scriptPath);
        if (isLinux) {
            if (scriptExtension != '.sh') {
                throw Error(tl.loc('InvalidScriptFile', scriptPath));
            }
        }
        else {
            if (scriptExtension != '.bat' && scriptExtension != '.cmd') {
                throw Error(tl.loc('InvalidScriptFile', scriptPath));
            }
        }
        tl.debug('postDeployment script path to execute : ' + scriptPath);
        return {
            filePath: scriptPath,
            isCreated: false
        };
    }
    _warFileDeployment(packagePath, physicalPath, virtualPath) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug('WAR: webAppPackage = ' + packagePath);
            let warFile = path.basename(packagePath.slice(0, packagePath.length - '.war'.length));
            let warExt = packagePath.slice(packagePath.length - '.war'.length);
            tl.debug('WAR: warFile = ' + warFile);
            warFile = warFile + ((virtualPath) ? "/" + virtualPath : "");
            tl.debug('WAR: warFile = ' + warFile);
            physicalPath = physicalPath + "/webapps/" + warFile;
            yield this.createPathIfRequired(physicalPath);
            return physicalPath;
        });
    }
    _appOfflineKuduService(physicalPath, enableFeature) {
        return __awaiter(this, void 0, void 0, function* () {
            if (enableFeature) {
                tl.debug('Trying to enable app offline mode.');
                var appOfflineFilePath = path.join(tl.getVariable('AGENT.TEMPDIRECTORY'), 'app_offline_temp.htm');
                tl.writeFile(appOfflineFilePath, '<h1>App Service is offline.</h1>');
                yield this._appServiceKuduService.uploadFile(physicalPath, 'app_offline.htm', appOfflineFilePath);
                tl.debug('App Offline mode enabled.');
            }
            else {
                tl.debug('Trying to disable app offline mode.');
                yield this._appServiceKuduService.deleteFile(physicalPath, 'app_offline.htm');
                tl.debug('App Offline mode disabled.');
            }
        });
    }
    _pollForFile(physicalPath, fileName, timeOutInMinutes) {
        return __awaiter(this, void 0, void 0, function* () {
            var attempts = 0;
            const retryInterval = 10;
            if (tl.getVariable('appservicedeploy.retrytimeout')) {
                timeOutInMinutes = Number(tl.getVariable('appservicedeploy.retrytimeout'));
                tl.debug('Retry timeout in minutes provided by user: ' + timeOutInMinutes);
            }
            var timeOutInSeconds = timeOutInMinutes * 60;
            var noOfRetry = timeOutInSeconds / retryInterval;
            tl.debug(`Polling started for file:  ${fileName} with retry count: ${noOfRetry}`);
            while (attempts < noOfRetry) {
                attempts += 1;
                var fileContent = yield this._appServiceKuduService.getFileContent(physicalPath, fileName);
                if (fileContent == null) {
                    tl.debug('File: ' + fileName + ' not found. retry after 10 seconds. Attempt: ' + attempts);
                    yield webClient.sleepFor(10);
                }
                else {
                    tl.debug('Found file:  ' + fileName);
                    return;
                }
            }
            if (attempts == noOfRetry) {
                throw new Error(tl.loc('ScriptStatusTimeout'));
            }
        });
    }
    _getUpdateHistoryRequest(isDeploymentSuccess, deploymentID, customMessage) {
        var status = isDeploymentSuccess ? constants_1.KUDU_DEPLOYMENT_CONSTANTS.SUCCESS : constants_1.KUDU_DEPLOYMENT_CONSTANTS.FAILED;
        var author = tl.getVariable('build.sourceVersionAuthor') || tl.getVariable('build.requestedfor') ||
            tl.getVariable('release.requestedfor') || tl.getVariable('agent.name');
        var buildUrl = tl.getVariable('build.buildUri');
        var releaseUrl = tl.getVariable('release.releaseUri');
        var buildId = tl.getVariable('build.buildId');
        var releaseId = tl.getVariable('release.releaseId');
        var buildNumber = tl.getVariable('build.buildNumber');
        var releaseName = tl.getVariable('release.releaseName');
        var collectionUrl = tl.getVariable('system.TeamFoundationCollectionUri');
        var teamProject = tl.getVariable('system.teamProjectId');
        var commitId = tl.getVariable('build.sourceVersion');
        var repoName = tl.getVariable('build.repository.name');
        var repoProvider = tl.getVariable('build.repository.provider');
        var buildOrReleaseUrl = "";
        deploymentID = !!deploymentID ? deploymentID : this.getDeploymentID();
        if (releaseUrl !== undefined) {
            buildOrReleaseUrl = collectionUrl + teamProject + "/_apps/hub/ms.vss-releaseManagement-web.hub-explorer?releaseId=" + releaseId + "&_a=release-summary";
        }
        else if (buildUrl !== undefined) {
            buildOrReleaseUrl = collectionUrl + teamProject + "/_build?buildId=" + buildId + "&_a=summary";
        }
        var message = {
            type: "deployment",
            commitId: commitId,
            buildId: buildId,
            releaseId: releaseId,
            buildNumber: buildNumber,
            releaseName: releaseName,
            repoProvider: repoProvider,
            repoName: repoName,
            collectionUrl: collectionUrl,
            teamProject: teamProject
        };
        if (!!customMessage) {
            // Append Custom Messages to original message
            for (var attribute in customMessage) {
                message[attribute] = customMessage[attribute];
            }
        }
        var deploymentLogType = message['type'];
        var active = false;
        if (deploymentLogType.toLowerCase() === "deployment" && isDeploymentSuccess) {
            active = true;
        }
        return {
            id: deploymentID,
            active: active,
            status: status,
            message: JSON.stringify(message),
            author: author,
            deployer: 'VSTS',
            details: buildOrReleaseUrl
        };
    }
}
exports.KuduServiceUtility = KuduServiceUtility;

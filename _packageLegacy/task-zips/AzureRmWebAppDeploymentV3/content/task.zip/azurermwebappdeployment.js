"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const azure_arm_endpoint_1 = require("azure-arm-rest/azure-arm-endpoint");
const AzureResourceFilterUtility_1 = require("./operations/AzureResourceFilterUtility");
const KuduServiceUtility_1 = require("./operations/KuduServiceUtility");
const azure_arm_app_service_1 = require("azure-arm-rest/azure-arm-app-service");
const AzureAppServiceUtility_1 = require("./operations/AzureAppServiceUtility");
const ContainerBasedDeploymentUtility_1 = require("./operations/ContainerBasedDeploymentUtility");
const TaskParameters_1 = require("./operations/TaskParameters");
const FileTransformsUtility_1 = require("./operations/FileTransformsUtility");
const ParameterParser = require("./parameterparser");
const ReleaseAnnotationUtility_1 = require("./operations/ReleaseAnnotationUtility");
const WarDeploymentUtilities_1 = require("./operations/WarDeploymentUtilities");
var packageUtility = require('webdeployment-common/packageUtility.js');
var zipUtility = require('webdeployment-common/ziputility.js');
var deployUtility = require('webdeployment-common/utility.js');
var msDeploy = require('webdeployment-common/deployusingmsdeploy.js');
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        let zipDeploymentID;
        let isDeploymentSuccess = true;
        let kuduServiceUtility;
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            var taskParams = TaskParameters_1.TaskParametersUtility.getParameters();
            var azureEndpoint = yield new azure_arm_endpoint_1.AzureRMEndpoint(taskParams.connectedServiceName).getEndpoint();
            var virtualApplicationPath;
            console.log(tl.loc('GotconnectiondetailsforazureRMWebApp0', taskParams.WebAppName));
            if (!taskParams.DeployToSlotFlag) {
                taskParams.ResourceGroupName = yield AzureResourceFilterUtility_1.AzureResourceFilterUtility.getResourceGroupName(azureEndpoint, taskParams.WebAppName);
            }
            tl.debug(`Resource Group: ${taskParams.ResourceGroupName}`);
            var appService = new azure_arm_app_service_1.AzureAppService(azureEndpoint, taskParams.ResourceGroupName, taskParams.WebAppName, taskParams.SlotName, taskParams.WebAppKind);
            let appServiceUtility = new AzureAppServiceUtility_1.AzureAppServiceUtility(appService);
            yield appServiceUtility.pingApplication();
            let kuduService = yield appServiceUtility.getKuduService();
            kuduServiceUtility = new KuduServiceUtility_1.KuduServiceUtility(kuduService);
            if (taskParams.WebAppUri) {
                tl.setVariable(taskParams.WebAppUri, yield appServiceUtility.getApplicationURL(!taskParams.isLinuxApp ? taskParams.VirtualApplication : null));
            }
            if (taskParams.isLinuxApp) {
                switch (taskParams.ImageSource) {
                    case 'Builtin': {
                        var webPackage = packageUtility.PackageUtility.getPackagePath(taskParams.Package);
                        tl.debug('Performing Linux built-in package deployment');
                        zipDeploymentID = yield kuduServiceUtility.zipDeploy(webPackage, taskParams.TakeAppOfflineFlag, { slotName: appService.getSlot() });
                        yield appServiceUtility.updateStartupCommandAndRuntimeStack(taskParams.RuntimeStack, taskParams.StartupCommand);
                        break;
                    }
                    case 'Registry': {
                        tl.debug("Performing container based deployment.");
                        let containerDeploymentUtility = new ContainerBasedDeploymentUtility_1.ContainerBasedDeploymentUtility(appService);
                        yield containerDeploymentUtility.deployWebAppImage(taskParams);
                        break;
                    }
                    default: {
                        throw new Error('Invalid Image source Type');
                    }
                }
            }
            else {
                var webPackage = packageUtility.PackageUtility.getPackagePath(taskParams.Package);
                var isFolderBasedDeployment = deployUtility.isInputPkgIsFolder(webPackage);
                var physicalPath = '/site/wwwroot';
                if (taskParams.VirtualApplication) {
                    physicalPath = yield appServiceUtility.getPhysicalPath(taskParams.VirtualApplication);
                    yield kuduServiceUtility.createPathIfRequired(physicalPath);
                    virtualApplicationPath = physicalPath;
                }
                webPackage = yield FileTransformsUtility_1.FileTransformsUtility.applyTransformations(webPackage, taskParams);
                if (deployUtility.canUseWebDeploy(taskParams.UseWebDeploy)) {
                    tl.debug("Performing the deployment of webapp.");
                    if (!tl.osType().match(/^Win/)) {
                        throw Error(tl.loc("PublishusingwebdeployoptionsaresupportedonlywhenusingWindowsagent"));
                    }
                    if (taskParams.RenameFilesFlag) {
                        yield appServiceUtility.enableRenameLockedFiles();
                    }
                    var msDeployPublishingProfile = yield appServiceUtility.getWebDeployPublishingProfile();
                    if (webPackage.toString().toLowerCase().endsWith('.war')) {
                        yield WarDeploymentUtilities_1.DeployWar(webPackage, taskParams, msDeployPublishingProfile, kuduService, appServiceUtility);
                    }
                    else {
                        yield msDeploy.DeployUsingMSDeploy(webPackage, taskParams.WebAppName, msDeployPublishingProfile, taskParams.RemoveAdditionalFilesFlag, taskParams.ExcludeFilesFromAppDataFlag, taskParams.TakeAppOfflineFlag, taskParams.VirtualApplication, taskParams.SetParametersFile, taskParams.AdditionalArguments, isFolderBasedDeployment, taskParams.UseWebDeploy);
                    }
                }
                else {
                    tl.debug("Initiated deployment via kudu service for webapp package : ");
                    yield kuduServiceUtility.deployWebPackage(webPackage, physicalPath, taskParams.VirtualApplication, taskParams.TakeAppOfflineFlag);
                }
            }
            if (!taskParams.isContainerWebApp) {
                if (taskParams.AppSettings) {
                    var customApplicationSettings = ParameterParser.parse(taskParams.AppSettings);
                    yield appServiceUtility.updateAndMonitorAppSettings(customApplicationSettings);
                }
                if (taskParams.ConfigurationSettings) {
                    var customApplicationSettings = ParameterParser.parse(taskParams.ConfigurationSettings);
                    yield appServiceUtility.updateConfigurationSettings(customApplicationSettings);
                }
            }
            else {
                tl.debug('App Settings and config settings are already updated during container based deployment.');
            }
            if (taskParams.ScriptType) {
                yield kuduServiceUtility.runPostDeploymentScript(taskParams, virtualApplicationPath);
            }
            yield appServiceUtility.updateScmTypeAndConfigurationDetails();
        }
        catch (error) {
            isDeploymentSuccess = false;
            tl.setResult(tl.TaskResult.Failed, error);
        }
        finally {
            if (kuduServiceUtility) {
                yield ReleaseAnnotationUtility_1.addReleaseAnnotation(azureEndpoint, appService, isDeploymentSuccess);
                let activeDeploymentID = yield kuduServiceUtility.updateDeploymentStatus(isDeploymentSuccess, null, { 'type': 'Deployment', slotName: appService.getSlot() });
                if (zipDeploymentID && activeDeploymentID && isDeploymentSuccess) {
                    yield kuduServiceUtility.postZipDeployOperation(zipDeploymentID, activeDeploymentID);
                }
            }
            else {
                tl.debug('Cannot update deployment status as Kudu is not initialized');
            }
        }
    });
}
main();

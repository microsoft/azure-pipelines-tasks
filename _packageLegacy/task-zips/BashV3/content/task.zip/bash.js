"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const tl = require("vsts-task-lib/task");
var uuidV4 = require('uuid/v4');
function translateDirectoryPath(bashPath, directoryPath) {
    return __awaiter(this, void 0, void 0, function* () {
        let bashPwd = tl.tool(bashPath)
            .arg('--noprofile')
            .arg('--norc')
            .arg('-c')
            .arg('pwd');
        let bashPwdOptions = {
            cwd: directoryPath,
            failOnStdErr: true,
            errStream: process.stdout,
            outStream: process.stdout,
            ignoreReturnCode: false
        };
        let pwdOutput = '';
        bashPwd.on('stdout', (data) => {
            pwdOutput += data.toString();
        });
        yield bashPwd.exec(bashPwdOptions);
        pwdOutput = pwdOutput.trim();
        if (!pwdOutput) {
            throw new Error(tl.loc('JS_TranslatePathFailed', directoryPath));
        }
        return `${pwdOutput}`;
    });
}
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // Get inputs.
            let input_failOnStderr = tl.getBoolInput('failOnStderr', false);
            let input_workingDirectory = tl.getPathInput('workingDirectory', /*required*/ true, /*check*/ true);
            let input_filePath;
            let input_arguments;
            let input_script;
            let input_targetType = tl.getInput('targetType') || '';
            if (input_targetType.toUpperCase() == 'FILEPATH') {
                input_filePath = tl.getPathInput('filePath', /*required*/ true);
                if (!tl.stats(input_filePath).isFile()) {
                    throw new Error(tl.loc('JS_InvalidFilePath', input_filePath));
                }
                input_arguments = tl.getInput('arguments') || '';
            }
            else {
                input_script = tl.getInput('script', false) || '';
            }
            // Generate the script contents.
            console.log(tl.loc('GeneratingScript'));
            let bashPath = tl.which('bash', true);
            let contents;
            if (input_targetType.toUpperCase() == 'FILEPATH') {
                // Translate the target file path from Windows to the Linux file system.
                let targetFilePath;
                if (process.platform == 'win32') {
                    targetFilePath = (yield translateDirectoryPath(bashPath, path.dirname(input_filePath))) + '/' + path.basename(input_filePath);
                }
                else {
                    targetFilePath = input_filePath;
                }
                contents = `. '${targetFilePath.replace("'", "'\\''")}' ${input_arguments}`.trim();
                console.log(tl.loc('JS_FormattedCommand', contents));
            }
            else {
                contents = input_script;
                // Print one-liner scripts.
                if (contents.indexOf('\n') < 0 && contents.toUpperCase().indexOf('##VSO[') < 0) {
                    console.log(tl.loc('JS_ScriptContents'));
                    console.log(contents);
                }
            }
            // Write the script to disk.
            tl.assertAgent('2.115.0');
            let tempDirectory = tl.getVariable('agent.tempDirectory');
            tl.checkPath(tempDirectory, `${tempDirectory} (agent.tempDirectory)`);
            let fileName = uuidV4() + '.sh';
            let filePath = path.join(tempDirectory, fileName);
            yield fs.writeFileSync(filePath, contents, { encoding: 'utf8' });
            // Translate the script file path from Windows to the Linux file system.
            if (process.platform == 'win32') {
                filePath = (yield translateDirectoryPath(bashPath, tempDirectory)) + '/' + fileName;
            }
            // Create the tool runner.
            let bash = tl.tool(bashPath)
                .arg('--noprofile')
                .arg('--norc')
                .arg(filePath);
            let options = {
                cwd: input_workingDirectory,
                failOnStdErr: false,
                errStream: process.stdout,
                outStream: process.stdout,
                ignoreReturnCode: true
            };
            // Listen for stderr.
            let stderrFailure = false;
            if (input_failOnStderr) {
                bash.on('stderr', (data) => {
                    stderrFailure = true;
                });
            }
            // Run bash.
            let exitCode = yield bash.exec(options);
            // Fail on exit code.
            if (exitCode !== 0) {
                tl.setResult(tl.TaskResult.Failed, tl.loc('JS_ExitCode', exitCode));
            }
            // Fail on stderr.
            if (stderrFailure) {
                tl.setResult(tl.TaskResult.Failed, tl.loc('JS_Stderr'));
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err.message || 'run() failed');
        }
    });
}
run();

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const request = require("request");
const Q = require("q");
const fs = require("fs");
const os = require("os");
const utils = require("./utils");
class UploadInfo {
}
class SymbolsUploadInfo {
}
function getEndpointDetails(endpointInputFieldName) {
    var errorMessage = tl.loc("CannotDecodeEndpoint");
    var endpoint = tl.getInput(endpointInputFieldName, true);
    if (!endpoint) {
        throw new Error(errorMessage);
    }
    let url = tl.getEndpointUrl(endpoint, false);
    let apiServer = url.substr(0, url.lastIndexOf('/'));
    let apiVersion = url.substr(url.lastIndexOf('/') + 1);
    let authToken = tl.getEndpointAuthorizationParameter(endpoint, 'apitoken', false);
    return {
        apiServer: apiServer,
        apiVersion: apiVersion,
        authToken: authToken
    };
}
function responseHandler(defer, err, res, body, handler) {
    if (body) {
        tl.debug(`---- ${JSON.stringify(body)}`);
    }
    if (err) {
        tl.debug(`---- Failed with error: ${err}`);
        defer.reject(err);
        return;
    }
    if (!res) {
        defer.reject(tl.loc("NoResponseFromServer"));
        return;
    }
    tl.debug(`---- http call status code: ${res.statusCode}`);
    if (res.statusCode < 200 || res.statusCode >= 300) {
        let message = JSON.stringify(body);
        if (!message) {
            message = `http response code: ${res.statusCode}`;
        }
        else {
            message = message.concat(os.EOL + `http response code: ${res.statusCode}`);
        }
        defer.reject(message);
        return;
    }
    handler();
}
function beginReleaseUpload(apiServer, apiVersion, appSlug, token, userAgent) {
    tl.debug("-- Prepare for uploading release.");
    let defer = Q.defer();
    let beginUploadUrl = `${apiServer}/${apiVersion}/apps/${appSlug}/release_uploads`;
    tl.debug(`---- url: ${beginUploadUrl}`);
    let headers = {
        "Content-Type": "application/json",
        "X-API-Token": token,
        "User-Agent": userAgent,
        "internal-request-source": "VSTS"
    };
    request.post({ url: beginUploadUrl, headers: headers }, (err, res, body) => {
        responseHandler(defer, err, res, body, () => {
            let response = JSON.parse(body);
            let uploadInfo = {
                upload_id: response['upload_id'],
                upload_url: response['upload_url']
            };
            defer.resolve(uploadInfo);
        });
    });
    return defer.promise;
}
function uploadRelease(uploadUrl, file, userAgent) {
    tl.debug("-- Uploading release...");
    let defer = Q.defer();
    tl.debug(`---- url: ${uploadUrl}`);
    let headers = {
        "User-Agent": userAgent,
        "internal-request-source": "VSTS"
    };
    let req = request.post({ url: uploadUrl, headers: headers }, (err, res, body) => {
        responseHandler(defer, err, res, body, () => {
            tl.debug('-- File uploaded.');
            defer.resolve();
        });
    });
    let form = req.form();
    form.append('ipa', fs.createReadStream(file));
    return defer.promise;
}
function commitRelease(apiServer, apiVersion, appSlug, upload_id, token, userAgent) {
    tl.debug("-- Finishing uploading release...");
    let defer = Q.defer();
    let commitReleaseUrl = `${apiServer}/${apiVersion}/apps/${appSlug}/release_uploads/${upload_id}`;
    tl.debug(`---- url: ${commitReleaseUrl}`);
    let headers = {
        "X-API-Token": token,
        "User-Agent": userAgent,
        "internal-request-source": "VSTS"
    };
    let commitBody = { "status": "committed" };
    request.patch({ url: commitReleaseUrl, headers: headers, json: commitBody }, (err, res, body) => {
        responseHandler(defer, err, res, body, () => {
            if (body && body['release_url']) {
                defer.resolve(body['release_url']);
            }
            else {
                defer.reject(tl.loc("FailedToUploadFile"));
            }
        });
    });
    return defer.promise;
}
function publishRelease(apiServer, releaseUrl, releaseNotes, distributionGroupId, token, userAgent) {
    tl.debug("-- Mark package available.");
    let defer = Q.defer();
    let publishReleaseUrl = `${apiServer}/${releaseUrl}`;
    tl.debug(`---- url: ${publishReleaseUrl}`);
    let headers = {
        "X-API-Token": token,
        "User-Agent": userAgent,
        "internal-request-source": "VSTS"
    };
    let publishBody = {
        "status": "available",
        "distribution_group_id": distributionGroupId,
        "release_notes": releaseNotes
    };
    request.patch({ url: publishReleaseUrl, headers: headers, json: publishBody }, (err, res, body) => {
        responseHandler(defer, err, res, body, () => {
            defer.resolve();
        });
    });
    return defer.promise;
}
/**
 * If the input is a single file, upload this file without any processing.
 * If the input is a single folder, zip it's content. The archive name is the folder's name
 * If the input is a set of folders or files, zip them so they appear on the root of the archive. The archive name is the parent folder's name.
 */
function prepareSymbols(symbolsPaths) {
    tl.debug("-- Prepare symbols");
    let defer = Q.defer();
    if (symbolsPaths.length === 1 && fs.statSync(symbolsPaths[0]).isFile()) {
        tl.debug(`.. a single symbols file: ${symbolsPaths[0]}`);
        // single file - Android source mapping txt file 
        defer.resolve(symbolsPaths[0]);
    }
    else if (symbolsPaths.length > 0) {
        tl.debug(`.. archiving: ${symbolsPaths}`);
        let symbolsRoot = utils.findCommonParent(symbolsPaths);
        let zipPath = utils.getArchivePath(symbolsRoot);
        let zipStream = utils.createZipStream(symbolsPaths, symbolsRoot);
        utils.createZipFile(zipStream, zipPath).
            then(() => {
            tl.debug(`---- symbols arechive file: ${zipPath}`);
            defer.resolve(zipPath);
        });
    }
    else {
        defer.resolve(null);
    }
    return defer.promise;
}
function beginSymbolUpload(apiServer, apiVersion, appSlug, symbol_type, token, userAgent) {
    tl.debug("-- Begin symbols upload");
    let defer = Q.defer();
    let beginSymbolUploadUrl = `${apiServer}/${apiVersion}/apps/${appSlug}/symbol_uploads`;
    tl.debug(`---- url: ${beginSymbolUploadUrl}`);
    let headers = {
        "X-API-Token": token,
        "User-Agent": userAgent,
        "internal-request-source": "VSTS"
    };
    let symbolsUploadBody = { "symbol_type": symbol_type };
    request.post({ url: beginSymbolUploadUrl, headers: headers, json: symbolsUploadBody }, (err, res, body) => {
        responseHandler(defer, err, res, body, () => {
            let symbolsUploadInfo = {
                symbol_upload_id: body['symbol_upload_id'],
                upload_url: body['upload_url'],
                expiration_date: body['expiration_date']
            };
            defer.resolve(symbolsUploadInfo);
        });
    });
    return defer.promise;
}
function uploadSymbols(uploadUrl, file, userAgent) {
    tl.debug("-- Uploading symbols...");
    let defer = Q.defer();
    tl.debug(`---- url: ${uploadUrl}`);
    let stat = fs.statSync(file);
    let headers = {
        "x-ms-blob-type": "BlockBlob",
        "Content-Length": stat.size,
        "User-Agent": userAgent,
        "internal-request-source": "VSTS"
    };
    fs.createReadStream(file).pipe(request.put({ url: uploadUrl, headers: headers }, (err, res, body) => {
        responseHandler(defer, err, res, body, () => {
            tl.debug('-- Symbol uploaded.');
            defer.resolve();
        });
    }));
    return defer.promise;
}
function commitSymbols(apiServer, apiVersion, appSlug, symbol_upload_id, token, userAgent) {
    tl.debug("-- Finishing uploading symbols...");
    let defer = Q.defer();
    let commitSymbolsUrl = `${apiServer}/${apiVersion}/apps/${appSlug}/symbol_uploads/${symbol_upload_id}`;
    tl.debug(`---- url: ${commitSymbolsUrl}`);
    let headers = {
        "X-API-Token": token,
        "User-Agent": userAgent,
        "internal-request-source": "VSTS"
    };
    let commitBody = { "status": "committed" };
    request.patch({ url: commitSymbolsUrl, headers: headers, json: commitBody }, (err, res, body) => {
        responseHandler(defer, err, res, body, () => {
            defer.resolve();
        });
    });
    return defer.promise;
}
function expandSymbolsPaths(symbolsType, pattern, continueOnError, packParentFolder) {
    tl.debug("-- Expanding symbols path pattern to a list of paths");
    let symbolsPaths = [];
    if (symbolsType === "Apple") {
        // User can specifay a symbols path pattern that selects 
        // multiple dSYM folder paths for Apple application.
        let dsymPaths = utils.resolvePaths(pattern, continueOnError, packParentFolder);
        // Resolved paths can be null if continueIfSymbolsNotFound is true and the file/folder does not exist.
        if (dsymPaths) {
            dsymPaths.forEach(dsymFolder => {
                if (dsymFolder) {
                    let folderPath = utils.checkAndFixFilePath(dsymFolder, continueOnError);
                    // The path can be null if continueIfSymbolsNotFound is true and the folder does not exist.
                    if (folderPath) {
                        symbolsPaths.push(folderPath);
                    }
                }
            });
        }
    }
    else if (symbolsType === "UWP") {
        // User can specifay a symbols path pattern that selects 
        // multiple PDB paths for UWP application.
        let pdbPaths = utils.resolvePaths(pattern, continueOnError, packParentFolder);
        // Resolved paths can be null if continueIfSymbolsNotFound is true and the file/folder does not exist.
        if (pdbPaths) {
            pdbPaths.forEach(pdbFile => {
                if (pdbFile) {
                    let pdbPath = utils.checkAndFixFilePath(pdbFile, continueOnError);
                    // The path can be null if continueIfSymbolsNotFound is true and the file does not exist.
                    if (pdbPath) {
                        symbolsPaths.push(pdbPath);
                    }
                }
            });
        }
    }
    else {
        // For all other application types user can specifay a symbols path pattern 
        // that selects only one file or one folder.
        let symbolsFile = utils.resolveSinglePath(pattern, continueOnError, packParentFolder);
        // Resolved paths can be null if continueIfSymbolsNotFound is true and the file/folder does not exist.
        if (symbolsFile) {
            let filePath = utils.checkAndFixFilePath(symbolsFile, continueOnError);
            // The path can be null if continueIfSymbolsNotFound is true and the file/folder does not exist.
            if (filePath) {
                symbolsPaths.push(filePath);
            }
        }
    }
    return symbolsPaths;
}
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // Get build inputs
            let apiEndpointData = getEndpointDetails('serverEndpoint');
            let apiToken = apiEndpointData.authToken;
            let apiServer = apiEndpointData.apiServer;
            let apiVersion = apiEndpointData.apiVersion;
            let userAgent = tl.getVariable('MSDEPLOY_HTTP_USER_AGENT');
            if (!userAgent) {
                userAgent = 'VSTS';
            }
            userAgent = userAgent + ' (Task:VSMobileCenterUpload)';
            var effectiveApiServer = process.env['SONOMA_API_SERVER'] || apiServer;
            var effectiveApiVersion = process.env['SONOMA_API_VERSION'] || apiVersion;
            tl.debug(`Effective API Url: ${effectiveApiServer}/${effectiveApiVersion}`);
            let appSlug = tl.getInput('appSlug', true);
            let appFilePattern = tl.getInput('app', true);
            /* The task has support for different symbol types but App Center server only support Apple currently, add back these types in the task.json when support is available in App Center.
            "AndroidJava": "Android (Java)",
            "AndroidNative": "Android (native C/C++)",
            "Windows": "Windows 8.1",
            "UWP": "Universal Windows Platform (UWP)"
            */
            let symbolsType = tl.getInput('symbolsType', false);
            let symbolVariableName = null;
            switch (symbolsType) {
                case "Apple":
                    symbolVariableName = "dsymPath";
                    break;
                case "AndroidJava":
                    symbolVariableName = "mappingTxtPath";
                    break;
                case "UWP":
                    symbolVariableName = "pdbPath";
                    break;
                default:
                    symbolVariableName = "symbolsPath";
            }
            let symbolsPathPattern = tl.getInput(symbolVariableName, false);
            let packParentFolder = tl.getBoolInput('packParentFolder', false);
            let releaseNotesSelection = tl.getInput('releaseNotesSelection', true);
            let releaseNotes = null;
            if (releaseNotesSelection === 'file') {
                let releaseNotesFile = tl.getPathInput('releaseNotesFile', true, true);
                releaseNotes = fs.readFileSync(releaseNotesFile).toString('utf8');
            }
            else {
                releaseNotes = tl.getInput('releaseNotesInput', true);
            }
            let distributionGroupId = tl.getInput('distributionGroupId', false) || '00000000-0000-0000-0000-000000000000';
            tl.debug(`Effective distribution_group_id: ${distributionGroupId}`);
            // Validate inputs
            if (!apiToken) {
                throw new Error(tl.loc("NoApiTokenFound"));
            }
            let app = utils.resolveSinglePath(appFilePattern);
            tl.checkPath(app, "Binary file");
            let continueIfSymbolsNotFoundVariable = tl.getVariable('VSMobileCenterUpload.ContinueIfSymbolsNotFound');
            let continueIfSymbolsNotFound = false;
            if (continueIfSymbolsNotFoundVariable && continueIfSymbolsNotFoundVariable.toLowerCase() === 'true') {
                continueIfSymbolsNotFound = true;
            }
            // Expand symbols path pattern to a list of paths
            let symbolsPaths = expandSymbolsPaths(symbolsType, symbolsPathPattern, continueIfSymbolsNotFound, packParentFolder);
            // Prepare symbols
            let symbolsFile = yield prepareSymbols(symbolsPaths);
            // Begin release upload
            let uploadInfo = yield beginReleaseUpload(effectiveApiServer, effectiveApiVersion, appSlug, apiToken, userAgent);
            // Perform the upload
            yield uploadRelease(uploadInfo.upload_url, app, userAgent);
            // Commit the upload
            let packageUrl = yield commitRelease(effectiveApiServer, effectiveApiVersion, appSlug, uploadInfo.upload_id, apiToken, userAgent);
            // Publish
            yield publishRelease(effectiveApiServer, packageUrl, releaseNotes, distributionGroupId, apiToken, userAgent);
            if (symbolsFile) {
                // Begin preparing upload symbols
                let symbolsUploadInfo = yield beginSymbolUpload(effectiveApiServer, effectiveApiVersion, appSlug, symbolsType, apiToken, userAgent);
                // upload symbols 
                yield uploadSymbols(symbolsUploadInfo.upload_url, symbolsFile, userAgent);
                // Commit the symbols upload
                yield commitSymbols(effectiveApiServer, effectiveApiVersion, appSlug, symbolsUploadInfo.symbol_upload_id, apiToken, userAgent);
            }
            tl.setResult(tl.TaskResult.Succeeded, tl.loc("Succeeded"));
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, `${err}`);
        }
    });
}
run();

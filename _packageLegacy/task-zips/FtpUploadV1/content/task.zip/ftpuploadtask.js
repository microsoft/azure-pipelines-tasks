"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const url = require("url");
const path = require("path");
let Client = require('ftp');
const ftputils = require("./ftputils");
class FtpOptions {
}
exports.FtpOptions = FtpOptions;
function getFtpOptions() {
    let options = new FtpOptions();
    if (tl.getInput('credsType') === 'serviceEndpoint') {
        // server endpoint
        let serverEndpoint = tl.getInput('serverEndpoint', true);
        options.serverEndpointUrl = url.parse(tl.getEndpointUrl(serverEndpoint, false));
        let serverEndpointAuth = tl.getEndpointAuthorization(serverEndpoint, false);
        options.username = serverEndpointAuth['parameters']['username'];
        options.password = serverEndpointAuth['parameters']['password'];
    }
    else if (tl.getInput('credsType') === 'inputs') {
        options.serverEndpointUrl = url.parse(tl.getInput('serverUrl', true));
        options.username = tl.getInput('username', true);
        options.password = tl.getInput('password', true);
    }
    // other standard options
    options.rootFolder = tl.getPathInput('rootFolder', true);
    options.filePatterns = tl.getDelimitedInput('filePatterns', '\n', true);
    options.remotePath = tl.getInput('remotePath', true).trim();
    // advanced options
    options.clean = tl.getBoolInput('clean', true);
    options.cleanContents = tl.getBoolInput('cleanContents', false);
    options.overwrite = tl.getBoolInput('overwrite', true);
    options.preservePaths = tl.getBoolInput('preservePaths', true);
    options.trustSSL = tl.getBoolInput('trustSSL', true);
    return options;
}
function doWork() {
    tl.setResourcePath(path.join(__dirname, 'task.json'));
    let ftpOptions = getFtpOptions();
    if (!ftpOptions.serverEndpointUrl.protocol) {
        tl.setResult(tl.TaskResult.Failed, tl.loc('FTPNoProtocolSpecified'));
    }
    if (!ftpOptions.serverEndpointUrl.hostname) {
        tl.setResult(tl.TaskResult.Failed, tl.loc('FTPNoHostSpecified'));
    }
    let ftpClient = new Client();
    let ftpHelper = new ftputils.FtpHelper(ftpOptions, ftpClient);
    let files = ftputils.findFiles(ftpOptions);
    tl.debug('number of files to upload: ' + files.length);
    tl.debug('files to upload: ' + JSON.stringify(files));
    let uploadSuccessful = false;
    ftpClient.on('greeting', (message) => {
        tl.debug('ftp client greeting');
        console.log(tl.loc('FTPConnected', message));
    });
    ftpClient.on('ready', () => __awaiter(this, void 0, void 0, function* () {
        tl.debug('ftp client ready');
        try {
            if (ftpOptions.clean) {
                console.log(tl.loc('CleanRemoteDir', ftpOptions.remotePath));
                yield ftpHelper.cleanRemote(ftpOptions.remotePath);
            }
            else if (ftpOptions.cleanContents) {
                console.log(tl.loc('CleanRemoteDirContents', ftpOptions.remotePath));
                yield ftpHelper.cleanRemoteContents(ftpOptions.remotePath);
            }
            console.log(tl.loc('UploadRemoteDir', ftpOptions.remotePath));
            yield ftpHelper.uploadFiles(files);
            uploadSuccessful = true;
            console.log(tl.loc('UploadSucceedMsg', ftpHelper.progressTracking.getSuccessStatusMessage()));
            tl.setResult(tl.TaskResult.Succeeded, tl.loc('UploadSucceedRes'));
        }
        catch (err) {
            failTask(err);
        }
        finally {
            console.log(tl.loc('DisconnectHost', ftpOptions.serverEndpointUrl.host));
            ftpClient.end();
            ftpClient.destroy();
        }
    }));
    ftpClient.on('close', (hadErr) => {
        console.log(tl.loc('Disconnected'));
        tl.debug('ftp client close, hadErr:' + hadErr);
    });
    ftpClient.on('end', () => {
        tl.debug('ftp client end');
    });
    ftpClient.on('error', (err) => {
        tl.debug('ftp client error, err: ' + err);
        if (!uploadSuccessful) {
            // once all files are successfully uploaded, a subsequent error should not fail the task
            failTask(err);
        }
    });
    let verboseSnippet = [];
    let debugLogger = function (message) {
        verboseSnippet.push(message);
        if (verboseSnippet.length >= 5) {
            verboseSnippet.shift();
        }
        tl.debug(message);
    };
    function failTask(message) {
        let fullMessage = `FTP upload failed: "${message}". FTP log: "${verboseSnippet}".`;
        if (ftpHelper.progressTracking) {
            fullMessage += ftpHelper.progressTracking.getFailureStatusMessage();
        }
        console.log(fullMessage);
        tl.setResult(tl.TaskResult.Failed, message);
    }
    let secure = ftpOptions.serverEndpointUrl.protocol.toLowerCase() == 'ftps:' ? true : false;
    tl.debug('secure ftp=' + secure);
    let secureOptions = { 'rejectUnauthorized': !ftpOptions.trustSSL };
    let hostName = ftpOptions.serverEndpointUrl.hostname;
    let port = ftpOptions.serverEndpointUrl.port;
    if (!port) {
        port = '21';
        tl.debug('port not specifided, using default: ' + port);
    }
    console.log(tl.loc('ConnectPort', hostName, port));
    ftpClient.connect({ 'host': hostName, 'port': port, 'user': ftpOptions.username, 'password': ftpOptions.password, 'secure': secure, 'secureOptions': secureOptions, 'debug': debugLogger });
}
doWork();

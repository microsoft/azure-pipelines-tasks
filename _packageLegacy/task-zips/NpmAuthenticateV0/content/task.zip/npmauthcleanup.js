"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const util = require("npm-common/util");
const constants = require("./constants");
const tl = require("vsts-task-lib/task");
const fs = require("fs");
const path = require("path");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        tl.setResourcePath(path.join(__dirname, 'task.json'));
        let indexFile = path.join(tl.getVariable("SAVE_NPMRC_PATH"), 'index.json');
        if (tl.exist(indexFile)) {
            let indexFileText = fs.readFileSync(indexFile, 'utf8');
            let jsonObject = JSON.parse(indexFileText);
            let npmrcIndex = JSON.stringify(jsonObject[tl.getInput(constants.NpmAuthenticateTaskInput.WorkingFile)]);
            util.restoreFileWithName(tl.getInput(constants.NpmAuthenticateTaskInput.WorkingFile), npmrcIndex, tl.getVariable("SAVE_NPMRC_PATH"));
            console.log(tl.loc("RevertedChangesToNpmrc", tl.getInput(constants.NpmAuthenticateTaskInput.WorkingFile)));
            if (fs.readdirSync(tl.getVariable("SAVE_NPMRC_PATH")).length == 1) {
                tl.rmRF(tl.getVariable("NPM_AUTHENTICATE_TEMP_DIRECTORY"));
            }
        }
        else {
            console.log(tl.loc("NoIndexJsonFile"));
        }
    });
}
run();

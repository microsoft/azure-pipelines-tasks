"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class NpmAuthenticateTaskInput {
}
NpmAuthenticateTaskInput.WorkingFile = 'workingFile';
NpmAuthenticateTaskInput.CustomRegistry = 'customRegistry';
NpmAuthenticateTaskInput.CustomEndpoint = 'customEndpoint';
exports.NpmAuthenticateTaskInput = NpmAuthenticateTaskInput;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const findAndroidTool = (tool) => {
    const androidHome = tl.getVariable('ANDROID_HOME');
    if (!androidHome) {
        throw new Error(tl.loc('AndroidHomeNotSet'));
    }
    // add * in search as on Windows the tool may end with ".exe" or ".bat"
    const toolsList = tl.findMatch(tl.resolve(androidHome, 'build-tools'), tool + '*', null, { matchBase: true });
    if (!toolsList || toolsList.length === 0) {
        throw new Error(tl.loc('CouldNotFindToolInAndroidHome', tool, androidHome));
    }
    return toolsList[0];
};
/*
Signing the specified file with apksigner.  Move the current file to fn.unsigned, and
place the signed file at the same location fn
*/
const apksigning = (fn) => {
    // file must exist
    tl.checkPath(fn, 'file to sign');
    let apksigner = tl.getInput('apksignerLocation', false);
    // if the tool path is not set, let's find one (anyone) from the SDK folder
    if (!apksigner) {
        apksigner = findAndroidTool('apksigner');
    }
    const apksignerRunner = tl.tool(apksigner);
    // Get keystore file path for signing
    const keystoreFile = tl.getTaskVariable('KEYSTORE_FILE_PATH');
    // Get keystore alias
    const keystoreAlias = tl.getInput('keystoreAlias', true);
    const keystorePass = tl.getInput('keystorePass', false);
    const keyPass = tl.getInput('keyPass', false);
    const apksignerArguments = tl.getInput('apksignerArguments', false);
    apksignerRunner.arg(['sign', '--ks', keystoreFile]);
    if (keystorePass) {
        apksignerRunner.arg(['--ks-pass', 'pass:' + keystorePass]);
    }
    if (keystoreAlias) {
        apksignerRunner.arg(['--ks-key-alias', keystoreAlias]);
    }
    if (keyPass) {
        apksignerRunner.arg(['--key-pass', 'pass:' + keyPass]);
    }
    if (apksignerArguments) {
        apksignerRunner.line(apksignerArguments);
    }
    apksignerRunner.arg([fn]);
    return apksignerRunner.exec(null);
};
/*
Zipaligning apk
*/
const zipaligning = (fn) => {
    // file must exist
    tl.checkPath(fn, 'file to zipalign');
    let zipaligner = tl.getInput('zipalignLocation', false);
    // if the tool path is not set, let's find one (anyone) from the SDK folder
    if (!zipaligner) {
        zipaligner = findAndroidTool('zipalign');
    }
    const zipalignRunner = tl.tool(zipaligner);
    // alignment must be 4 or play store will reject, hard code this to avoid user errors
    zipalignRunner.arg(['-v', '4']);
    const unalignedFn = fn + '.unaligned';
    const success = tl.mv(fn, unalignedFn, '-f', false);
    zipalignRunner.arg([unalignedFn, fn]);
    return zipalignRunner.exec(null);
};
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Configure localization
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // Get files to be signed
            const filesPattern = tl.getInput('files', true);
            // Signing the APK?
            const apksign = tl.getBoolInput('apksign');
            // Zipaligning the APK?
            const zipalign = tl.getBoolInput('zipalign');
            // Resolve files for the specified value or pattern
            const filesToSign = tl.findMatch(null, filesPattern);
            // Fail if no matching files were found
            if (!filesToSign || filesToSign.length === 0) {
                throw new Error(tl.loc('NoMatchingFiles', filesPattern));
            }
            for (const file of filesToSign) {
                if (zipalign) {
                    yield zipaligning(file);
                }
                if (apksign) {
                    yield apksigning(file);
                }
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
    });
}
run();

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const webClient = require("azure-arm-rest/webClient");
const pythonExtensionPrefix = "azureappservice-";
class KuduServiceUtils {
    constructor(kuduService) {
        this._appServiceKuduService = kuduService;
    }
    startContinuousWebJobs() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc('StartingContinousWebJobs'));
            var webJobs = yield this._appServiceKuduService.getContinuousJobs();
            for (var webJob of webJobs) {
                if (webJob.status.toLowerCase() == "running") {
                    console.log(tl.loc('WebJobAlreadyInRunningState', webJob.name));
                }
                else {
                    yield this._appServiceKuduService.startContinuousWebJob(webJob.name);
                }
            }
            console.log(tl.loc('StartedContinousWebJobs'));
        });
    }
    stopContinuousWebJobs() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc('StoppingContinousWebJobs'));
            var webJobs = yield this._appServiceKuduService.getContinuousJobs();
            for (var webJob of webJobs) {
                if (webJob.status.toLowerCase() == "stopped") {
                    console.log(tl.loc('WebJobAlreadyInStoppedState', webJob.name));
                }
                else {
                    yield this._appServiceKuduService.stopContinuousWebJob(webJob.name);
                }
            }
            console.log(tl.loc('StoppedContinousWebJobs'));
        });
    }
    installSiteExtensions(extensionList, outputVariables) {
        return __awaiter(this, void 0, void 0, function* () {
            outputVariables = outputVariables ? outputVariables : [];
            var outputVariableIterator = 0;
            var siteExtensions = yield this._appServiceKuduService.getSiteExtensions();
            var allSiteExtensions = yield this._appServiceKuduService.getAllSiteExtensions();
            var anyExtensionInstalled = false;
            var siteExtensionMap = {};
            var allSiteExtensionMap = {};
            var extensionLocalPaths = "";
            for (var siteExtension of siteExtensions) {
                siteExtensionMap[siteExtension.id] = siteExtension;
            }
            for (var siteExtension of allSiteExtensions) {
                allSiteExtensionMap[siteExtension.id] = siteExtension;
                allSiteExtensionMap[siteExtension.title] = siteExtension;
            }
            for (var extensionID of extensionList) {
                var siteExtensionDetails = null;
                if (allSiteExtensionMap[extensionID] && allSiteExtensionMap[extensionID].title == extensionID) {
                    extensionID = allSiteExtensionMap[extensionID].id;
                }
                // Python extensions are moved to Nuget and the extensions IDs are changed. The belo check ensures that old extensions are mapped to new extension ID.
                if (siteExtensionMap[extensionID] || (extensionID.startsWith('python') && siteExtensionMap[pythonExtensionPrefix + extensionID])) {
                    siteExtensionDetails = siteExtensionMap[extensionID] || siteExtensionMap[pythonExtensionPrefix + extensionID];
                    console.log(tl.loc('ExtensionAlreadyInstalled', extensionID));
                }
                else {
                    siteExtensionDetails = yield this._appServiceKuduService.installSiteExtension(extensionID);
                    anyExtensionInstalled = true;
                }
                var extensionLocalPath = this._getExtensionLocalPath(siteExtensionDetails);
                extensionLocalPaths += extensionLocalPath + ",";
                if (outputVariableIterator < outputVariables.length) {
                    tl.debug('Set output Variable ' + outputVariables[outputVariableIterator] + ' to value: ' + extensionLocalPath);
                    tl.setVariable(outputVariables[outputVariableIterator], extensionLocalPath);
                    outputVariableIterator += 1;
                }
            }
            tl.debug('Set output Variable LocalPathsForInstalledExtensions to value: ' + extensionLocalPaths.slice(0, -1));
            tl.setVariable("LocalPathsForInstalledExtensions", extensionLocalPaths.slice(0, -1));
            if (anyExtensionInstalled) {
                yield this.restart();
            }
        });
    }
    restart() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                console.log(tl.loc('RestartingKuduService'));
                var process0 = yield this._appServiceKuduService.getProcess(0);
                tl.debug(`Process 0 ID: ${process0.id}`);
                yield this._appServiceKuduService.killProcess(0);
                yield this._pollForNewProcess(0, process0.id);
                console.log(tl.loc('RestartedKuduService'));
            }
            catch (error) {
                throw Error(tl.loc('FailedToRestartKuduService', error.toString()));
            }
        });
    }
    updateDeploymentStatus(taskResult, DeploymentID, customMessage) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var requestBody = this._getUpdateHistoryRequest(taskResult, DeploymentID, customMessage);
                return yield this._appServiceKuduService.updateDeployment(requestBody);
            }
            catch (error) {
                tl.warning(error);
            }
        });
    }
    _pollForNewProcess(processID, id) {
        return __awaiter(this, void 0, void 0, function* () {
            var retryCount = 6;
            while (true) {
                try {
                    var process = yield this._appServiceKuduService.getProcess(processID);
                    tl.debug(`process ${processID} ID: ${process.id}`);
                    if (process.id != id) {
                        tl.debug(`New Process created`);
                        return process;
                    }
                }
                catch (error) {
                    tl.debug(`error while polling for process ${processID}: ` + error.toString());
                }
                retryCount -= 1;
                if (retryCount == 0) {
                    throw new Error(tl.loc('TimeoutWhileWaiting'));
                }
                tl.debug(`sleep for 5 seconds`);
                yield webClient.sleepFor(5);
            }
        });
    }
    _getExtensionLocalPath(extensionInfo) {
        var extensionId = extensionInfo['id'].replace(pythonExtensionPrefix, "");
        var homeDir = "D:\\home\\";
        if (extensionId.startsWith('python2')) {
            return homeDir + "Python27";
        }
        else if (extensionId.startsWith('python351') || extensionId.startsWith('python352')) {
            return homeDir + "Python35";
        }
        else if (extensionId.startsWith('python3')) {
            return homeDir + extensionId;
        }
        else {
            return extensionInfo['local_path'];
        }
    }
    _getUpdateHistoryRequest(isDeploymentSuccess, deploymentID, customMessage) {
        var status = isDeploymentSuccess ? 4 : 3;
        var author = tl.getVariable('build.sourceVersionAuthor') || tl.getVariable('build.requestedfor') ||
            tl.getVariable('release.requestedfor') || tl.getVariable('agent.name');
        var buildUrl = tl.getVariable('build.buildUri');
        var releaseUrl = tl.getVariable('release.releaseUri');
        var buildId = tl.getVariable('build.buildId');
        var releaseId = tl.getVariable('release.releaseId');
        var buildNumber = tl.getVariable('build.buildNumber');
        var releaseName = tl.getVariable('release.releaseName');
        var collectionUrl = tl.getVariable('system.TeamFoundationCollectionUri');
        var teamProject = tl.getVariable('system.teamProjectId');
        var commitId = tl.getVariable('build.sourceVersion');
        var repoName = tl.getVariable('build.repository.name');
        var repoProvider = tl.getVariable('build.repository.provider');
        var buildOrReleaseUrl = "";
        deploymentID = !!deploymentID ? deploymentID : (releaseId ? releaseId : buildId) + Date.now().toString();
        if (releaseUrl !== undefined) {
            buildOrReleaseUrl = collectionUrl + teamProject + "/_apps/hub/ms.vss-releaseManagement-web.hub-explorer?releaseId=" + releaseId + "&_a=release-summary";
        }
        else if (buildUrl !== undefined) {
            buildOrReleaseUrl = collectionUrl + teamProject + "/_build?buildId=" + buildId + "&_a=summary";
        }
        var message = {
            type: customMessage ? customMessage.type : "",
            commitId: commitId,
            buildId: buildId,
            releaseId: releaseId,
            buildNumber: buildNumber,
            releaseName: releaseName,
            repoProvider: repoProvider,
            repoName: repoName,
            collectionUrl: collectionUrl,
            teamProject: teamProject
        };
        // Append Custom Messages to original message
        for (var attribute in customMessage) {
            message[attribute] = customMessage[attribute];
        }
        var deploymentLogType = message['type'];
        var active = false;
        if (deploymentLogType.toLowerCase() === "deployment" && isDeploymentSuccess) {
            active = true;
        }
        return {
            id: deploymentID,
            active: active,
            status: status,
            message: JSON.stringify(message),
            author: author,
            deployer: 'VSTS',
            details: buildOrReleaseUrl
        };
    }
}
exports.KuduServiceUtils = KuduServiceUtils;

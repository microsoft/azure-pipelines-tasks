"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const webClient = require("azure-arm-rest/webClient");
var parseString = require('xml2js').parseString;
const Q = require("q");
const azure_arm_app_service_kudu_1 = require("azure-arm-rest/azure-arm-app-service-kudu");
class AzureAppServiceUtils {
    constructor(appService) {
        this._appService = appService;
    }
    monitorApplicationState(state) {
        return __awaiter(this, void 0, void 0, function* () {
            state = state.toLowerCase();
            if (["running", "stopped"].indexOf(state) == -1) {
                throw new Error(tl.loc('InvalidMonitorAppState', state));
            }
            while (true) {
                var appDetails = yield this._appService.get(true);
                if (appDetails && appDetails.properties && appDetails.properties["state"]) {
                    tl.debug(`App Service state: ${appDetails.properties["state"]}`);
                    if (appDetails.properties["state"].toLowerCase() == state) {
                        tl.debug(`App Service state '${appDetails.properties["state"]}' matched with expected state '${state}'.`);
                        console.log(tl.loc('AppServiceState', appDetails.properties["state"]));
                        break;
                    }
                    yield webClient.sleepFor(5);
                }
                else {
                    tl.debug('Unable to monitor app service details as the state is unknown.');
                    break;
                }
            }
        });
    }
    getWebDeployPublishingProfile() {
        return __awaiter(this, void 0, void 0, function* () {
            var publishingProfile = yield this._appService.getPublishingProfileWithSecrets();
            var defer = Q.defer();
            parseString(publishingProfile, (error, result) => {
                for (var index in result.publishData.publishProfile) {
                    if (result.publishData.publishProfile[index].$.publishMethod === "MSDeploy") {
                        defer.resolve(result.publishData.publishProfile[index].$);
                    }
                }
                defer.reject(tl.loc('ErrorNoSuchDeployingMethodExists'));
            });
            return defer.promise;
        });
    }
    pingApplication() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var applicationUrl = (yield this.getWebDeployPublishingProfile()).destinationAppUrl;
                if (!applicationUrl) {
                    tl.debug('Application Url not found.');
                    return;
                }
                var webRequest = new webClient.WebRequest();
                webRequest.method = 'GET';
                webRequest.uri = applicationUrl;
                tl.debug('pausing for 5 seconds before request');
                yield webClient.sleepFor(5);
                var response = yield webClient.sendRequest(webRequest);
                tl.debug(`App Service status Code: '${response.statusCode}'. Status Message: '${response.statusMessage}'`);
            }
            catch (error) {
                tl.debug(`Unable to ping App Service. Error: ${error}`);
            }
        });
    }
    getKuduService() {
        return __awaiter(this, void 0, void 0, function* () {
            var publishingCredentials = yield this._appService.getPublishingCredentials();
            if (publishingCredentials.properties["scmUri"]) {
                tl.setVariable(`AZURE_APP_SERVICE_KUDU_${this._appService.getSlot()}_PASSWORD`, publishingCredentials.properties["publishingPassword"], true);
                return new azure_arm_app_service_kudu_1.Kudu(publishingCredentials.properties["scmUri"], publishingCredentials.properties["publishingUserName"], publishingCredentials.properties["publishingPassword"]);
            }
            throw Error(tl.loc('KuduSCMDetailsAreEmpty'));
        });
    }
}
exports.AzureAppServiceUtils = AzureAppServiceUtils;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const azure_arm_endpoint_1 = require("azure-arm-rest/azure-arm-endpoint");
const azure_arm_app_service_1 = require("azure-arm-rest/azure-arm-app-service");
const azure_arm_appinsights_1 = require("azure-arm-rest/azure-arm-appinsights");
const AzureAppServiceUtils_1 = require("./operations/AzureAppServiceUtils");
const KuduServiceUtils_1 = require("./operations/KuduServiceUtils");
const AzureResourceFilterUtils_1 = require("./operations/AzureResourceFilterUtils");
const ContinuousMonitoringUtils_1 = require("./operations/ContinuousMonitoringUtils");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            var connectedServiceName = tl.getInput('ConnectedServiceName', true);
            var action = tl.getInput('Action', true);
            var webAppName = tl.getInput('WebAppName', true);
            var resourceGroupName = tl.getInput('ResourceGroupName', false);
            var specifySlotFlag = tl.getBoolInput('SpecifySlot', false);
            var slotName = specifySlotFlag ? tl.getInput('Slot', false) : null;
            var appInsightsResourceGroupName = tl.getInput('AppInsightsResourceGroupName', false);
            var appInsightsResourceName = tl.getInput('ApplicationInsightsResourceName', false);
            var sourceSlot = tl.getInput('SourceSlot', false);
            var swapWithProduction = tl.getBoolInput('SwapWithProduction', false);
            var targetSlot = tl.getInput('TargetSlot', false);
            var preserveVnet = tl.getBoolInput('PreserveVnet', false);
            var extensionList = tl.getInput('ExtensionsList', false);
            var extensionOutputVariables = tl.getInput('OutputVariable');
            var appInsightsWebTestName = tl.getInput('ApplicationInsightsWebTestName', false);
            var taskResult = true;
            var errorMessage = "";
            var updateDeploymentStatus = true;
            var azureEndpoint = yield new azure_arm_endpoint_1.AzureRMEndpoint(connectedServiceName).getEndpoint();
            var endpointTelemetry = '{"endpointId":"' + connectedServiceName + '"}';
            console.log("##vso[telemetry.publish area=TaskEndpointId;feature=AzureAppServiceManage]" + endpointTelemetry);
            if (action != "Swap Slots" && !slotName) {
                resourceGroupName = yield AzureResourceFilterUtils_1.AzureResourceFilterUtils.getResourceGroupName(azureEndpoint, 'Microsoft.Web/Sites', webAppName);
            }
            tl.debug(`Resource Group: ${resourceGroupName}`);
            var appService = new azure_arm_app_service_1.AzureAppService(azureEndpoint, resourceGroupName, webAppName, slotName);
            var azureAppServiceUtils = new AzureAppServiceUtils_1.AzureAppServiceUtils(appService);
            switch (action) {
                case "Start Azure App Service": {
                    yield appService.start();
                    yield azureAppServiceUtils.monitorApplicationState("running");
                    yield azureAppServiceUtils.pingApplication();
                    break;
                }
                case "Stop Azure App Service": {
                    yield appService.stop();
                    yield azureAppServiceUtils.monitorApplicationState("stopped");
                    break;
                }
                case "Restart Azure App Service": {
                    yield appService.restart();
                    yield azureAppServiceUtils.pingApplication();
                    break;
                }
                case "Swap Slots": {
                    targetSlot = (swapWithProduction) ? "production" : targetSlot;
                    var appServiceSourceSlot = new azure_arm_app_service_1.AzureAppService(azureEndpoint, resourceGroupName, webAppName, sourceSlot);
                    var appServiceTargetSlot = new azure_arm_app_service_1.AzureAppService(azureEndpoint, resourceGroupName, webAppName, targetSlot);
                    var appServiceSourceSlotUtils = new AzureAppServiceUtils_1.AzureAppServiceUtils(appServiceSourceSlot);
                    var appServiceTargetSlotUtils = new AzureAppServiceUtils_1.AzureAppServiceUtils(appServiceTargetSlot);
                    if (appServiceSourceSlot.getSlot().toLowerCase() == appServiceTargetSlot.getSlot().toLowerCase()) {
                        updateDeploymentStatus = false;
                        throw new Error(tl.loc('SourceAndTargetSlotCannotBeSame'));
                    }
                    console.log(tl.loc('WarmingUpSlots'));
                    try {
                        yield Promise.all([appServiceSourceSlotUtils.pingApplication(), appServiceTargetSlotUtils.pingApplication()]);
                    }
                    catch (error) {
                        tl.debug('Failed to warm-up slots. Error: ' + error);
                    }
                    yield appServiceSourceSlot.swap(targetSlot, preserveVnet);
                    break;
                }
                case "Start all continuous webjobs": {
                    var appServiceKuduService = yield azureAppServiceUtils.getKuduService();
                    var kuduServiceUtils = new KuduServiceUtils_1.KuduServiceUtils(appServiceKuduService);
                    yield kuduServiceUtils.startContinuousWebJobs();
                    break;
                }
                case "Stop all continuous webjobs": {
                    var appServiceKuduService = yield azureAppServiceUtils.getKuduService();
                    var kuduServiceUtils = new KuduServiceUtils_1.KuduServiceUtils(appServiceKuduService);
                    yield kuduServiceUtils.stopContinuousWebJobs();
                    break;
                }
                case "Install Extensions": {
                    var appServiceKuduService = yield azureAppServiceUtils.getKuduService();
                    var kuduServiceUtils = new KuduServiceUtils_1.KuduServiceUtils(appServiceKuduService);
                    var extensionOutputVariablesArray = (extensionOutputVariables) ? extensionOutputVariables.split(',') : [];
                    yield kuduServiceUtils.installSiteExtensions(extensionList.split(','), extensionOutputVariablesArray);
                    break;
                }
                case "Enable Continuous Monitoring": {
                    var appInsights = new azure_arm_appinsights_1.AzureApplicationInsights(azureEndpoint, appInsightsResourceGroupName, appInsightsResourceName);
                    yield ContinuousMonitoringUtils_1.enableContinuousMonitoring(azureEndpoint, appService, appInsights, appInsightsWebTestName);
                    break;
                }
                default: {
                    throw Error(tl.loc('InvalidAction'));
                }
            }
        }
        catch (exception) {
            taskResult = false;
            errorMessage = exception;
        }
        tl.debug('Completed action');
        try {
            switch (action) {
                case "Swap Slots": {
                    if (appServiceSourceSlotUtils && appServiceTargetSlotUtils && updateDeploymentStatus) {
                        var sourceSlotKuduService = yield appServiceSourceSlotUtils.getKuduService();
                        var targetSlotKuduService = yield appServiceTargetSlotUtils.getKuduService();
                        var sourceSlotKuduServiceUtils = new KuduServiceUtils_1.KuduServiceUtils(sourceSlotKuduService);
                        var targetSlotKuduServiceUtils = new KuduServiceUtils_1.KuduServiceUtils(targetSlotKuduService);
                        var customMessage = {
                            'type': 'SlotSwap',
                            'sourceSlot': appServiceSourceSlot.getSlot(),
                            'targetSlot': appServiceTargetSlot.getSlot()
                        };
                        var DeploymentID = yield sourceSlotKuduServiceUtils.updateDeploymentStatus(taskResult, null, customMessage);
                        yield targetSlotKuduServiceUtils.updateDeploymentStatus(taskResult, DeploymentID, customMessage);
                    }
                    break;
                }
                case "Install Extensions": {
                    if (kuduServiceUtils) {
                        yield kuduServiceUtils.updateDeploymentStatus(taskResult, null, { "type": action });
                    }
                    break;
                }
                default: {
                    tl.debug(`deployment status not updated for action: ${action}`);
                }
            }
        }
        catch (error) {
            tl.debug(error);
        }
        if (!taskResult) {
            tl.setResult(tl.TaskResult.Failed, errorMessage);
        }
    });
}
run();

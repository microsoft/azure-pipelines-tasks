"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
class AzureApplicationInsightsWebTestsUtils {
    constructor(applicationInsightsWebTests) {
        this._webTestData = {
            "name": "",
            "location": "",
            "tags": {},
            "type": "microsoft.insights/webtests",
            "properties": {
                "SyntheticMonitorId": "",
                "Name": "",
                "Description": "",
                "Enabled": true,
                "Frequency": 300,
                "Timeout": 120,
                "Kind": "ping",
                "RetryEnabled": true,
                "Locations": [
                    {
                        "Id": "us-tx-sn1-azr"
                    },
                    {
                        "Id": "us-il-ch1-azr"
                    },
                    {
                        "Id": "us-ca-sjc-azr"
                    },
                    {
                        "Id": "us-va-ash-azr"
                    },
                    {
                        "Id": "us-fl-mia-edge"
                    }
                ],
                "Configuration": {
                    "WebTest": "<WebTest Name=\"{WEB_TEST_NAME}\" Enabled=\"True\" CssProjectStructure=\"\"  CssIteration=\"\"  Timeout=\"120\"  WorkItemIds=\"\"  xmlns=\"http://microsoft.com/schemas/VisualStudio/TeamTest/2010\" Description=\"\" CredentialUserName=\"\" CredentialPassword=\"\" PreAuthenticate=\"True\" Proxy=\"default\" StopOnError=\"False\" RecordedResultFile=\"\" ResultsLocale=\"\"> <Items> <Request Method=\"GET\"  Version=\"1.1\"  Url=\"{APPLICATION_URL}\"  ThinkTime=\"0\" Timeout=\"120\" ParseDependentRequests=\"True\" FollowRedirects=\"True\"         RecordResult=\"True\"         Cache=\"False\" ResponseTimeGoal=\"0\" Encoding=\"utf-8\"  ExpectedHttpStatusCode=\"200\" ExpectedResponseUrl=\"\"  ReportingName=\"\" IgnoreHttpStatusCode=\"False\" /></Items></WebTest>"
                }
            }
        };
        this._applicationInsightsWebTests = applicationInsightsWebTests;
    }
    addWebTest(appInsightsResource, applicationUrl, testName) {
        return __awaiter(this, void 0, void 0, function* () {
            let webTests = yield this._applicationInsightsWebTests.list();
            for (let webTest of webTests) {
                let isTagPresent = false;
                let isApplicationUrlPresent = false;
                for (let tag in webTest.tags) {
                    if (tag.toLowerCase().indexOf(appInsightsResource.id.toLowerCase()) != -1) {
                        isTagPresent = true;
                        break;
                    }
                }
                isApplicationUrlPresent = webTest.properties['Configuration'].WebTest.toLowerCase().indexOf(applicationUrl.toLowerCase()) != -1;
                if (isTagPresent && isApplicationUrlPresent) {
                    console.log(tl.loc('WebTestAlreadyConfigured', applicationUrl));
                    return;
                }
            }
            yield this.create(appInsightsResource, applicationUrl, testName);
        });
    }
    create(appInsightsResource, applicationUrl, testName) {
        return __awaiter(this, void 0, void 0, function* () {
            let webTestData = this.configureNewWebTest(appInsightsResource, applicationUrl, testName);
            yield this._applicationInsightsWebTests.create(webTestData);
        });
    }
    configureNewWebTest(appInsightsResource, applicationUrl, testName) {
        let webTestName = testName ? testName : "vsts-web-test-" + Date.now();
        let webTestData = JSON.parse(JSON.stringify(this._webTestData));
        webTestData.name = webTestName;
        webTestData.properties.Name = webTestName;
        webTestData.properties.SyntheticMonitorId = webTestName;
        webTestData.location = appInsightsResource.location;
        webTestData.tags["hidden-link:" + appInsightsResource.id] = "Resource";
        webTestData.properties.Configuration.WebTest = webTestData.properties.Configuration.WebTest.replace("{WEB_TEST_NAME}", webTestName);
        webTestData.properties.Configuration.WebTest = webTestData.properties.Configuration.WebTest.replace("{APPLICATION_URL}", applicationUrl);
        return webTestData;
    }
}
exports.AzureApplicationInsightsWebTestsUtils = AzureApplicationInsightsWebTestsUtils;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const azure_arm_appinsights_webtests_1 = require("azure-arm-rest/azure-arm-appinsights-webtests");
const AzureAppServiceUtils_1 = require("./AzureAppServiceUtils");
const AzureApplicationInsightsWebTestsUtils_1 = require("./AzureApplicationInsightsWebTestsUtils");
const APPLICATION_INSIGHTS_EXTENSION_NAME = "Microsoft.ApplicationInsights.AzureWebSites";
function enableContinuousMonitoring(endpoint, appService, appInsights, testName) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(tl.loc('EnablingContinousMonitoring', appService.getName()));
            var appDetails = yield appService.get();
            var appServiceUtils = new AzureAppServiceUtils_1.AzureAppServiceUtils(appService);
            var appInsightsResource = yield appInsights.get();
            var appInsightsWebTests = new azure_arm_appinsights_webtests_1.ApplicationInsightsWebTests(endpoint, appInsights.getResourceGroupName());
            var webDeployPublishingProfile = yield appServiceUtils.getWebDeployPublishingProfile();
            var applicationUrl = webDeployPublishingProfile.destinationAppUrl;
            if (appDetails.kind.indexOf("linux") == -1) {
                var appKuduService = yield appServiceUtils.getKuduService();
                yield appKuduService.installSiteExtension(APPLICATION_INSIGHTS_EXTENSION_NAME);
            }
            appInsightsResource.tags["hidden-link:" + appDetails.id] = "Resource";
            tl.debug('Link app insights with app service via tag');
            yield appInsights.update(appInsightsResource);
            tl.debug('Link app service with app insights via instrumentation key');
            yield appService.patchApplicationSettings({
                "APPINSIGHTS_INSTRUMENTATIONKEY": appInsightsResource.properties['InstrumentationKey']
            });
            try {
                tl.debug('Enable alwaysOn property for app service.');
                yield appService.patchConfiguration({ "properties": { "alwaysOn": true } });
            }
            catch (error) {
                tl.warning(error);
            }
            try {
                tl.debug('add web test for app service - app insights');
                var appInsightsWebTestsUtils = new AzureApplicationInsightsWebTestsUtils_1.AzureApplicationInsightsWebTestsUtils(appInsightsWebTests);
                yield appInsightsWebTestsUtils.addWebTest(appInsightsResource, applicationUrl, testName);
            }
            catch (error) {
                tl.warning(error);
            }
            console.log(tl.loc("ContinousMonitoringEnabled", appService.getName()));
        }
        catch (error) {
            throw new Error(tl.loc('FailedToEnableContinuousMonitoring', error));
        }
    });
}
exports.enableContinuousMonitoring = enableContinuousMonitoring;

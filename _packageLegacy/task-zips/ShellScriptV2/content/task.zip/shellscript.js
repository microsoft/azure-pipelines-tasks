/// <reference path="typings/index.d.ts" />
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const path = require('path');
const tl = require('vsts-task-lib/task');
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            var bash = tl.tool(tl.which('bash', true));
            var scriptPath = tl.getPathInput('scriptPath', true, true);
            var cwd = tl.getPathInput('cwd', true, false);
            // if user didn't supply a cwd (advanced), then set cwd to folder script is in.
            // All "script" tasks should do this
            if (!tl.filePathSupplied('cwd') && !tl.getBoolInput('disableAutoCwd', false)) {
                cwd = path.dirname(scriptPath);
            }
            tl.mkdirP(cwd);
            tl.cd(cwd);
            bash.arg(scriptPath);
            // additional args should always call argString.  argString() parses quoted arg strings
            bash.line(tl.getInput('args', false));
            // determines whether output to stderr will fail a task.
            // some tools write progress and other warnings to stderr.  scripts can also redirect.
            var failOnStdErr = tl.getBoolInput('failOnStandardError', false);
            var code = yield bash.exec({ failOnStdErr: failOnStdErr });
            tl.setResult(tl.TaskResult.Succeeded, tl.loc('BashReturnCode', code));
        }
        catch (err) {
            tl.error(err.message);
            tl.setResult(tl.TaskResult.Failed, tl.loc('BashFailed', err.message));
        }
    });
}
run();

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const keyVaultTaskParameters = require("./models/KeyVaultTaskParameters");
const keyVault = require("./operations/KeyVault");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            var taskManifestPath = path.join(__dirname, "task.json");
            tl.debug("Setting resource path to " + taskManifestPath);
            tl.setResourcePath(taskManifestPath);
            var secretsToErrorsMap = new keyVault.SecretsToErrorsMapping();
            var taskParameters = new keyVaultTaskParameters.KeyVaultTaskParameters();
            var KeyVaultController = new keyVault.KeyVault(taskParameters);
            yield KeyVaultController.downloadSecrets(secretsToErrorsMap);
            if (!secretsToErrorsMap.isEmpty()) {
                tl.setResult(tl.TaskResult.Failed, secretsToErrorsMap.getAllErrors());
            }
            else {
                tl.setResult(tl.TaskResult.Succeeded, "");
            }
        }
        catch (error) {
            tl.setResult(tl.TaskResult.Failed, error);
        }
    });
}
run();

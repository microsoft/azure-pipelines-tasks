"use strict";
/// <reference path="../typings/index.d.ts" />
Object.defineProperty(exports, "__esModule", { value: true });
const msRestAzure = require("azure-arm-rest/azure-arm-common");
const tl = require("vsts-task-lib/task");
const util = require("util");
class KeyVaultTaskParameters {
    constructor() {
        var connectedService = tl.getInput("ConnectedServiceName", true);
        this.subscriptionId = tl.getEndpointDataParameter(connectedService, "SubscriptionId", true);
        this.keyVaultName = tl.getInput("KeyVaultName", true);
        this.secretsFilter = tl.getDelimitedInput("SecretsFilter", ",", true);
        var azureKeyVaultDnsSuffix = tl.getEndpointDataParameter(connectedService, "AzureKeyVaultDnsSuffix", true);
        this.servicePrincipalId = tl.getEndpointAuthorizationParameter(connectedService, 'serviceprincipalid', true);
        this.keyVaultUrl = util.format("https://%s.%s", this.keyVaultName, azureKeyVaultDnsSuffix);
        this.scheme = tl.getEndpointAuthorizationScheme(connectedService, false);
        this.vaultCredentials = this.getVaultCredentials(connectedService, azureKeyVaultDnsSuffix);
    }
    getVaultCredentials(connectedService, azureKeyVaultDnsSuffix) {
        var vaultUrl = util.format("https://%s", azureKeyVaultDnsSuffix);
        var servicePrincipalKey = tl.getEndpointAuthorizationParameter(connectedService, 'serviceprincipalkey', true);
        var tenantId = tl.getEndpointAuthorizationParameter(connectedService, 'tenantid', false);
        var armUrl = tl.getEndpointUrl(connectedService, true);
        var envAuthorityUrl = tl.getEndpointDataParameter(connectedService, 'environmentAuthorityUrl', true);
        envAuthorityUrl = (envAuthorityUrl != null) ? envAuthorityUrl : "https://login.windows.net/";
        var msiClientId = tl.getEndpointDataParameter(connectedService, 'msiclientId', true);
        var credentials = new msRestAzure.ApplicationTokenCredentials(this.servicePrincipalId, tenantId, servicePrincipalKey, vaultUrl, envAuthorityUrl, vaultUrl, false, this.scheme, msiClientId);
        return credentials;
    }
}
exports.KeyVaultTaskParameters = KeyVaultTaskParameters;

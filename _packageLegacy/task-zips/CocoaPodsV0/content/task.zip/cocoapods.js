"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
// The CocoaPods install command is documented here:
// https://guides.cocoapods.org/terminal/commands.html#pod_install
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Set path to resource strings
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // Change to configured working directory
            tl.cd(tl.getPathInput('cwd', true, true));
            // Set locale to UTF-8
            tl.debug('Setting locale to UTF8 as required by CocoaPods');
            process.env['LC_ALL'] = 'en_US.UTF-8';
            // Locate the CocoaPods 'pod' command
            var podPath = tl.which('pod');
            if (!podPath) {
                throw new Error(tl.loc('CocoaPodsNotFound'));
            }
            // Prepare to run 'pod install'
            var pod = tl.tool(podPath);
            pod.arg('install');
            // Force updating the pod repo before install?
            if (tl.getBoolInput('forceRepoUpdate', true)) {
                pod.arg('--repo-update');
            }
            // Explicitly specify a project directory?
            if (tl.filePathSupplied('projectDirectory')) {
                var projectDirectory = tl.getPathInput('projectDirectory', false, true);
                pod.arg('--project-directory=' + projectDirectory);
            }
            // Execute
            var returnCode = yield pod.exec();
            // Get the result code and set the task result accordingly
            tl.setResult(tl.TaskResult.Succeeded, tl.loc('PodReturnCode', returnCode));
        }
        catch (err) {
            // Report failure
            tl.error(err.message);
            tl.setResult(tl.TaskResult.Failed, tl.loc('PodFailed', err.message));
        }
    });
}
run();

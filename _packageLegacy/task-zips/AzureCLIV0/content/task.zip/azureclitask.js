"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const path = require("path");
const tl = require("vsts-task-lib/task");
const fs = require("fs");
const util = require("util");
const os = require("os");
class azureclitask {
    static runMain() {
        return __awaiter(this, void 0, void 0, function* () {
            var toolExecutionError = null;
            try {
                tl.setResourcePath(path.join(__dirname, "task.json"));
                var tool;
                if (os.type() != "Windows_NT") {
                    tool = tl.tool(tl.which("bash", true));
                }
                var scriptLocation = tl.getInput("scriptLocation");
                var scriptPath = null;
                var cwd = tl.getPathInput("cwd", true, false);
                if (scriptLocation === "scriptPath") {
                    scriptPath = tl.getPathInput("scriptPath", true, true);
                    // if user didn"t supply a cwd (advanced), then set cwd to folder script is in.
                    // All "script" tasks should do this
                    if (!tl.filePathSupplied("cwd")) {
                        cwd = path.dirname(scriptPath);
                    }
                }
                else {
                    var script = tl.getInput("inlineScript", true);
                    if (os.type() != "Windows_NT") {
                        scriptPath = path.join(os.tmpdir(), "azureclitaskscript" + new Date().getTime() + ".sh");
                    }
                    else {
                        scriptPath = path.join(os.tmpdir(), "azureclitaskscript" + new Date().getTime() + ".bat");
                    }
                    this.createFile(scriptPath, script);
                }
                var args = tl.getInput("args", false);
                // determines whether output to stderr will fail a task.
                // some tools write progress and other warnings to stderr.  scripts can also redirect.
                var failOnStdErr = tl.getBoolInput("failOnStandardError", false);
                tl.mkdirP(cwd);
                tl.cd(cwd);
                if (os.type() != "Windows_NT") {
                    tool.arg(scriptPath);
                }
                else {
                    tool = tl.tool(tl.which(scriptPath, true));
                }
                var connectedServiceNameSelector = tl.getInput("connectedServiceNameSelector", true);
                this.loginAzure(connectedServiceNameSelector);
                tool.line(args); // additional args should always call line. line() parses quoted arg strings
                yield tool.exec({ failOnStdErr: failOnStdErr });
            }
            catch (err) {
                if (err.stderr) {
                    toolExecutionError = err.stderr;
                }
                else {
                    toolExecutionError = err;
                }
            }
            finally {
                if (scriptLocation === "inlineScript") {
                    this.deleteFile(scriptPath);
                }
                //Logout of Azure if logged in
                if (this.isLoggedIn) {
                    this.logoutAzure(connectedServiceNameSelector);
                }
                //set the task result to either succeeded or failed based on error was thrown or not
                if (toolExecutionError) {
                    tl.setResult(tl.TaskResult.Failed, tl.loc("ScriptFailed", toolExecutionError));
                }
                else {
                    tl.setResult(tl.TaskResult.Succeeded, tl.loc("ScriptReturnCode", 0));
                }
            }
        });
    }
    static loginAzure(connectedServiceNameSelector) {
        var connectedService;
        if (connectedServiceNameSelector === "connectedServiceNameARM") {
            connectedService = tl.getInput("connectedServiceNameARM", true);
            this.loginAzureRM(connectedService);
        }
        else {
            connectedService = tl.getInput("connectedServiceName", true);
            this.loginAzureClassic(connectedService);
        }
    }
    static loginAzureRM(connectedService) {
        var endpointAuth = tl.getEndpointAuthorization(connectedService, true);
        var servicePrincipalId = endpointAuth.parameters["serviceprincipalid"];
        var servicePrincipalKey = endpointAuth.parameters["serviceprincipalkey"];
        var tenantId = endpointAuth.parameters["tenantid"];
        var subscriptionName = tl.getEndpointDataParameter(connectedService, "SubscriptionName", true);
        //set the azure mode to arm to use azureRM commands
        this.throwIfError(tl.execSync("azure", "config mode arm"));
        //login using svn
        this.throwIfError(tl.execSync("azure", "login -u \"" + servicePrincipalId + "\" -p \"" + servicePrincipalKey + "\" --tenant \"" + tenantId + "\" --service-principal"));
        this.isLoggedIn = true;
        //set the subscription imported to the current subscription
        this.throwIfError(tl.execSync("azure", "account set \"" + subscriptionName + "\""));
    }
    static loginAzureClassic(connectedService) {
        var endpointAuth = tl.getEndpointAuthorization(connectedService, true);
        var subscriptionName = tl.getEndpointDataParameter(connectedService, "SubscriptionName", true);
        //set the azure mode to asm to use azureRM commands
        this.throwIfError(tl.execSync("azure", "config mode asm"));
        if (endpointAuth.scheme === "Certificate") {
            var bytes = endpointAuth.parameters["certificate"];
            var subscriptionId = tl.getEndpointDataParameter(connectedService, "SubscriptionId", true);
            var serviceManagementUrl = tl.getEndpointUrl(connectedService, false);
            const publishSettingFileName = path.join(os.tmpdir(), "subscriptions" + new Date().getTime() + ".publishsettings");
            this.createPublishSettingFile(subscriptionName, subscriptionId, bytes, serviceManagementUrl, publishSettingFileName);
            var resultOfToolExecution = tl.execSync("azure", "account import \"" + publishSettingFileName + "\"");
            this.deleteFile(publishSettingFileName);
            this.throwIfError(resultOfToolExecution);
            this.isLoggedIn = true;
            //set the subscription imported to the current subscription
            this.throwIfError(tl.execSync("azure", "account set \"" + subscriptionName + "\""));
        }
        else if (endpointAuth.scheme === "UsernamePassword") {
            var username = endpointAuth.parameters["username"];
            var passwd = endpointAuth.parameters["password"];
            this.throwIfError(tl.execSync("azure", "login -u \"" + username + "\" -p \"" + passwd + "\""));
            this.isLoggedIn = true;
            //set the subscription imported to the current subscription
            this.throwIfError(tl.execSync("azure", "account set \"" + subscriptionName + "\""));
        }
        else {
            var err;
            err.stderr = tl.loc("UnsupportedEndpointScheme");
            throw (err);
        }
    }
    static logoutAzure(connectedServiceNameSelector) {
        try {
            var connectedService;
            if (connectedServiceNameSelector === "connectedServiceNameARM") {
                connectedService = tl.getInput("connectedServiceNameARM", true);
                this.logoutAzureRM(connectedService);
            }
            else {
                connectedService = tl.getInput("connectedServiceName", true);
                this.logoutAzureClassic(connectedService);
            }
        }
        catch (err) {
        }
    }
    static logoutAzureRM(connectedService) {
        var subscriptionName = tl.getEndpointDataParameter(connectedService, "SubscriptionName", true);
        tl.execSync("azure", " account clear -s \"" + subscriptionName + "\"");
    }
    static logoutAzureClassic(connectedService) {
        var endpointAuth = tl.getEndpointAuthorization(connectedService, true);
        if (endpointAuth["scheme"] === "usernamePassword") {
            var username = endpointAuth.parameters["username"];
            tl.execSync("azure", "logout -u \"" + username + "\"");
        }
        else {
            var subscriptionName = tl.getEndpointDataParameter(connectedService, "SubscriptionName", true);
            tl.execSync("azure", " account clear -s \"" + subscriptionName + "\"");
        }
    }
    static throwIfError(resultOfToolExecution) {
        if (resultOfToolExecution.stderr) {
            throw resultOfToolExecution;
        }
    }
    static createPublishSettingFile(subscriptionName, subscriptionId, certificate, serviceManagementUrl, publishSettingFileName) {
        //writing the data to the publishsetting file
        this.createFile(publishSettingFileName, util.format('<?xml version="1.0" encoding="utf-8"?><PublishData><PublishProfile SchemaVersion="2.0" PublishMethod="AzureServiceManagementAPI"><Subscription ServiceManagementUrl="%s" Id="%s" Name="%s" ManagementCertificate="%s" /> </PublishProfile></PublishData>', serviceManagementUrl, subscriptionId, subscriptionName, certificate));
    }
    static createFile(filePath, data) {
        try {
            fs.writeFileSync(filePath, data);
        }
        catch (err) {
            this.deleteFile(filePath);
            throw err;
        }
    }
    static deleteFile(filePath) {
        if (fs.existsSync(filePath)) {
            try {
                //delete the publishsetting file created earlier
                fs.unlinkSync(filePath);
            }
            catch (err) {
                //error while deleting should not result in task failure
                console.error(err.toString());
            }
        }
    }
}
azureclitask.isLoggedIn = false;
exports.azureclitask = azureclitask;
azureclitask.runMain();

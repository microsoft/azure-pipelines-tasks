"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const task = require("vsts-task-lib/task");
const azure_arm_mysql_1 = require("azure-arm-rest/azure-arm-mysql");
const MysqlServer_1 = require("../models/MysqlServer");
const Q = require("q");
class MysqlServerOperations {
    constructor(azureCredentials, subscriptionId) {
        this._azureMysqManagementClient = new azure_arm_mysql_1.AzureMysqlManagementClient(azureCredentials, subscriptionId);
    }
    /**
     * Get mysql server data from server name including resource group
     * @param serverName     mysql server name to get details
     *
     * @returns              mysql server details
     */
    getMysqlServerFromServerName(serverName) {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            this._azureMysqManagementClient.mysqlServers.list((error, result, request, response) => {
                if (error) {
                    task.debug("Error during fetching mysql severs list: " + error);
                    defer.reject(new Error(task.loc("NotAbleToGetAllServers", error)));
                }
                else {
                    try {
                        const mysqlServer = this._getMysqlServerFromResponse(result, serverName);
                        defer.resolve(mysqlServer);
                    }
                    catch (error) {
                        defer.reject(error);
                    }
                }
            });
            return defer.promise;
        });
    }
    /**
     * Filter mysqlServer data from list of mysql server in particular subscription
     * @param result      List of mysql server in a subscription
     * @param serverName  server name
     *
     * @returns           MysqlServer data
     */
    _getMysqlServerFromResponse(result, serverName) {
        let mysqlServer;
        if (result && result.length > 0) {
            result.forEach((resultObject) => {
                if (resultObject && resultObject.properties && resultObject.properties.fullyQualifiedDomainName === serverName) {
                    mysqlServer = new MysqlServer_1.MysqlServer(resultObject.name, resultObject.properties.fullyQualifiedDomainName, this._getResourceGroupNameFromUrl(resultObject.id));
                }
            });
        }
        else {
            task.debug("Mysql server list is empty or null.");
            throw new Error(task.loc("EmptyOrNullServerList"));
        }
        return mysqlServer;
    }
    /**
     * Get resource group name from mysql server url i.e Id
     */
    _getResourceGroupNameFromUrl(id) {
        if (!id) {
            throw new Error(task.loc("UnableToFindResourceGroupDueToNullId"));
        }
        const pathArray = id.split("/");
        if (pathArray[3] != 'resourceGroups') {
            throw new Error(task.loc("UnableToFindResourceGroupDueToInvalidId"));
        }
        return pathArray[4];
    }
}
exports.MysqlServerOperations = MysqlServerOperations;

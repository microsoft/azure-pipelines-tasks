"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
class FirewallRule {
    constructor(name, firewallAddressRange) {
        if (!name || typeof name.valueOf() !== 'string') {
            throw new Error(tl.loc("FirewallRuleNameCannotBeEmpty"));
        }
        if (!firewallAddressRange) {
            throw new Error(tl.loc("FirewallAddressRangeCannotBeEmpty"));
        }
        this.name = name;
        this.properties = firewallAddressRange;
    }
    getProperties() {
        return this.properties;
    }
    getName() {
        return this.name;
    }
}
exports.FirewallRule = FirewallRule;
class FirewallAddressRange {
    constructor(startIpAddress, endIpAddress) {
        if (!startIpAddress || typeof startIpAddress.valueOf() !== 'string') {
            throw new Error(tl.loc("StartIpAddressCannotBeEmpty"));
        }
        if (!endIpAddress || typeof endIpAddress.valueOf() !== 'string') {
            throw new Error(tl.loc("EndIpAddressCannotBeEmpty"));
        }
        this.startIpAddress = startIpAddress;
        this.endIpAddress = endIpAddress;
    }
    getEndIpAddress() {
        return this.endIpAddress;
    }
    getStartIpAddress() {
        return this.startIpAddress;
    }
}
exports.FirewallAddressRange = FirewallAddressRange;

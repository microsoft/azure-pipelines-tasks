"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const task = require("vsts-task-lib/task");
const path = require("path");
const AzureMysqlTaskParameter_1 = require("./models/AzureMysqlTaskParameter");
const FirewallOperations_1 = require("./operations/FirewallOperations");
const MysqlServerOperations_1 = require("./operations/MysqlServerOperations");
const ToolPathOperations_1 = require("./operations/ToolPathOperations");
const MysqlClient_1 = require("./sql/MysqlClient");
const azure_arm_endpoint_1 = require("azure-arm-rest/azure-arm-endpoint");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        let azureMysqlTaskParameter;
        let firewallAdded;
        let firewallOperations;
        let mysqlServer;
        try {
            task.debug('Task execution started');
            task.setResourcePath(path.join(__dirname, 'task.json'));
            // Get all task input parameters
            azureMysqlTaskParameter = new AzureMysqlTaskParameter_1.AzureMysqlTaskParameter();
            task.debug('parsed task inputs');
            const endpoint = yield new azure_arm_endpoint_1.AzureRMEndpoint(azureMysqlTaskParameter.getConnectedServiceName()).getEndpoint();
            var endpointTelemetry = '{"endpointId":"' + azureMysqlTaskParameter.getConnectedServiceName() + '"}';
            console.log("##vso[telemetry.publish area=TaskEndpointId;feature=AzureMysqlDeployment]" + endpointTelemetry);
            if (!endpoint) {
                throw new Error(task.loc("AzureEndpointCannotBeNull"));
            }
            const mysqlServerOperations = new MysqlServerOperations_1.MysqlServerOperations(endpoint.applicationTokenCredentials, endpoint.subscriptionID);
            // Get mysql server data entered by user 
            mysqlServer = yield mysqlServerOperations.getMysqlServerFromServerName(azureMysqlTaskParameter.getServerName());
            task.debug('Mysql server details from server name: ' + JSON.stringify(mysqlServer));
            const mysqlClientPath = yield new ToolPathOperations_1.ToolPathOperations().getInstalledPathOfMysql();
            if (mysqlClientPath) {
                // Mysql client
                const sqlClient = new MysqlClient_1.MysqlClient(azureMysqlTaskParameter, mysqlServer.getFullyQualifiedName(), mysqlClientPath);
                firewallOperations = new FirewallOperations_1.FirewallOperations(endpoint.applicationTokenCredentials, endpoint.subscriptionID);
                //Invoke firewall operation to validate user has permission for server or not. If not whitelist the IP
                firewallAdded = yield firewallOperations.invokeFirewallOperations(azureMysqlTaskParameter, sqlClient, mysqlServer);
                //Execute sql script entered by user
                yield sqlClient.executeSqlCommand();
            }
            else {
                throw new Error(task.loc("NotAbleToGetInstalledLocationOfMysqlFromPath"));
            }
        }
        catch (exception) {
            task.debug('Getting exception: ' + exception);
            task.setResult(task.TaskResult.Failed, exception);
        }
        finally {
            // Delete firewall rule in case of automatic added rule or either user wants to delete it
            if (firewallAdded && azureMysqlTaskParameter && azureMysqlTaskParameter.getDeleteFirewallRule()) {
                task.debug('Deleting firewall rule.');
                if (firewallOperations && mysqlServer) {
                    yield firewallOperations.deleteFirewallRule(mysqlServer.getName(), mysqlServer.getResourceGroupName());
                }
                task.debug('Sucessfully deleted firewall rule.');
            }
        }
        task.debug('Task completed.');
    });
}
run();

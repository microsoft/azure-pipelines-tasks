"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const task = require("vsts-task-lib/task");
const azure_arm_mysql_1 = require("azure-arm-rest/azure-arm-mysql");
const Firewall_1 = require("../models/Firewall");
const Q = require("q");
class FirewallOperations {
    constructor(azureCredentials, subscriptionId) {
        this._azureMysqManagementClient = new azure_arm_mysql_1.AzureMysqlManagementClient(azureCredentials, subscriptionId);
    }
    /**
     * Add firewall rule for particular mysql server
     * @param serverName          mysql server name
     * @param firewallRule        firewallRule i.e name and Ip Adress range
     * @param resourceGroupName   mysql server resource group name
     *
     * @returns operation is success or failure
     */
    addFirewallRule(serverName, firewallRule, resourceGroupName) {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            this._azureMysqManagementClient.firewallRules.createOrUpdate(resourceGroupName, serverName, firewallRule.getName(), firewallRule, (error, result, request, response) => {
                if (error) {
                    task.debug("Getting error during adding firewall rule: " + error);
                    defer.reject(new Error(task.loc("NotAbleToAddFirewallRule", error)));
                }
                else {
                    defer.resolve();
                }
            });
            return defer.promise;
        });
    }
    /**
     * Delete firewall rule for mysql server
     * @param serverName           mysql server name
     * @param resourceGroupName    mysql server resource group name
     *
     * @returns operation is success or failure
     */
    deleteFirewallRule(serverName, resourceGroupName) {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            this._azureMysqManagementClient.firewallRules.delete(resourceGroupName, serverName, this._firewallName, (error, result, request, response) => {
                if (error) {
                    task.debug("Getting error during deleting firewall rule: " + error);
                    defer.reject(new Error(task.loc("NotAbleToDeleteFirewallRule", error)));
                }
                else {
                    defer.resolve();
                }
            });
            return defer.promise;
        });
    }
    /**
     * To check agent box has permission to connect with mysqlServer or not. If not then add firewall rule to whitelist this IP.
     * @param azureMysqlTaskParameter    task input parameters
     * @param sqlClient                  mysql client
     * @param resourceGroupName          mysql server resource group name
     *
     * @returns                          firewall rule added or not
     */
    invokeFirewallOperations(azureMysqlTaskParameter, sqlClient, mysqlServer) {
        return __awaiter(this, void 0, void 0, function* () {
            var defer = Q.defer();
            if (azureMysqlTaskParameter.getIpDetectionMethod() === 'IPAddressRange') {
                this._preparefirewallRule(mysqlServer.getName(), azureMysqlTaskParameter.getStartIpAddress(), azureMysqlTaskParameter.getEndIpAddress(), mysqlServer.getResourceGroupName(), "IPAddressRange_" + this._getFirewallRuleName()).then(() => {
                    let firewallConfiguration = sqlClient.getFirewallConfiguration();
                    console.log(" firewall conf " + JSON.stringify(firewallConfiguration));
                    if (!firewallConfiguration.isIpAdressAlreadyAdded()) {
                        task.debug("Agent Ip address not in added firewall rule: " + firewallConfiguration.getIpAddress());
                        defer.reject(new Error(task.loc("AgentIpAddressIsMissingInAddedFirewallRule")));
                    }
                    else {
                        defer.resolve(true);
                    }
                }, (error) => {
                    task.debug("Error during adding firewall rule for IPAddressRange: " + error);
                    defer.reject(error);
                });
            }
            else {
                const firewallConfiguration = sqlClient.getFirewallConfiguration();
                if (!firewallConfiguration.isIpAdressAlreadyAdded()) {
                    this._preparefirewallRule(mysqlServer.getName(), firewallConfiguration.getIpAddress(), firewallConfiguration.getIpAddress(), mysqlServer.getResourceGroupName(), "AutoDetect_" + this._getFirewallRuleName()).then(() => {
                        defer.resolve(true);
                    }, (error) => {
                        task.debug("Error during adding firewall rule for IPAddressRange: " + error);
                        defer.reject(error);
                    });
                }
                else {
                    defer.resolve(false);
                }
            }
            return defer.promise;
        });
    }
    /**
     * Prepare firewall rule for mysql server
     */
    _preparefirewallRule(serverName, startIpAddress, endIpAddress, resourceGroupName, ruleName) {
        return __awaiter(this, void 0, void 0, function* () {
            var defer = Q.defer();
            this._firewallName = ruleName;
            const firewallAddressRange = new Firewall_1.FirewallAddressRange(startIpAddress, endIpAddress);
            const firewallRule = new Firewall_1.FirewallRule(this._firewallName, firewallAddressRange);
            this.addFirewallRule(serverName, firewallRule, resourceGroupName).then(() => {
                task.debug('Firewall configuration name added : ' + this._firewallName);
                defer.resolve();
            }, (error) => {
                defer.reject(error);
            });
            return defer.promise;
        });
    }
    _getFirewallRuleName() {
        let buildId = task.getVariable('build.buildId');
        let releaseId = task.getVariable('release.releaseId');
        let firewallRuleName = (releaseId ? releaseId : buildId) + Date.now().toString();
        return firewallRuleName;
    }
}
exports.FirewallOperations = FirewallOperations;

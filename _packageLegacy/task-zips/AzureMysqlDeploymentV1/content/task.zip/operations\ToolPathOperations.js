"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const task = require("vsts-task-lib/task");
var winreg = require('winreg');
const Q = require("q");
class ToolPathOperations {
    /**
     * Get installed path of mysql either it is linux or windows
     */
    getInstalledPathOfMysql() {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            // To check either it is linux or windows platform
            if (task.osType().match(/^Win/)) {
                this.getInstalledPathOfMysqlForWindow().then((path) => {
                    defer.resolve(path);
                }, (error) => {
                    task.debug("Error during window mysql path finding: " + error);
                    defer.reject(task.loc("WindowMysqlClientMissingError"));
                });
            }
            else {
                // linux check
                this.getInstalledPathOfMysqlForLinux().then((path) => {
                    defer.resolve(path);
                }, (error) => {
                    task.debug("Error during linux mysql path finding: " + error);
                    defer.reject(task.loc("LinuxMysqlClientMissingError"));
                });
            }
            return defer.promise;
        });
    }
    /**
     * Get installed path of mysql for Linux
     */
    getInstalledPathOfMysqlForLinux() {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            try {
                const path = task.which("mysql", true);
                defer.resolve(path);
            }
            catch (error) {
                defer.reject(error);
            }
            return defer.promise;
        });
    }
    /**
    * Get installed path of mysql for windows
    */
    getInstalledPathOfMysqlForWindow() {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            // If user has installed 32 bit mysql client in 64 bit machine
            this.getInstalledLocationFromPath("\\Software\\Wow6432Node\\MySQL AB").then((path) => {
                task.debug('Window Wow6432 mysql executable path: ' + path);
                defer.resolve(path + "bin\\mysql.exe");
            }, (error) => {
                task.debug("Error during finding of Window Wow6432 mysql executable path: " + error);
                this.getInstalledLocationFromPath("\\Software\\MySQL AB").then((path) => {
                    task.debug('Window mysql executable path: ' + path);
                    defer.resolve(path + "bin\\mysql.exe");
                }, (error) => {
                    task.debug("Error during finding of Window mysql executable path: " + error);
                    try {
                        const path = task.which("mysql", true);
                        if (path) {
                            task.debug('Window mysql executable path from enviroment variable: ' + path);
                            defer.resolve(path);
                        }
                        else {
                            defer.reject(task.loc("NotAbleToGetInstalledLocationOfMysqlFromPath"));
                        }
                    }
                    catch (exception) {
                        task.debug("Error during finding of Window mysql executable path from environment path: " + exception);
                        defer.reject(task.loc("NotAbleToGetInstalledLocationOfMysqlFromPath"));
                    }
                });
            });
            return defer.promise;
        });
    }
    /**
     * Get installed location from path
     * @param path     path of window registry
     *
     * @returns        installed path
     */
    getInstalledLocationFromPath(path) {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            task.debug('Getting executable path of mysql client for registry path: ' + path);
            this._getToolRegKeyFromPath(path).then((regKey) => {
                this._getToolInstalledPathFromRegKey(regKey).then((installedPath) => {
                    defer.resolve(installedPath);
                }, (error) => {
                    defer.reject(error);
                });
            }, (error) => {
                defer.reject(error);
            });
            return defer.promise;
        });
    }
    /**
     * Get resgistry key from path
     * @param path  path of window registry
     *
     * @returns     registry key
     */
    _getToolRegKeyFromPath(path) {
        var defer = Q.defer();
        var regKey = new winreg({
            hive: winreg.HKLM,
            key: path
        });
        regKey.keys(function (err, subRegKeys) {
            if (err) {
                task.debug('Error during fetching registry key from path: ' + err);
                defer.reject(new Error(task.loc("UnableToFindMysqlFromRegistryOnMachineError", err)));
            }
            let resgistryKeyResult;
            if (subRegKeys) {
                for (var index in subRegKeys) {
                    let subRegKey = subRegKeys[index].key;
                    if (subRegKey.match("MySQL Server")) {
                        task.debug('Window mysql registry key: ' + subRegKey);
                        resgistryKeyResult = subRegKey;
                    }
                }
            }
            if (resgistryKeyResult) {
                defer.resolve(resgistryKeyResult);
            }
            else {
                defer.reject(new Error(task.loc("UnableToFindMysqlFromRegistry")));
            }
        });
        return defer.promise;
    }
    /**
     * Get installed path from registry key
     * @param registryKey   window registry key
     *
     * @returns             installed path
     */
    _getToolInstalledPathFromRegKey(registryKey) {
        var defer = Q.defer();
        var regKey = new winreg({
            hive: winreg.HKLM,
            key: registryKey
        });
        regKey.get("Location", function (err, item) {
            if (err) {
                task.debug('Error during fetching installed path from registry key: ' + err);
                defer.reject(new Error(task.loc("UnableToFindTheLocationOfMysqlFromRegistryOnMachineError", err)));
            }
            else {
                task.debug('Window mysql installed path from registry key: ' + item.value);
                defer.resolve(item.value);
            }
        });
        return defer.promise;
    }
}
exports.ToolPathOperations = ToolPathOperations;

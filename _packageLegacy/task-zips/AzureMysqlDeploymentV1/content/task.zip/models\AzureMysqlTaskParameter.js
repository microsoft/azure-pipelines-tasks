"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
class AzureMysqlTaskParameter {
    constructor() {
        try {
            this.connectedServiceName = tl.getInput('ConnectedServiceName', true);
            this.serverName = tl.getInput('ServerName', true);
            this.databaseName = tl.getInput('DatabaseName', false);
            this.sqlUserName = tl.getInput('SqlUsername', true);
            this.sqlPassword = tl.getInput('SqlPassword', true);
            this.taskNameSelector = tl.getInput('TaskNameSelector', true);
            this.sqlFile = tl.getInput('SqlFile', false);
            this.sqlInline = tl.getInput('SqlInline', false);
            this.sqlAdditionalArguments = tl.getInput('SqlAdditionalArguments', false);
            this.ipDetectionMethod = tl.getInput('IpDetectionMethod', false);
            this.startIpAddress = tl.getInput('StartIpAddress', false);
            this.endIpAddress = tl.getInput('EndIpAddress', false);
            this.deleteFirewallRule = tl.getBoolInput('DeleteFirewallRule', false);
        }
        catch (error) {
            throw new Error(tl.loc("ARGD_ConstructorFailed", error.message));
        }
    }
    getConnectedServiceName() {
        return this.connectedServiceName;
    }
    getServerName() {
        return this.serverName;
    }
    getDatabaseName() {
        return this.databaseName;
    }
    getSqlPassword() {
        return this.sqlPassword;
    }
    getSqlUserName() {
        return this.sqlUserName;
    }
    getTaskNameSelector() {
        return this.taskNameSelector;
    }
    getSqlFile() {
        return this.sqlFile;
    }
    getSqlInline() {
        return this.sqlInline;
    }
    getSqlAdditionalArguments() {
        return this.sqlAdditionalArguments;
    }
    getIpDetectionMethod() {
        return this.ipDetectionMethod;
    }
    getStartIpAddress() {
        return this.startIpAddress;
    }
    getEndIpAddress() {
        return this.endIpAddress;
    }
    getDeleteFirewallRule() {
        return this.deleteFirewallRule;
    }
}
exports.AzureMysqlTaskParameter = AzureMysqlTaskParameter;

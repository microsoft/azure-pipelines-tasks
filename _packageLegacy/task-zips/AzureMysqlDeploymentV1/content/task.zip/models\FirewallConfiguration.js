"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class FirewallConfiguration {
    constructor(ipAdressAlreadyAdded, iPAddress) {
        this.ipAdressAlreadyAdded = ipAdressAlreadyAdded;
        this.ipAddress = iPAddress;
    }
    isIpAdressAlreadyAdded() {
        return this.ipAdressAlreadyAdded;
    }
    getIpAddress() {
        return this.ipAddress;
    }
}
exports.FirewallConfiguration = FirewallConfiguration;

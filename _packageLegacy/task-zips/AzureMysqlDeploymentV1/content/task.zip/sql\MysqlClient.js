"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const FirewallConfiguration_1 = require("../models/FirewallConfiguration");
const MysqlUtiliy_1 = require("../operations/MysqlUtiliy");
const telemetry = require("utility-common/telemetry");
const task = require("vsts-task-lib/task");
var packageUtility = require('webdeployment-common/packageUtility.js');
const Q = require("q");
class MysqlClient {
    constructor(azureMysqlTaskParameter, serverName, toolPath) {
        if (!azureMysqlTaskParameter) {
            throw new Error(task.loc("AzureMysqlTaskParameterCannotBeEmpty"));
        }
        if (!serverName || typeof serverName.valueOf() !== 'string') {
            throw new Error(task.loc("MysqlServerNameCannotBeEmpty"));
        }
        if (!toolPath || typeof toolPath.valueOf() !== 'string') {
            throw new Error(task.loc("ToolPathCannotBeNull"));
        }
        this._azureMysqlTaskParameter = azureMysqlTaskParameter;
        this._hostName = serverName;
        this._toolPath = toolPath;
    }
    /**
     * Get Firewall configuration related to agent box
     */
    getFirewallConfiguration() {
        let firewallConfiguration = new FirewallConfiguration_1.FirewallConfiguration(true);
        // Regex to extract Ip Address from string
        const regexToGetIpAddress = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
        const result = task.execSync(this._toolPath, MysqlUtiliy_1.Utility.argStringToArray(this._getArgumentString() + " " + this._getAdditionalArgument()));
        task.debug('Mysql server connection check result: ' + JSON.stringify(result));
        // If agent is not whitelisted it will throw error with ip address 
        if (result && result.stderr) {
            var ipAddresses = result.stderr.match(regexToGetIpAddress);
            if (ipAddresses && ipAddresses.length > 0) {
                firewallConfiguration = new FirewallConfiguration_1.FirewallConfiguration(false, ipAddresses[0]);
            }
        }
        return firewallConfiguration;
    }
    /**
     * Get the connection argument for mysql
     */
    _getArgumentString() {
        let argumentString = "-h" + this._hostName + " -u" + this._azureMysqlTaskParameter.getSqlUserName() + " -p" + this._azureMysqlTaskParameter.getSqlPassword();
        return argumentString;
    }
    /**
     * Execute Mysql script
     */
    executeSqlCommand() {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            let argument = this._getArgumentString() + " " + this._getAdditionalArgument();
            let additionalArgumentTelemtry = { additionalArguments: MysqlUtiliy_1.Utility.getAdditionalArgumentForTelemtry(this._getAdditionalArgument()) };
            telemetry.emitTelemetry('TaskHub', 'AzureMysqlDeployment', additionalArgumentTelemtry);
            if (this._azureMysqlTaskParameter.getDatabaseName()) {
                // Creating databse if it doesn't exist 
                this._executeSqlScript(argument + this._createDatabaseScriptIfItDoesnotExist()).then((resultCode) => {
                    argument += this._azureMysqlTaskParameter.getDatabaseName() ? " -D" + this._azureMysqlTaskParameter.getDatabaseName() : "";
                    // Running sql script passes by user
                    this._executeSqlScript(argument + this._getFileSourceArgument()).then((resultCode) => {
                        defer.resolve(resultCode);
                    }, (error) => {
                        defer.reject(error);
                    });
                }, (error) => {
                    defer.reject(new Error(task.loc("UnableToCreateDatabaseException")));
                });
            }
            else {
                argument += this._azureMysqlTaskParameter.getDatabaseName() ? " -D" + this._azureMysqlTaskParameter.getDatabaseName() : "";
                this._executeSqlScript(argument + this._getFileSourceArgument()).then((resultCode) => {
                    defer.resolve(resultCode);
                }, (error) => {
                    defer.reject(error);
                });
            }
            return defer.promise;
        });
    }
    _createDatabaseScriptIfItDoesnotExist() {
        return " -e" + '"' + "CREATE DATABASE IF NOT EXISTS " + this._azureMysqlTaskParameter.getDatabaseName() + " ; " + '"';
    }
    _executeSqlScript(argument) {
        return __awaiter(this, void 0, void 0, function* () {
            let defer = Q.defer();
            task.debug('Started execution of mysql script');
            task.exec(this._toolPath, MysqlUtiliy_1.Utility.argStringToArray(argument)).then((resultCode) => {
                task.debug('Script execution on mysql server result: ' + resultCode);
                if (resultCode === 0) {
                    defer.resolve(resultCode);
                }
                else {
                    defer.reject(new Error(task.loc("SqlExecutionException", resultCode)));
                }
            }, (error) => {
                defer.reject(error);
            });
            return defer.promise;
        });
    }
    /**
     * Additional connection argument passed by user
     */
    _getAdditionalArgument() {
        return this._azureMysqlTaskParameter.getSqlAdditionalArguments() ? this._azureMysqlTaskParameter.getSqlAdditionalArguments() : " ";
    }
    /**
     * Get connection argument to run script from file or inline
     */
    _getFileSourceArgument() {
        let fileSourceArgument;
        if (this._azureMysqlTaskParameter.getTaskNameSelector() === 'InlineSqlTask') {
            fileSourceArgument = " -e" + '"' + this._azureMysqlTaskParameter.getSqlInline() + '"';
        }
        else {
            fileSourceArgument = " -e" + '" source ' + packageUtility.PackageUtility.getPackagePath(this._azureMysqlTaskParameter.getSqlFile()) + '"';
        }
        return fileSourceArgument;
    }
}
exports.MysqlClient = MysqlClient;

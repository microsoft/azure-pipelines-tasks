"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
class MysqlServer {
    constructor(name, fullyQualifiedName, resourceGroupName) {
        if (!this.isNameValid(name)) {
            throw new Error(tl.loc("MysqlServerNameCannotBeEmpty"));
        }
        if (!this.isNameValid(fullyQualifiedName)) {
            throw new Error(tl.loc("MysqlFullyQualifiedServerNameCannotBeEmpty"));
        }
        if (!this.isNameValid(resourceGroupName)) {
            throw new Error(tl.loc("ResourceGroupCannotBeEmpty"));
        }
        this.name = name;
        this.fullyQualifiedName = fullyQualifiedName;
        this.resourceGroupName = resourceGroupName;
    }
    getResourceGroupName() {
        return this.resourceGroupName;
    }
    getName() {
        return this.name;
    }
    getFullyQualifiedName() {
        return this.fullyQualifiedName;
    }
    isNameValid(name) {
        if (name === null || name === undefined || typeof name.valueOf() !== 'string') {
            return false;
        }
        else {
            return true;
        }
    }
}
exports.MysqlServer = MysqlServer;

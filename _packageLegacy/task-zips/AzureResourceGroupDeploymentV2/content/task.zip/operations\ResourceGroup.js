"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const fs = require("fs");
const util = require("util");
const env = require("./Environment");
const armResource = require("azure-arm-rest/azure-arm-resource");
const winRM = require("./WinRMExtensionHelper");
const dgExtensionHelper = require("./DeploymentGroupExtensionHelper");
const ParameterParser_1 = require("./ParameterParser");
const utils = require("./Utils");
const fileEncoding = require("./FileEncoding");
var hm = require("typed-rest-client/HttpClient");
var uuid = require("uuid");
let proxyUrl = tl.getVariable("agent.proxyurl");
var requestOptions = proxyUrl ? {
    proxy: {
        proxyUrl: proxyUrl,
        proxyUsername: tl.getVariable("agent.proxyusername"),
        proxyPassword: tl.getVariable("agent.proxypassword"),
        proxyBypassHosts: tl.getVariable("agent.proxybypasslist") ? JSON.parse(tl.getVariable("agent.proxybypasslist")) : null
    }
} : {};
let ignoreSslErrors = tl.getVariable("VSTS_ARM_REST_IGNORE_SSL_ERRORS");
requestOptions.ignoreSslError = ignoreSslErrors && ignoreSslErrors.toLowerCase() == "true";
let httpClient = new hm.HttpClient(tl.getVariable("AZURE_HTTP_USER_AGENT"), null, requestOptions);
function stripJsonComments(content) {
    if (!content || (content.indexOf("//") < 0 && content.indexOf("/*") < 0)) {
        return content;
    }
    var currentChar;
    var nextChar;
    var insideQuotes = false;
    var contentWithoutComments = '';
    var insideComment = 0;
    var singlelineComment = 1;
    var multilineComment = 2;
    for (var i = 0; i < content.length; i++) {
        currentChar = content[i];
        nextChar = i + 1 < content.length ? content[i + 1] : "";
        if (insideComment) {
            var update = false;
            if (insideComment == singlelineComment && (currentChar + nextChar === '\r\n' || currentChar === '\n')) {
                i--;
                insideComment = 0;
                continue;
            }
            if (insideComment == multilineComment && currentChar + nextChar === '*/') {
                i++;
                insideComment = 0;
                continue;
            }
        }
        else {
            if (insideQuotes && currentChar == "\\") {
                contentWithoutComments += currentChar + nextChar;
                i++; // Skipping checks for next char if escaped
                continue;
            }
            else {
                if (currentChar == '"') {
                    insideQuotes = !insideQuotes;
                }
                if (!insideQuotes) {
                    if (currentChar + nextChar === '//') {
                        insideComment = singlelineComment;
                        i++;
                    }
                    if (currentChar + nextChar === '/*') {
                        insideComment = multilineComment;
                        i++;
                    }
                }
            }
        }
        if (!insideComment) {
            contentWithoutComments += content[i];
        }
    }
    return contentWithoutComments;
}
function formatNumber(num) {
    return ("0" + num).slice(-2);
}
class Deployment {
    constructor(properties) {
        this.properties = properties;
    }
    updateCommonProperties(mode) {
        this.properties["mode"] = mode;
        this.properties["debugSetting"] = { "detailLevel": "requestContent, responseContent" };
    }
}
class ResourceGroup {
    constructor(taskParameters) {
        this.enablePrereqDG = "ConfigureVMWithDGAgent";
        this.enablePrereqWinRM = "ConfigureVMwithWinRM";
        this.enablePrereqNone = "None";
        this.taskParameters = taskParameters;
        this.winRMExtensionHelper = new winRM.WinRMExtensionHelper(this.taskParameters);
        this.deploymentGroupExtensionHelper = new dgExtensionHelper.DeploymentGroupExtensionHelper(this.taskParameters);
        this.environmentHelper = new env.EnvironmentHelper(this.taskParameters);
    }
    createOrUpdateResourceGroup() {
        return __awaiter(this, void 0, void 0, function* () {
            var armClient = new armResource.ResourceManagementClient(this.taskParameters.credentials, this.taskParameters.subscriptionId);
            yield this.createResourceGroupIfRequired(armClient);
            yield this.createTemplateDeployment(armClient);
            yield this.enableDeploymentPrerequestiesIfRequired(armClient);
            yield this.registerEnvironmentIfRequired(armClient);
        });
    }
    deleteResourceGroup() {
        return new Promise((resolve, reject) => {
            var extDelPromise = this.deploymentGroupExtensionHelper.deleteExtensionFromResourceGroup();
            var deleteRG = (val) => {
                var armClient = new armResource.ResourceManagementClient(this.taskParameters.credentials, this.taskParameters.subscriptionId);
                console.log(tl.loc("DeletingResourceGroup", this.taskParameters.resourceGroupName));
                armClient.resourceGroups.deleteMethod(this.taskParameters.resourceGroupName, (error, result, request, response) => {
                    if (error) {
                        return reject(tl.loc("CouldNotDeletedResourceGroup", this.taskParameters.resourceGroupName, utils.getError(error)));
                    }
                    console.log(tl.loc("DeletedResourceGroup", this.taskParameters.resourceGroupName));
                    resolve();
                });
            };
            extDelPromise.then(deleteRG, deleteRG);
        });
    }
    selectResourceGroup() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!utils.isNonEmpty(this.taskParameters.outputVariable) &&
                (this.taskParameters.enableDeploymentPrerequisites == this.enablePrereqNone ||
                    this.taskParameters.enableDeploymentPrerequisites == this.enablePrereqWinRM)) {
                throw tl.loc("OutputVariableShouldNotBeEmpty");
            }
            var armClient = new armResource.ResourceManagementClient(this.taskParameters.credentials, this.taskParameters.subscriptionId);
            yield this.enableDeploymentPrerequestiesIfRequired(armClient);
            yield this.registerEnvironmentIfRequired(armClient);
        });
    }
    writeDeploymentErrors(error) {
        console.log(tl.loc("ErrorsInYourDeployment", error.code));
        if (error.message) {
            tl.error(error.message);
            if (error.details) {
                tl.error(tl.loc("Details"));
                let policyLink = null;
                for (var i = 0; i < error.details.length; i++) {
                    var errorMessage = null;
                    if (error.details[i].code === "RequestDisallowedByPolicy") {
                        if (!policyLink) {
                            policyLink = this.getPolicyHelpLink(error.details[i]);
                        }
                        errorMessage = this.getPolicyErrorMessage(error.details[i]);
                    }
                    else {
                        errorMessage = util.format("%s: %s %s", error.details[i].code, error.details[i].message, error.details[i].details);
                    }
                    tl.error(errorMessage);
                }
                if (policyLink) {
                    tl.error(util.format("[%s](%s)", tl.loc("MoreInformationOnAzurePortal"), policyLink));
                }
            }
        }
        else {
            tl.error(error);
        }
    }
    getPolicyHelpLink(errorDetail) {
        var additionalInfo = errorDetail.additionalInfo;
        if (!!additionalInfo) {
            for (var i = 0; i < additionalInfo.length; i++) {
                if (!!additionalInfo[i].info && !!additionalInfo[i].info.policyAssignmentId) {
                    let portalUrl = this.taskParameters.endpointPortalUrl ? this.taskParameters.endpointPortalUrl : "https://portal.azure.com";
                    return portalUrl + "#blade/Microsoft_Azure_Policy/EditAssignmentBlade/id/" + encodeURIComponent(additionalInfo[i].info.policyAssignmentId);
                }
            }
        }
        return null;
    }
    getPolicyErrorMessage(errorDetail) {
        var errorMessage = errorDetail.message;
        if (!!errorMessage) {
            errorMessage = errorMessage.split(".")[0] + ".";
        }
        var additionalInfo = errorDetail.additionalInfo;
        if (!!additionalInfo) {
            for (var i = 0; i < additionalInfo.length; i++) {
                if (!!additionalInfo[i].info) {
                    errorMessage = util.format("%s %s %s, %s %s, %s %s.", errorMessage, tl.loc("ErrorType"), additionalInfo[i].type, tl.loc("PolicyDefinitionName"), additionalInfo[i].info.policyDefinitionDisplayName, tl.loc("PolicyAssignmentName"), additionalInfo[i].info.policyAssignmentName);
                }
            }
        }
        return errorMessage;
    }
    registerEnvironmentIfRequired(armClient) {
        return __awaiter(this, void 0, void 0, function* () {
            if (utils.isNonEmpty(this.taskParameters.outputVariable) &&
                (this.taskParameters.enableDeploymentPrerequisites == this.enablePrereqWinRM ||
                    this.taskParameters.enableDeploymentPrerequisites == this.enablePrereqNone)) {
                yield this.environmentHelper.RegisterEnvironment();
            }
        });
    }
    enableDeploymentPrerequestiesIfRequired(armClient) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.taskParameters.enableDeploymentPrerequisites == this.enablePrereqWinRM) {
                yield this.winRMExtensionHelper.ConfigureWinRMExtension();
            }
            else if (this.taskParameters.enableDeploymentPrerequisites == this.enablePrereqDG) {
                yield this.deploymentGroupExtensionHelper.addExtensionOnResourceGroup();
            }
        });
    }
    createResourceGroupIfRequired(armClient) {
        return __awaiter(this, void 0, void 0, function* () {
            var exists = yield this.checkResourceGroupExistence(armClient);
            if (!exists) {
                yield this.createResourceGroup(armClient);
            }
        });
    }
    checkResourceGroupExistence(armClient) {
        console.log(tl.loc("CheckResourceGroupExistence", this.taskParameters.resourceGroupName));
        return new Promise((resolve, reject) => {
            armClient.resourceGroups.checkExistence(this.taskParameters.resourceGroupName, (error, exists, request, response) => {
                if (error) {
                    return reject(tl.loc("ResourceGroupStatusFetchFailed", utils.getError(error)));
                }
                console.log(tl.loc("ResourceGroupStatus", exists));
                resolve(exists);
            });
        });
    }
    createDeploymentName() {
        var name;
        if (this.taskParameters.templateLocation == "Linked artifact") {
            name = tl.findMatch(tl.getVariable("System.DefaultWorkingDirectory"), this.taskParameters.csmFile)[0];
        }
        else {
            name = this.taskParameters.csmFileLink;
        }
        name = path.basename(name).split(".")[0].replace(" ", "");
        name = name.substr(0, 40);
        var timestamp = new Date(Date.now());
        var uniqueId = uuid().substr(0, 4);
        var suffix = util.format("%s%s%s-%s%s%s-%s", timestamp.getFullYear(), formatNumber(timestamp.getMonth()), formatNumber(timestamp.getDate()), formatNumber(timestamp.getHours()), formatNumber(timestamp.getMinutes()), formatNumber(timestamp.getSeconds()), uniqueId);
        var deploymentName = util.format("%s-%s", name, suffix);
        if (deploymentName.match(/^[-\w\._\(\)]+$/) === null) {
            deploymentName = util.format("deployment-%s", suffix);
        }
        return deploymentName;
    }
    castToType(value, type) {
        switch (type.toLowerCase()) {
            case "int":
            case "object":
            case "secureobject":
            case "array":
            case "bool":
                return JSON.parse(value);
            case "string":
            case "securestring":
                return JSON.parse(`"` + value + `"`); // Adding trailing quotes for JSON parser to detect string
            default:
                // Sending as string
                break;
        }
        return value;
    }
    updateOverrideParameters(template, parameters) {
        tl.debug("Overriding Parameters..");
        var overrideParameters = ParameterParser_1.PowerShellParameters.parse(this.taskParameters.overrideParameters, true, "\\");
        for (var overrideParameter of overrideParameters) {
            tl.debug("Overriding key: " + overrideParameter.name);
            try {
                overrideParameter.value = this.castToType(overrideParameter.value, template.parameters[overrideParameter.name].type);
            }
            catch (error) {
                console.log(tl.loc("ErrorWhileParsingParameter", overrideParameter.name, error.toString()));
            }
            parameters[overrideParameter.name] = {
                value: overrideParameter.value
            };
        }
        return parameters;
    }
    createResourceGroup(armClient) {
        return new Promise((resolve, reject) => {
            console.log(tl.loc("CreatingNewRG", this.taskParameters.resourceGroupName));
            armClient.resourceGroups.createOrUpdate(this.taskParameters.resourceGroupName, { "name": this.taskParameters.resourceGroupName, "location": this.taskParameters.location }, (error, result, request, response) => {
                if (error) {
                    return reject(tl.loc("ResourceGroupCreationFailed", utils.getError(error)));
                }
                console.log(tl.loc("CreatedRG"));
                resolve();
            });
        });
    }
    downloadFile(url) {
        return new Promise((resolve, reject) => {
            httpClient.get(url, {}).then((response) => __awaiter(this, void 0, void 0, function* () {
                if (response.message.statusCode == 200) {
                    let contents = "";
                    try {
                        contents = yield response.readBody();
                        contents = contents.replace(/^\uFEFF/, ''); // Remove UTF-8 BOM if present.
                    }
                    catch (error) {
                        reject(tl.loc("UnableToReadResponseBody", error));
                    }
                    resolve(contents);
                }
                else {
                    var errorMessage = response.message.statusCode.toString() + ": " + response.message.statusMessage;
                    return reject(tl.loc("FileFetchFailed", url, errorMessage));
                }
            }), (error) => {
                return reject(tl.loc("FileFetchFailed", url, error));
            });
        });
    }
    getDeploymentDataForLinkedArtifact() {
        var template;
        var fileMatches = tl.findMatch(tl.getVariable("System.DefaultWorkingDirectory"), this.taskParameters.csmFile);
        if (fileMatches.length > 1) {
            throw new Error(tl.loc("TemplateFilePatternMatchingMoreThanOneFile", fileMatches));
        }
        if (fileMatches.length < 1) {
            throw new Error(tl.loc("TemplateFilePatternMatchingNoFile"));
        }
        var csmFilePath = fileMatches[0];
        if (!fs.lstatSync(csmFilePath).isDirectory()) {
            tl.debug("Loading CSM Template File.. " + csmFilePath);
            try {
                template = JSON.parse(stripJsonComments(fileEncoding.readFileContentsAsText(csmFilePath)));
            }
            catch (error) {
                throw new Error(tl.loc("TemplateParsingFailed", csmFilePath, utils.getError(error.message)));
            }
            tl.debug("Loaded CSM File");
        }
        else {
            throw new Error(tl.loc("CsmFilePatternMatchesADirectoryInsteadOfAFile", csmFilePath));
        }
        var parameters = {};
        if (utils.isNonEmpty(this.taskParameters.csmParametersFile)) {
            var fileMatches = tl.findMatch(tl.getVariable("System.DefaultWorkingDirectory"), this.taskParameters.csmParametersFile);
            if (fileMatches.length > 1) {
                throw new Error(tl.loc("TemplateParameterFilePatternMatchingMoreThanOneFile", fileMatches));
            }
            if (fileMatches.length < 1) {
                throw new Error(tl.loc("TemplateParameterFilePatternMatchingNoFile"));
            }
            var csmParametersFilePath = fileMatches[0];
            if (!fs.lstatSync(csmParametersFilePath).isDirectory()) {
                tl.debug("Loading Parameters File.. " + csmParametersFilePath);
                try {
                    var parameterFile = JSON.parse(stripJsonComments(fileEncoding.readFileContentsAsText(csmParametersFilePath)));
                    tl.debug("Loaded Parameters File");
                    parameters = parameterFile["parameters"];
                }
                catch (error) {
                    throw new Error(tl.loc("ParametersFileParsingFailed", csmParametersFilePath, utils.getError(error.message)));
                }
            }
            else {
                if (tl.filePathSupplied("csmParametersFile")) {
                    throw new Error(tl.loc("ParametersPatternMatchesADirectoryInsteadOfAFile", csmParametersFilePath));
                }
            }
        }
        if (utils.isNonEmpty(this.taskParameters.overrideParameters)) {
            parameters = this.updateOverrideParameters(template, parameters);
        }
        parameters = this.sanitizeParameters(parameters);
        var deployment = new Deployment({
            template: template,
            parameters: parameters
        });
        deployment.updateCommonProperties(this.taskParameters.deploymentMode);
        return deployment;
    }
    sanitizeParameters(parameters) {
        var result = {};
        for (var key in parameters) {
            if (!!parameters[key]) {
                if (parameters[key].hasOwnProperty("value")) {
                    result[key] = {
                        value: parameters[key].value
                    };
                }
                else if (parameters[key].hasOwnProperty("reference")) {
                    result[key] = {
                        reference: parameters[key].reference
                    };
                }
            }
        }
        return result;
    }
    getDeploymentObjectForPublicURL() {
        return __awaiter(this, void 0, void 0, function* () {
            var properties = {};
            properties["templateLink"] = {
                uri: this.taskParameters.csmFileLink
            };
            var parameters = {};
            var deployment = new Deployment(properties);
            if (utils.isNonEmpty(this.taskParameters.csmParametersFileLink)) {
                if (utils.isNonEmpty(this.taskParameters.overrideParameters)) {
                    var contents = yield this.downloadFile(this.taskParameters.csmParametersFileLink);
                    parameters = JSON.parse(stripJsonComments(contents)).parameters;
                }
                else {
                    deployment.properties["parametersLink"] = {
                        uri: this.taskParameters.csmParametersFileLink
                    };
                }
            }
            if (utils.isNonEmpty(this.taskParameters.overrideParameters)) {
                tl.debug("Downloading CSM Template File.. " + this.taskParameters.csmFileLink);
                var templateFile = yield this.downloadFile(this.taskParameters.csmFileLink);
                var template;
                try {
                    var template = JSON.parse(stripJsonComments(templateFile));
                    tl.debug("Loaded CSM File");
                }
                catch (error) {
                    throw new Error(tl.loc("TemplateParsingFailed", utils.getError(error.message)));
                }
                parameters = this.updateOverrideParameters(template, parameters);
                parameters = this.sanitizeParameters(parameters);
                deployment.properties["parameters"] = parameters;
            }
            deployment.updateCommonProperties(this.taskParameters.deploymentMode);
            return deployment;
        });
    }
    validateDeployment(armClient, deployment) {
        return new Promise((resolve, reject) => {
            console.log(tl.loc("StartingValidation"));
            deployment.properties["mode"] = "Incremental";
            armClient.deployments.validate(this.taskParameters.resourceGroupName, this.createDeploymentName(), deployment, (error, result, request, response) => {
                if (error) {
                    return reject(tl.loc("CreateTemplateDeploymentValidationFailed", utils.getError(error)));
                }
                if (result.error) {
                    this.writeDeploymentErrors(result.error);
                    return reject(tl.loc("CreateTemplateDeploymentFailed"));
                }
                else {
                    console.log(tl.loc("ValidDeployment"));
                    resolve();
                }
            });
        });
    }
    performAzureDeployment(armClient, deployment) {
        return __awaiter(this, void 0, void 0, function* () {
            if (deployment.properties["mode"] === "Validation") {
                return this.validateDeployment(armClient, deployment);
            }
            else {
                console.log(tl.loc("StartingDeployment"));
                return new Promise((resolve, reject) => {
                    armClient.deployments.createOrUpdate(this.taskParameters.resourceGroupName, this.createDeploymentName(), deployment, (error, result, request, response) => {
                        if (error) {
                            this.writeDeploymentErrors(error);
                            return reject(tl.loc("CreateTemplateDeploymentFailed"));
                        }
                        if (result && result["properties"] && result["properties"]["outputs"] && utils.isNonEmpty(this.taskParameters.deploymentOutputs)) {
                            tl.setVariable(this.taskParameters.deploymentOutputs, JSON.stringify(result["properties"]["outputs"]));
                            console.log(tl.loc("AddedOutputVariable", this.taskParameters.deploymentOutputs));
                        }
                        console.log(tl.loc("CreateTemplateDeploymentSucceeded"));
                        resolve();
                    });
                });
            }
        });
    }
    createTemplateDeployment(armClient) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("CreatingTemplateDeployment"));
            var deployment;
            if (this.taskParameters.templateLocation === "Linked artifact") {
                deployment = this.getDeploymentDataForLinkedArtifact();
            }
            else if (this.taskParameters.templateLocation === "URL of the file") {
                deployment = yield this.getDeploymentObjectForPublicURL();
            }
            else {
                throw new Error(tl.loc("InvalidTemplateLocation"));
            }
            yield this.performAzureDeployment(armClient, deployment);
        });
    }
}
exports.ResourceGroup = ResourceGroup;

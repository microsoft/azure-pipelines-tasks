"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const azure_arm_endpoint_1 = require("azure-arm-rest/azure-arm-endpoint");
class TokenCredentials {
    constructor(hostUrl, patToken) {
        if (typeof hostUrl.valueOf() !== 'string' || !hostUrl) {
            throw new Error(tl.loc("HostUrlCannotBeEmpty"));
        }
        if (typeof patToken.valueOf() !== 'string' || !patToken) {
            throw new Error(tl.loc("PatTokenCannotBeEmpty"));
        }
        this.hostUrl = hostUrl;
        this.patToken = patToken;
    }
    getPatToken() {
        return this.patToken;
    }
    getHostUrl() {
        return this.hostUrl;
    }
}
class AgentServiceUserCredentials {
    constructor(userName, password) {
        this.userName = userName || "";
        this.password = password || "";
    }
    getUserName() {
        return this.userName;
    }
    getPassword() {
        return this.password;
    }
}
class AzureRGTaskParameters {
    constructor() {
        this.deploymentGroupProjectName = "";
    }
    getVSTSPatToken(deploymentGroupEndpointName) {
        var endpointAuth = tl.getEndpointAuthorization(deploymentGroupEndpointName, true);
        if (endpointAuth.scheme === 'Token') {
            var hostUrl = tl.getEndpointUrl(deploymentGroupEndpointName, true);
            var patToken = endpointAuth.parameters["apitoken"];
            if (typeof hostUrl.valueOf() !== 'string' || !hostUrl) {
                throw new Error(tl.loc("DeploymentGroupEndpointUrlCannotBeEmpty"));
            }
            if (typeof patToken.valueOf() !== 'string' || !patToken) {
                throw new Error(tl.loc("DeploymentGroupEndpointPatTokenCannotBeEmpty"));
            }
            var credentials = new TokenCredentials(hostUrl, patToken);
            return credentials;
        }
        else {
            var msg = tl.loc("OnlyTokenAuthAllowed");
            console.log(msg);
            throw (msg);
        }
    }
    getARMCredentials(connectedService) {
        return __awaiter(this, void 0, void 0, function* () {
            var azureEndpoint = yield new azure_arm_endpoint_1.AzureRMEndpoint(connectedService).getEndpoint();
            return azureEndpoint.applicationTokenCredentials;
        });
    }
    getAzureRGTaskParameters() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var connectedService = tl.getInput("ConnectedServiceName", true);
                var endpointTelemetry = '{"endpointId":"' + connectedService + '"}';
                console.log("##vso[telemetry.publish area=TaskEndpointId;feature=AzureResourceGroupDeployment]" + endpointTelemetry);
                this.subscriptionId = tl.getEndpointDataParameter(connectedService, "SubscriptionId", true);
                this.endpointPortalUrl = tl.getEndpointDataParameter(connectedService, "armManagementPortalUrl", true);
                this.resourceGroupName = tl.getInput("resourceGroupName", true);
                this.action = tl.getInput("action");
                this.location = tl.getInput("location");
                this.templateLocation = tl.getInput("templateLocation");
                if (this.templateLocation === "Linked artifact") {
                    this.csmFile = tl.getPathInput("csmFile");
                    this.csmParametersFile = tl.getPathInput("csmParametersFile");
                }
                else {
                    this.csmFileLink = tl.getInput("csmFileLink");
                    this.csmParametersFileLink = tl.getInput("csmParametersFileLink");
                }
                this.overrideParameters = tl.getInput("overrideParameters");
                this.enableDeploymentPrerequisites = tl.getInput("enableDeploymentPrerequisites");
                this.deploymentGroupName = tl.getInput("deploymentGroupName");
                this.copyAzureVMTags = tl.getBoolInput("copyAzureVMTags");
                var deploymentGroupEndpointName = tl.getInput("deploymentGroupEndpoint", false);
                if (deploymentGroupEndpointName) {
                    this.tokenCredentials = this.getVSTSPatToken(deploymentGroupEndpointName);
                }
                this.runAgentServiceAsUser = tl.getBoolInput("runAgentServiceAsUser");
                var userName = tl.getInput("userName");
                if (this.runAgentServiceAsUser && !userName) {
                    throw tl.loc("UserNameCannotBeNull");
                }
                var password = tl.getInput("password");
                this.agentServiceUserCredentials = new AgentServiceUserCredentials(userName, password);
                this.outputVariable = tl.getInput("outputVariable");
                this.deploymentMode = tl.getInput("deploymentMode");
                this.credentials = yield this.getARMCredentials(connectedService);
                this.deploymentGroupProjectName = tl.getInput("project");
                this.deploymentOutputs = tl.getInput("deploymentOutputs");
                return this;
            }
            catch (error) {
                throw new Error(tl.loc("ARGD_ConstructorFailed", error.message));
            }
        });
    }
}
exports.AzureRGTaskParameters = AzureRGTaskParameters;

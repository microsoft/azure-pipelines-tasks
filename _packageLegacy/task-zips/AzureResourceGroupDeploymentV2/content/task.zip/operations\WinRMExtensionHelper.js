"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const networkManagementClient = require("azure-arm-rest/azure-arm-network");
const computeManagementClient = require("azure-arm-rest/azure-arm-compute");
const util = require("util");
const tl = require("vsts-task-lib/task");
const azure_utils = require("./AzureUtil");
const az = require("azure-arm-rest/azureModels");
const utils = require("./Utils");
const webRequestUtility = require("azure-arm-rest/webRequestUtility");
class WinRMExtensionHelper {
    constructor(taskParameters) {
        this.taskParameters = taskParameters;
        this.resourceGroupName = this.taskParameters.resourceGroupName;
        this.credentials = this.taskParameters.credentials;
        this.subscriptionId = this.taskParameters.subscriptionId;
        this.fqdnMap = {};
        this.winRmHttpsPortMap = {};
        this.customScriptExtensionInstalled = false;
        this.ruleAddedToNsg = false;
        this.networkClient = new networkManagementClient.NetworkManagementClient(this.credentials, this.subscriptionId);
        this.computeClient = new computeManagementClient.ComputeManagementClient(this.credentials, this.subscriptionId);
        this.azureUtils = new azure_utils.AzureUtil(this.taskParameters, this.computeClient, this.networkClient);
    }
    ConfigureWinRMExtension() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.AddInboundNatRulesOnLoadBalancers();
            yield this.AddExtensionToVMsToConfigureWinRM();
            yield this.AddNetworkSecurityRuleConfigForWinRMPort();
        });
    }
    AddInboundNatRulesOnLoadBalancers() {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug("Trying to add Inbound Nat Rule to the LBs...");
            var resourceGroupDetails = yield this.azureUtils.getResourceGroupDetails();
            for (var virtualMachine of resourceGroupDetails.VirtualMachines) {
                if (!utils.isNonEmpty(virtualMachine.WinRMHttpsPublicAddress)) {
                    tl.debug("Adding Inbound Nat Rule for the VM: " + virtualMachine.Name);
                    var lb;
                    var nicId;
                    for (var nic of virtualMachine.NetworkInterfaceIds) {
                        nicId = nic;
                        lb = resourceGroupDetails.LoadBalancers.find(l => !!l.BackendNicIds.find(id => id === nic));
                        if (lb)
                            break;
                    }
                    if (lb) {
                        tl.debug("LB to which Inbound Nat Rule for VM " + virtualMachine.Name + " is to be added is " + lb.Id);
                        var frontendPort = this.GetFreeFrontendPort(lb);
                        yield this.AddNatRuleInternal(lb.Id, nicId, frontendPort, 5986, virtualMachine.Name);
                        lb.FrontEndPortsInUse.push(frontendPort);
                    }
                    else {
                        tl.warning("There is no public address to reach the virtual machine x.");
                    }
                }
                else {
                    tl.debug("No need to add Inbound Nat rule for vm " + virtualMachine.Name);
                }
            }
        });
    }
    GetFreeFrontendPort(loadBalancer) {
        var port = 5986;
        while (loadBalancer.FrontEndPortsInUse.find(p => p == port)) {
            port++;
        }
        tl.debug("Free port for Load balancer " + loadBalancer.Id + " is " + port);
        return port;
    }
    AddNatRuleInternal(loadBalancerId, networkInterfaceId, fronendPort, backendPort, virtualMachineName) {
        return __awaiter(this, void 0, void 0, function* () {
            var random = Math.floor(Math.random() * 10000 + 100);
            var name = "winRMHttpsRule" + random.toString();
            var loadBalancers = yield this.azureUtils.getLoadBalancers();
            var loadBalancer = loadBalancers.find(l => l.id == loadBalancerId);
            var InboundNatRuleProperties = {
                backendPort: backendPort,
                frontendPort: fronendPort,
                frontendIPConfiguration: { id: loadBalancer.properties.frontendIPConfigurations[0].id },
                protocol: "Tcp",
                idleTimeoutInMinutes: 4,
                enableFloatingIP: false
            };
            var rule = {
                id: "",
                name: name,
                properties: InboundNatRuleProperties
            };
            loadBalancer.properties.inboundNatRules.push(rule);
            var networkInterfaces = this.azureUtils.networkInterfaceDetails;
            var networkInterface = networkInterfaces.find(n => n.id == networkInterfaceId);
            var ipConfiguration;
            for (var ipc of networkInterface.properties.ipConfigurations) {
                for (var pool of loadBalancer.properties.backendAddressPools) {
                    if (pool.properties.backendIPConfigurations && pool.properties.backendIPConfigurations.find(x => x.id == ipc.id)) {
                        if (!ipc.properties.loadBalancerInboundNatRules) {
                            ipc.properties.loadBalancerInboundNatRules = [];
                        }
                        ipConfiguration = ipc;
                        break;
                    }
                }
            }
            if (!!loadBalancer && !!networkInterface) {
                yield this.AddInboundNatRule(networkInterface, loadBalancer, ipConfiguration, fronendPort, virtualMachineName);
            }
        });
    }
    AddInboundNatRule(networkInterface, loadBalancer, ipConfiguration, fronendPort, virtualMachineName) {
        return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("AddingInboundNatRule", virtualMachineName, loadBalancer.name));
            this.networkClient.loadBalancers.createOrUpdate(this.resourceGroupName, loadBalancer.name, loadBalancer, null, (error, result, request, response) => {
                if (error) {
                    console.log(tl.loc("InboundNatRuleAdditionFailed", loadBalancer.name, utils.getError(error)));
                    reject(tl.loc("InboundNatRuleAdditionFailed", loadBalancer.name, utils.getError(error)));
                }
                else {
                    var loadBalancerUpdated = result;
                    var addedRule = loadBalancerUpdated.properties.inboundNatRules.find(r => r.properties.frontendPort == fronendPort);
                    ipConfiguration.properties.loadBalancerInboundNatRules.push(addedRule);
                    tl.debug("Updating the loadBalancerInboundNatRules of nic " + networkInterface.name);
                    this.networkClient.networkInterfaces.createOrUpdate(this.resourceGroupName, networkInterface.name, networkInterface, null, (error2, result2, request2, response2) => {
                        if (error2) {
                            console.log(tl.loc("InboundNatRulesToNICFailed", networkInterface.name, utils.getError(error2)));
                            reject(tl.loc("InboundNatRulesToNICFailed", networkInterface.name, utils.getError(error2)));
                            return;
                        }
                        console.log(tl.loc("AddedTargetInboundNatRuleLB", networkInterface.name));
                        resolve();
                    });
                }
            });
        }));
    }
    AddNetworkSecurityRuleConfigForWinRMPort() {
        return __awaiter(this, void 0, void 0, function* () {
            var ruleName = "VSO-Custom-WinRM-Https-Port";
            var rulePriority = 3986;
            var winrmHttpsPort = "5986";
            var securityGroups = yield this.GetNetworkSecurityGroups();
            var promises = [];
            if (securityGroups && securityGroups.length) {
                tl.debug("Trying to add a network security group rule");
                for (var i = 0; i < securityGroups.length; i++) {
                    console.log(tl.loc("AddingSecurityRuleNSG", securityGroups[i]["name"]));
                    var securityGrp = securityGroups[i];
                    var securityGrpName = securityGrp["name"];
                    tl.debug("Getting the network security rule config " + ruleName + " under security group " + securityGrpName);
                    promises.push(this.TryAddNetworkSecurityRule(securityGrpName, ruleName, rulePriority, winrmHttpsPort));
                }
            }
            return new Promise((resolve, reject) => {
                Promise.all(promises).then(() => {
                    tl.debug("Finished adding rules to the network security groups");
                    resolve(null);
                }).catch((exception) => {
                    tl.debug("Failed to add the network security rules with the exception " + exception);
                    reject(exception);
                });
            });
        });
    }
    AddInboundNetworkSecurityRule(securityGrpName, ruleName, rulePriority, winrmHttpsPort) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                tl.debug("Adding inbound network security rule config " + ruleName + " with priority " + rulePriority + " for port " + winrmHttpsPort + " under security group " + securityGrpName);
                var securityRuleParameters = {
                    properties: {
                        direction: "Inbound",
                        access: "Allow",
                        sourceAddressPrefix: "*",
                        sourcePortRange: "*",
                        destinationAddressPrefix: "*",
                        destinationPortRange: winrmHttpsPort,
                        protocol: "*",
                        priority: rulePriority
                    }
                };
                this.networkClient.securityRules.createOrUpdate(this.resourceGroupName, securityGrpName, ruleName, securityRuleParameters, (error, result, request, response) => {
                    if (error) {
                        tl.debug("Error in adding network security rule " + util.inspect(error, { depth: null }));
                        tl.debug("Failed to add inbound network security rule config " + ruleName + " with priority " + rulePriority + " for port " + winrmHttpsPort + " under security group " + securityGrpName);
                        rulePriority = rulePriority + 50;
                        return reject(utils.getError(error));
                    }
                    console.log(tl.loc("AddedSecurityRuleNSG", ruleName, rulePriority, winrmHttpsPort, securityGrpName, util.inspect(result, { depth: null })));
                    return resolve();
                });
            }));
        });
    }
    AddInboundNetworkSecurityRuleWithRetry(retryCnt, securityGrpName, ruleName, rulePriority, winrmHttpsPort) {
        return __awaiter(this, void 0, void 0, function* () {
            for (var i = 0; i < 3; i++) {
                try {
                    yield this.AddInboundNetworkSecurityRule(securityGrpName, ruleName, rulePriority, winrmHttpsPort);
                    return;
                }
                catch (exception) {
                }
            }
            throw tl.loc("FailedAddingNSGRule3Times", securityGrpName);
        });
    }
    TryAddNetworkSecurityRule(securityGrpName, ruleName, rulePriority, winrmHttpsPort) {
        return __awaiter(this, void 0, void 0, function* () {
            var result = yield this.GetSecurityRules(securityGrpName, ruleName);
            if (!result) {
                tl.debug("Rule " + ruleName + " not found under security Group " + securityGrpName);
                var maxRetries = 3;
                yield this.AddInboundNetworkSecurityRuleWithRetry(maxRetries, securityGrpName, ruleName, rulePriority, winrmHttpsPort);
            }
            else {
                console.log(tl.loc("RuleExistsAlready", ruleName, securityGrpName));
            }
        });
    }
    GetSecurityRules(securityGrpName, ruleName) {
        return new Promise((resolve, reject) => {
            this.networkClient.securityRules.get(this.resourceGroupName, securityGrpName, ruleName, null, (error, result, request, response) => {
                if (error) {
                    return resolve(null); // Rule doesnt exist;
                }
                resolve(result);
            });
        });
    }
    GetNetworkSecurityGroups() {
        return new Promise((resolve, reject) => {
            this.networkClient.networkSecurityGroups.list(this.resourceGroupName, null, (error, result, request, response) => {
                if (error) {
                    tl.debug("Failed to get the list of NSG " + JSON.stringify(error));
                    reject(utils.getError(error));
                    return;
                }
                resolve(result);
            });
        });
    }
    AddExtensionToVMsToConfigureWinRM() {
        return __awaiter(this, void 0, void 0, function* () {
            var resourceGroupDetails = yield this.azureUtils.getResourceGroupDetails();
            var promises = [];
            for (var vm of this.azureUtils.vmDetails) {
                var resourceName = vm.name;
                var resourceId = vm.id;
                var vmResource = resourceGroupDetails.VirtualMachines.find(v => v.Name == resourceName);
                var resourceFQDN = vmResource.WinRMHttpsPublicAddress;
                var resourceWinRmHttpsPort = vmResource.WinRMHttpsPort;
                if (vm["properties"]["storageProfile"]["osDisk"]["osType"] === 'Windows') {
                    tl.debug("Enabling winrm for virtual machine " + resourceName);
                    promises.push(this.AddWinRMExtension(resourceId, resourceName, resourceFQDN, vm["location"]));
                }
                else {
                    tl.debug("WinRM extension cannot be enabled on the virtual machine: " + resourceName + "since the OS type is " +
                        vm.properties["storageProfile"]["osDisk"]["osType"]);
                }
            }
            return new Promise((resolve, reject) => {
                Promise.all(promises).then(() => {
                    tl.debug("Added custom script extension to all the vms in the resource group");
                    resolve(null);
                }).catch((exception) => {
                    tl.debug("Failed to add extension to the vms with the exception: " + exception);
                    reject(exception);
                });
            });
        });
    }
    AddWinRMExtension(vmId, vmName, dnsName, location) {
        return __awaiter(this, void 0, void 0, function* () {
            var extensionName = "WinRMCustomScriptExtension";
            var configWinRMScriptFileFwdLink = "https://aka.ms/vstsconfigurewinrm";
            var makeCertFileFwdLink = "https://aka.ms/vstsmakecertexe";
            var configWinRMScriptFile = yield webRequestUtility.getTargetUriFromFwdLink(configWinRMScriptFileFwdLink);
            var makeCertFile = yield webRequestUtility.getTargetUriFromFwdLink(makeCertFileFwdLink);
            var fileUris = [configWinRMScriptFile, makeCertFile];
            tl.debug("Adding custom script extension for virtual machine " + vmName);
            tl.debug("VM Location: " + location);
            tl.debug("VM DNS: " + dnsName);
            tl.debug("Checking if the extension " + extensionName + " is present on vm " + vmName);
            var result = yield this.GetCustomScriptExtension(vmName);
            tl.debug("Matching extension: " + JSON.stringify(result));
            var extensionStatusValid = false;
            if (result) {
                if (result["name"] == extensionName && result["properties"]["settings"]["fileUris"].length == fileUris.length && fileUris.every((element, index) => { return element === result["properties"]["settings"]["fileUris"][index]; })) {
                    tl.debug("Custom Script extension is for enabling Https Listener on VM: " + vmName);
                    if (result["properties"]["provisioningState"] === 'Succeeded') {
                        try {
                            yield this.ValidateExtensionExecutionStatus(vmName, dnsName, extensionName, location, fileUris);
                            extensionStatusValid = true;
                        }
                        catch (exception) {
                            tl.debug("Extension substatus is: " + exception);
                        }
                    }
                }
                if (!extensionStatusValid) {
                    yield this.RemoveExtensionFromVM(result["name"], vmName);
                }
            }
            if (!extensionStatusValid) {
                yield this.AddExtensionToVM(vmName, dnsName, extensionName, location, fileUris);
            }
            tl.debug("Addition of Custom Script Extension is completed on vm: " + vmName);
        });
    }
    GetCustomScriptExtension(vmName) {
        return new Promise((resolve, reject) => {
            this.computeClient.virtualMachineExtensions.list(this.resourceGroupName, vmName, az.ComputeResourceType.VirtualMachine, null, (error, result, request, response) => __awaiter(this, void 0, void 0, function* () {
                if (error) {
                    reject(tl.loc("ListingOfExtensionsFailed", vmName, utils.getError(error)));
                    return;
                }
                tl.debug("Result of listing the extensions: " + JSON.stringify(result));
                var extensions = result || [];
                var matchingExtension = null;
                extensions.forEach((extension) => {
                    if (extension.properties.type == "CustomScriptExtension" &&
                        extension.properties.publisher == "Microsoft.Compute") {
                        matchingExtension = extension;
                    }
                });
                resolve(matchingExtension);
            }));
        });
    }
    ValidateExtensionExecutionStatus(vmName, dnsName, extensionName, location, fileUris) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug("Validating the winrm configuration custom script extension status on vm: " + vmName);
            return new Promise((resolve, reject) => {
                this.computeClient.virtualMachines.get(this.resourceGroupName, vmName, { expand: 'instanceView' }, (error, result, request, response) => __awaiter(this, void 0, void 0, function* () {
                    if (error) {
                        reject(tl.loc("FailedToFetchInstanceViewVM", utils.getError(error)));
                        return;
                    }
                    var extensionPresent = false;
                    tl.debug("Got the Instance View of the virtualMachine " + vmName + ": " + JSON.stringify(result));
                    var errorMessage = null;
                    if (result["properties"]["instanceView"] && result["properties"]["instanceView"]["extensions"]) {
                        var extensions = result["properties"]["instanceView"]["extensions"];
                        for (var extension of extensions) {
                            if (extension["name"] === extensionName) {
                                extensionPresent = true;
                                for (var substatus of extension["substatuses"]) {
                                    if (substatus["code"] && substatus["code"].indexOf("ComponentStatus/StdErr") >= 0 && substatus["message"]) {
                                        errorMessage = substatus["message"];
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                    }
                    if (!extensionPresent) {
                        errorMessage = tl.loc("ExtensionNotFound", vmName);
                    }
                    if (errorMessage) {
                        reject(errorMessage);
                    }
                    else {
                        tl.debug("Custom Script Extension status validated for vm: " + vmName + "!!");
                        resolve();
                    }
                }));
            });
        });
    }
    AddExtensionToVM(vmName, dnsName, extensionName, location, _fileUris) {
        return __awaiter(this, void 0, void 0, function* () {
            var _commandToExecute = "powershell.exe -ExecutionPolicy RemoteSigned -File ConfigureWinRM.ps1 " + dnsName;
            var _extensionType = 'Microsoft.Compute/virtualMachines/extensions';
            var _virtualMachineExtensionType = 'CustomScriptExtension';
            var _typeHandlerVersion = '1.7';
            var _publisher = 'Microsoft.Compute';
            var _protectedSettings = { commandToExecute: _commandToExecute };
            var parameters = {
                type: _extensionType,
                location: location,
                properties: {
                    publisher: _publisher,
                    type: _virtualMachineExtensionType,
                    typeHandlerVersion: _typeHandlerVersion,
                    settings: {
                        fileUris: _fileUris,
                        commandToExecute: _commandToExecute
                    }
                }
            };
            console.log(tl.loc("AddExtension", extensionName, vmName));
            return new Promise((resolve, reject) => {
                this.computeClient.virtualMachineExtensions.createOrUpdate(this.resourceGroupName, vmName, az.ComputeResourceType.VirtualMachine, extensionName, parameters, (error, result, request, response) => __awaiter(this, void 0, void 0, function* () {
                    if (error) {
                        console.log(tl.loc("CreationOfExtensionFailed", vmName, utils.getError(error)));
                    }
                    else {
                        tl.debug("Addition of extension completed for vm: " + vmName);
                        if (result["properties"]["provisioningState"] != 'Succeeded') {
                            console.log(tl.loc("ProvisioningStatusOfExtensionIsNotSucceeded", vmName));
                            tl.debug("Result: " + JSON.stringify(result));
                        }
                    }
                    try {
                        yield this.ValidateExtensionExecutionStatus(vmName, dnsName, extensionName, location, _fileUris);
                    }
                    catch (exception) {
                        tl.debug("WinRMCustomScriptExtension is not valid on vm " + vmName);
                        reject(tl.loc("ARG_SetExtensionFailedForVm", vmName, exception));
                        return;
                    }
                    tl.debug("Provisioning of CustomScriptExtension on vm " + vmName + " is in Succeeded State");
                    this.customScriptExtensionInstalled = true;
                    console.log(tl.loc("AddedExtension", vmName));
                    resolve();
                }));
            });
        });
    }
    RemoveExtensionFromVM(extensionName, vmName) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug("Removing the extension " + extensionName + "from vm " + vmName);
            //delete the extension
            return new Promise((resolve, reject) => {
                this.computeClient.virtualMachineExtensions.deleteMethod(this.resourceGroupName, vmName, az.ComputeResourceType.VirtualMachine, extensionName, (error, result, request, response) => __awaiter(this, void 0, void 0, function* () {
                    if (error) {
                        tl.debug("Failed to delete the extension " + extensionName + " on the vm " + vmName + ", with error Message: " + util.inspect(error, { depth: null }));
                        reject(tl.loc("FailedToDeleteExtension"));
                        return;
                    }
                    tl.debug("Successfully removed the extension " + extensionName + " from the VM " + vmName);
                    resolve();
                }));
            });
        });
    }
}
exports.WinRMExtensionHelper = WinRMExtensionHelper;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const computeManagementClient = require("azure-arm-rest/azure-arm-compute");
const tl = require("vsts-task-lib/task");
const azure_utils = require("./AzureUtil");
const az = require("azure-arm-rest/azureModels");
const utils = require("./Utils");
class DeploymentGroupExtensionHelper {
    constructor(taskParameters) {
        this.publisher = "Microsoft.VisualStudio.Services";
        this.extensionType = "Microsoft.Compute/virtualMachines/extensions";
        this.dgExtensionNameWindows = "TeamServicesAgent";
        this.vmExtensionTypeWindows = "TeamServicesAgent";
        this.dgExtensionNameLinux = "TeamServicesAgentLinux";
        this.vmExtensionTypeLinux = "TeamServicesAgentLinux";
        //Whenever major version is modified, modify the task version accordingly.
        this.version = "1.0";
        this.taskParameters = taskParameters;
        this.computeClient = new computeManagementClient.ComputeManagementClient(this.taskParameters.credentials, this.taskParameters.subscriptionId);
        this.azureUtils = new azure_utils.AzureUtil(this.taskParameters, this.computeClient);
    }
    addExtensionOnResourceGroup() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("AddingDGAgentOnVMs"));
            var listOfVms = yield this.azureUtils.getVMDetails();
            var extensionAddedOnVMsPromises = [];
            for (var vm of listOfVms) {
                extensionAddedOnVMsPromises.push(this.addExtensionOnSingleVM(vm));
            }
            yield Promise.all(extensionAddedOnVMsPromises);
            if (listOfVms.length > 0) {
                console.log(tl.loc("DGAgentAddedOnAllVMs"));
            }
        });
    }
    deleteExtensionFromResourceGroup() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("DeletingDGAgentOnVMs"));
            var listOfVms = yield this.azureUtils.getVMDetails();
            var deleteExtensionFromVmPromises = [];
            for (var vm of listOfVms) {
                deleteExtensionFromVmPromises.push(this.deleteExtensionFromSingleVM(vm));
            }
            yield Promise.all(deleteExtensionFromVmPromises);
            if (listOfVms.length > 0) {
                console.log(tl.loc("DGAgentDeletedFromAllVMs"));
            }
        });
    }
    deleteExtensionFromSingleVM(vm) {
        return new Promise((resolve, reject) => {
            var vmName = vm["name"];
            var extensionParameters = this.formExtensionParameters(vm, "delete");
            var extensionName = extensionParameters["extensionName"];
            console.log(tl.loc("DeleteExtension", extensionName, vmName));
            this.computeClient.virtualMachineExtensions.deleteMethod(this.taskParameters.resourceGroupName, vmName, az.ComputeResourceType.VirtualMachine, extensionName, (error, result, request, response) => {
                if (error) {
                    tl.warning(tl.loc("DeleteAgentManually", vmName, this.taskParameters.deploymentGroupName));
                    return reject(tl.loc("DeletionFailed", vmName, utils.getError(error)));
                }
                console.log(tl.loc("DeletionSucceeded", vmName));
                resolve();
            });
        });
    }
    addExtensionOnSingleVM(vm) {
        return __awaiter(this, void 0, void 0, function* () {
            var vmName = vm.name;
            var operation = "add";
            var vmWithInstanceView = yield this.getVmWithInstanceView(this.taskParameters.resourceGroupName, vmName, { expand: 'instanceView' });
            var vmPowerState = this.getVMPowerState(vmWithInstanceView);
            if (vmPowerState === "deallocated") {
                yield this.startVirtualMachine(vmName);
                vmPowerState = "running";
            }
            if (vmPowerState === "running") {
                yield this.addExtensionOnRunningVm(vm);
            }
            else {
                throw new Error(tl.loc("VMTransitioningSkipExtensionAddition", vmName));
            }
        });
    }
    getVMPowerState(vm) {
        var statuses = vm.properties.instanceView.statuses;
        for (var status of statuses) {
            if (status.code) {
                var properties = status.code.split("/");
                if (properties.length > 1 && properties[0] === "PowerState") {
                    return properties[1];
                }
            }
        }
        return null;
    }
    getVmWithInstanceView(resourceGroupName, vmName, object) {
        return new Promise((resolve, reject) => {
            var getVmWithInstanceViewCallback = (error, result, request, response) => {
                if (error) {
                    return reject(tl.loc("VMDetailsFetchFailed", vmName, utils.getError(error)));
                }
                console.log(tl.loc("VMDetailsFetchSucceeded", vmName));
                resolve(result);
            };
            this.computeClient.virtualMachines.get(resourceGroupName, vmName, object, getVmWithInstanceViewCallback);
        });
    }
    startVirtualMachine(vmName) {
        return new Promise((resolve, reject) => {
            this.computeClient.virtualMachines.start(this.taskParameters.resourceGroupName, vmName, (error, result, request, response) => __awaiter(this, void 0, void 0, function* () {
                if (error) {
                    console.log(utils.getError(error));
                    var isVMRunning = false;
                    try {
                        var vmWithInstanceView = yield this.getVmWithInstanceView(this.taskParameters.resourceGroupName, vmName, { expand: 'instanceView' });
                        var vmPowerState = this.getVMPowerState(vmWithInstanceView);
                        if (vmPowerState === "running") {
                            isVMRunning = true;
                        }
                    }
                    catch (exception) {
                        tl.warning(exception);
                    }
                    if (!isVMRunning) {
                        return reject(tl.loc("VMStartFailed", vmName, utils.getError(error)));
                    }
                }
                console.log(tl.loc("VMStarted", vmName));
                resolve(result);
            }));
        });
    }
    tryDeleteFailedExtension(vm) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.deleteExtensionFromSingleVM(vm);
            }
            catch (exception) {
                tl.warning(exception);
            }
        });
    }
    addExtensionOnRunningVm(vm) {
        return new Promise((resolve, reject) => {
            var vmName = vm.name;
            var extensionParameters = this.formExtensionParameters(vm, "add");
            var extensionName = extensionParameters["extensionName"];
            var parameters = extensionParameters["parameters"];
            this.computeClient.virtualMachineExtensions.get(this.taskParameters.resourceGroupName, vmName, az.ComputeResourceType.VirtualMachine, extensionName, null, (error, result, request, response) => __awaiter(this, void 0, void 0, function* () {
                if (result && result.properties.provisioningState === "Failed") {
                    yield this.tryDeleteFailedExtension(vm);
                }
                console.log(tl.loc("AddExtension", extensionName, vmName));
                this.computeClient.virtualMachineExtensions.createOrUpdate(this.taskParameters.resourceGroupName, vmName, az.ComputeResourceType.VirtualMachine, extensionName, parameters, (error, result, request, response) => __awaiter(this, void 0, void 0, function* () {
                    if (error) {
                        console.log(tl.loc("AddingExtensionFailed", extensionName, vmName, utils.getError(error)));
                        yield this.tryDeleteFailedExtension(vm);
                        return reject(tl.loc("DGAgentOperationOnAllVMsFailed", "addition", ""));
                    }
                    console.log(tl.loc("AddingExtensionSucceeded", extensionName, vmName));
                    resolve();
                }));
            }));
        });
    }
    formExtensionParameters(vm, operation) {
        var vmId = vm.id;
        var vmName = vm.name;
        console.log("virtual machine : " + vmName);
        var vmOsType = vm.properties.storageProfile.osDisk.osType;
        console.log("Operating system on virtual machine : " + vmOsType);
        var vmLocation = vm.location;
        if (vmOsType === "Windows") {
            var extensionName = this.dgExtensionNameWindows;
            var virtualMachineExtensionType = this.vmExtensionTypeWindows;
            var typeHandlerVersion = this.version;
        }
        else if (vmOsType === "Linux") {
            extensionName = this.dgExtensionNameLinux;
            virtualMachineExtensionType = this.vmExtensionTypeLinux;
            typeHandlerVersion = this.version;
        }
        console.log(tl.loc("DGAgentHandlerMajorVersion", typeHandlerVersion.split(".")[0]));
        if (operation === "add") {
            var autoUpgradeMinorVersion = true;
            var publisher = this.publisher;
            var extensionType = this.extensionType;
            var collectionUri = this.taskParameters.tokenCredentials.getHostUrl();
            var teamProject = this.taskParameters.deploymentGroupProjectName;
            var uriLength = collectionUri.length;
            if (collectionUri[uriLength - 1] === '/') {
                collectionUri = collectionUri.substr(0, uriLength - 1);
            }
            var tags = "";
            if (vm.tags && this.taskParameters.copyAzureVMTags) {
                console.log("Copying VM tags");
                tags = vm.tags;
            }
            var publicSettings = {
                VSTSAccountName: collectionUri,
                TeamProject: teamProject,
                DeploymentGroup: this.taskParameters.deploymentGroupName,
                AgentName: "",
                Tags: tags
            };
            console.log("Public settings are:\n VSTSAccountName: %s\nTeamProject: %s\nDeploymentGroup: %s\nTags: %s\n", collectionUri, teamProject, this.taskParameters.deploymentGroupName, JSON.stringify(tags));
            var protectedSettings = { PATToken: this.taskParameters.tokenCredentials.getPatToken() };
            if (this.taskParameters.runAgentServiceAsUser) {
                publicSettings["UserName"] = this.taskParameters.agentServiceUserCredentials.getUserName();
                if (vmOsType === "Windows") {
                    protectedSettings["Password"] = this.taskParameters.agentServiceUserCredentials.getPassword();
                }
            }
            var parameters = {
                type: extensionType,
                location: vmLocation,
                properties: {
                    publisher: publisher,
                    type: virtualMachineExtensionType,
                    typeHandlerVersion: typeHandlerVersion,
                    autoUpgradeMinorVersion: autoUpgradeMinorVersion,
                    settings: publicSettings,
                    protectedSettings: protectedSettings
                }
            };
        }
        return { vmName: vmName, extensionName: extensionName, parameters: parameters };
    }
}
exports.DeploymentGroupExtensionHelper = DeploymentGroupExtensionHelper;

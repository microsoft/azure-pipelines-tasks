"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const azureUtil = require("./AzureUtil");
class PropertyValue {
    constructor(data, isSecure) {
        this.Data = data;
        this.IsSecure = !!isSecure;
    }
}
class Resource {
    constructor(id, name) {
        this.Id = id;
        this.Name = name;
        this.Properties = {};
    }
    addOrUpdateProperty(type, property) {
        this.Properties[type] = property;
    }
}
class Project {
    constructor(id, name) {
        this.Id = id;
        this.Name = name;
    }
}
class User {
    constructor(name) {
        this.Name = name;
    }
}
class Environment {
    constructor(resources, userId, projectName, environmentName) {
        this.Id = 0;
        this.Name = environmentName;
        this.Url = null;
        this.Revision = 1;
        this.Project = new Project(projectName, projectName);
        this.Resources = resources;
        this.Properties = {
            "Microsoft-Vslabs-MG-WinRMProtocol": new PropertyValue("HTTPS"),
            "Microsoft-Vslabs-MG-SkipCACheck": new PropertyValue("False")
        };
        this.IsReserved = false;
        var user = new User(userId);
        this.CreatedBy = user;
        this.ModifiedBy = user;
        this.CreatedDate = this.formatDate(new Date());
        this.ModifiedDate = "0001-01-01T00:00:00";
    }
    pad(num) {
        return ("0" + num).slice(-2);
    }
    formatDate(d) {
        return [d.getUTCFullYear(),
            this.pad(d.getUTCMonth() + 1),
            this.pad(d.getUTCDate())].join("-") + "T" +
            [this.pad(d.getUTCHours()),
                this.pad(d.getUTCMinutes()),
                this.pad(d.getUTCSeconds())].join(":") + "Z";
    }
}
class EnvironmentHelper {
    constructor(taskParameters) {
        this.taskParameters = taskParameters;
    }
    RegisterEnvironment() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("RegisteringEnvironmentVariable", this.taskParameters.resourceGroupName));
            var azureUtilObject = new azureUtil.AzureUtil(this.taskParameters);
            var resourceGroupDetails = yield azureUtilObject.getResourceGroupDetails();
            this.instantiateEnvironment(resourceGroupDetails);
            console.log(tl.loc("AddedToOutputVariable", this.taskParameters.outputVariable));
        });
    }
    instantiateEnvironment(resourceGroupDetails) {
        var resources = this.getResources(resourceGroupDetails);
        tl.debug("Got resources..");
        var environment = new Environment(resources, process.env["SYSTEM_COLLECTIONID"], process.env["SYSTEM_TEAMPROJECT"], this.taskParameters.outputVariable);
        tl.setVariable(this.taskParameters.outputVariable, JSON.stringify(environment));
    }
    getResources(resourceGroupDetails) {
        var resources = new Array();
        var id = 1;
        for (var virtualMachine of resourceGroupDetails.VirtualMachines) {
            var fqdn = virtualMachine.WinRMHttpsPublicAddress;
            var resource = new Resource(id++, fqdn);
            resource.addOrUpdateProperty("Microsoft-Vslabs-MG-Resource-FQDN", new PropertyValue(fqdn));
            resource.addOrUpdateProperty("WinRM_Https", new PropertyValue(virtualMachine.WinRMHttpsPort.toString()));
            var tags = virtualMachine.Tags;
            if (tags) {
                for (var tag in tags) {
                    resource.addOrUpdateProperty(tag, new PropertyValue(tags[tag]));
                }
            }
            if (fqdn)
                resources.push(resource);
        }
        return resources;
    }
}
exports.EnvironmentHelper = EnvironmentHelper;

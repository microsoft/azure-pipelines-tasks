"use strict";
class Utils {
    static isNonEmpty(str) {
        return (!!str && !!str.trim());
    }
    static getError(error) {
        if (error && error.message) {
            return JSON.stringify(error.message);
        }
        return JSON.stringify(error);
    }
}
module.exports = Utils;

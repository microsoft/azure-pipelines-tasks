"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const deployAzureRG = require("./models/DeployAzureRG");
const virtualMachine = require("./operations/VirtualMachine");
const resourceGroup = require("./operations/ResourceGroup");
function run() {
    var azureRGTaskParameters = new deployAzureRG.AzureRGTaskParameters();
    return azureRGTaskParameters.getAzureRGTaskParameters().then((taskParameters) => {
        var resourceGroupOperationsController = new resourceGroup.ResourceGroup(taskParameters);
        var virtualMachineOperation = new virtualMachine.VirtualMachine(taskParameters);
        switch (taskParameters.action) {
            case "Create Or Update Resource Group":
                return resourceGroupOperationsController.createOrUpdateResourceGroup();
            case "DeleteRG":
                return resourceGroupOperationsController.deleteResourceGroup();
            case "Select Resource Group":
                return resourceGroupOperationsController.selectResourceGroup();
            case "Start":
            case "Stop":
            case "Restart":
            case "Delete":
            case "StopWithDeallocate":
                return virtualMachineOperation.execute();
            default:
                throw tl.loc("InvalidAction", taskParameters.action);
        }
    });
}
var taskManifestPath = path.join(__dirname, "task.json");
tl.debug("Setting resource path to " + taskManifestPath);
tl.setResourcePath(taskManifestPath);
run().then((result) => tl.setResult(tl.TaskResult.Succeeded, "")).catch((error) => tl.setResult(tl.TaskResult.Failed, error));

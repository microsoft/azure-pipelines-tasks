"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const path = require('path');
const tl = require('vsts-task-lib/task');
const sign = require('ios-signing-common/ios-signing-common');
const utils = require('./xcodeutils');
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            //clean up the temporary keychain, so it is not used to search for code signing identity in future builds
            var keychainToDelete = utils.getTaskState('XCODE_KEYCHAIN_TO_DELETE');
            if (keychainToDelete) {
                try {
                    yield sign.deleteKeychain(keychainToDelete);
                }
                catch (err) {
                    tl.debug('Failed to delete temporary keychain. Error = ' + err);
                    tl.warning(tl.loc('TempKeychainDeleteFailed', keychainToDelete));
                }
            }
            //delete provisioning profile if specified
            var profileToDelete = utils.getTaskState('XCODE_PROFILE_TO_DELETE');
            if (profileToDelete) {
                try {
                    yield sign.deleteProvisioningProfile(profileToDelete);
                }
                catch (err) {
                    tl.debug('Failed to delete provisioning profile. Error = ' + err);
                    tl.warning(tl.loc('ProvProfileDeleteFailed', profileToDelete));
                }
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
    });
}
run();

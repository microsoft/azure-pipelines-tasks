"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const task = require("vsts-task-lib/task");
const tool = require("vsts-task-tool-lib/tool");
const toolrunner_1 = require("vsts-task-lib/toolrunner");
const taskutil_1 = require("./taskutil");
/**
 * Whether `searchDir` has a `conda` executable for `platform`.
 * @param searchDir Absolute path to a directory to look for a `conda` executable in.
 * @param platform Platform whose executable type we want to use (i.e. `conda` vs `conda.exe`)
 * @returns Whether `searchDir` has a `conda` executable for `platform`.
 */
function hasConda(searchDir, platform) {
    const conda = platform === taskutil_1.Platform.Windows ?
        path.join(searchDir, 'Scripts', 'conda.exe') :
        path.join(searchDir, 'bin', 'conda');
    return fs.existsSync(conda) && fs.statSync(conda).isFile();
}
/**
 * Search the system for an existing Conda installation.
 * This function will check, in order:
 *   - the `CONDA` environment variable
 *   - `PATH`
 *   - The directory where the agent will install Conda if missing
 */
function findConda(platform) {
    const condaFromPath = task.which('conda');
    if (condaFromPath) {
        // On all platforms, the `conda` executable lives in a directory off the root of the installation
        return path.dirname(path.dirname(condaFromPath));
    }
    const condaFromEnvironment = task.getVariable('CONDA');
    if (condaFromEnvironment && hasConda(condaFromEnvironment, platform)) {
        return condaFromEnvironment;
    }
    return null;
}
exports.findConda = findConda;
/**
 * Add Conda's `python` and `conda` executables to PATH.
 * Precondition: Conda is installed at `condaRoot`
 * @param condaRoot Root directory or "prefix" of the Conda installation
 * @param platform Platform for which Conda is installed
 */
function prependCondaToPath(condaRoot, platform) {
    if (platform === taskutil_1.Platform.Windows) {
        // Windows: `python` lives in `condaRoot` and `conda` lives in `condaRoot\Scripts`
        tool.prependPath(condaRoot);
        tool.prependPath(path.join(condaRoot, 'Scripts'));
    }
    else {
        // Linux and macOS: `python` and `conda` both live in the `bin` directory
        tool.prependPath(path.join(condaRoot, 'bin'));
    }
}
exports.prependCondaToPath = prependCondaToPath;
function updateConda(condaRoot, platform) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const conda = (() => {
                if (platform === taskutil_1.Platform.Windows) {
                    return new toolrunner_1.ToolRunner(path.join(condaRoot, 'Scripts', 'conda.exe'));
                }
                else {
                    return new toolrunner_1.ToolRunner(path.join(condaRoot, 'bin', 'conda'));
                }
            })();
            conda.line('update --name base conda --yes');
            yield conda.exec();
        }
        catch (e) {
            // Best effort
        }
    });
}
exports.updateConda = updateConda;
/**
 * Create a Conda environment by running `conda create`.
 * Precondition: `conda` executable is in PATH
 * @param environmentPath Absolute path of the directory in which to create the environment. Will be created if it does not exist.
 * @param packageSpecs Optional list of Conda packages and versions to preinstall in the environment.
 * @param otherOptions Optional list of other options to pass to the `conda create` command.
 */
function createEnvironment(environmentPath, packageSpecs, otherOptions) {
    return __awaiter(this, void 0, void 0, function* () {
        const conda = task.tool('conda');
        conda.line(`create --quiet --prefix ${environmentPath} --mkdir --yes`);
        if (packageSpecs) {
            conda.line(packageSpecs);
        }
        if (otherOptions) {
            conda.line(otherOptions);
        }
        try {
            yield conda.exec();
        }
        catch (e) {
            // vsts-task-lib 2.5.0: `ToolRunner` does not localize its error messages
            throw new Error(task.loc('CreateFailed', environmentPath, e));
        }
    });
}
exports.createEnvironment = createEnvironment;
/**
 * Manually activate the environment by setting the variables touched by `conda activate` and prepending the environment to PATH.
 * This allows the environment to remain activated in subsequent build steps.
 */
function activateEnvironment(environmentsDir, environmentName, platform) {
    const environmentPath = path.join(environmentsDir, environmentName);
    prependCondaToPath(environmentPath, platform);
    // If Conda ever changes the names of the environment variables it uses to find its environment, this task will break.
    // For now we will assume these names are stable.
    // If we ever get broken, we should write code to run the activation script, diff the environment before and after,
    // and surface up the new environment variables as build variables.
    task.setVariable('CONDA_DEFAULT_ENV', environmentName);
    task.setVariable('CONDA_PREFIX', environmentPath);
}
exports.activateEnvironment = activateEnvironment;

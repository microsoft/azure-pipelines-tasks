"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const task = require("vsts-task-lib/task");
const taskutil_1 = require("./taskutil");
const conda_1 = require("./conda");
(() => __awaiter(this, void 0, void 0, function* () {
    try {
        task.setResourcePath(path.join(__dirname, 'task.json'));
        yield conda_1.condaEnvironment({
            environmentName: task.getInput('environmentName', true),
            packageSpecs: task.getInput('packageSpecs', false),
            updateConda: task.getBoolInput('updateConda', false),
            createOptions: task.getInput('createOptions', false),
            cleanEnvironment: task.getBoolInput('cleanEnvironment', false)
        }, taskutil_1.getPlatform());
        task.setResult(task.TaskResult.Succeeded, "");
    }
    catch (error) {
        task.error(error.message);
        task.setResult(task.TaskResult.Failed, error.message);
    }
}))();

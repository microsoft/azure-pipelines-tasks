"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const os = require("os");
const util = require("util");
const tl = require("vsts-task-lib/task");
const armCompute = require("azure-arm-rest/azure-arm-compute");
const armStorage = require("azure-arm-rest/azure-arm-storage");
const azureModel = require("azure-arm-rest/azureModels");
const BlobService = require("azure-blobstorage-artifactProvider/blobservice");
const compress = require("utility-common/compressutility");
const utils = require("./Utils");
class VirtualMachineScaleSet {
    constructor(taskParameters) {
        this.taskParameters = taskParameters;
    }
    execute() {
        return __awaiter(this, void 0, void 0, function* () {
            var client = new armCompute.ComputeManagementClient(this.taskParameters.credentials, this.taskParameters.subscriptionId);
            var result = yield this._getResourceGroupForVmss(client);
            var resourceGroupName = result.resourceGroupName;
            var osType = this.taskParameters.vmssOsType || result.osType;
            if (!resourceGroupName) {
                throw (tl.loc("FailedToGetRGForVMSS", this.taskParameters.vmssName));
            }
            switch (this.taskParameters.action) {
                case "UpdateImage":
                case "Update image":
                    yield this._configureAppUsingCustomScriptExtension(client, resourceGroupName, osType);
                    yield this._updateImageInternal(client, resourceGroupName);
                    break;
                case "Configure application startup":
                    yield this._configureAppUsingCustomScriptExtension(client, resourceGroupName, osType);
                    break;
                default:
                    throw tl.loc("InvalidAction", this.taskParameters.action);
            }
        });
    }
    _uploadCustomScriptsToBlobService(customScriptInfo) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("UploadingCustomScriptsBlobs", customScriptInfo.localDirPath));
            let storageDetails = customScriptInfo.storageAccount;
            let blobService = new BlobService.BlobService(storageDetails.name, storageDetails.primaryAccessKey);
            let blobsBaseUrl = util.format("%s%s/%s", storageDetails.primaryBlobUrl, "vststasks", customScriptInfo.blobsPrefixPath);
            console.log(tl.loc("DestinationBlobContainer", blobsBaseUrl));
            return yield blobService.uploadBlobs(customScriptInfo.localDirPath, "vststasks", customScriptInfo.blobsPrefixPath);
        });
    }
    _getStorageAccountDetails() {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug("Getting storage account details for " + this.taskParameters.customScriptsStorageAccount);
            var storageArmClient = new armStorage.StorageManagementClient(this.taskParameters.credentials, this.taskParameters.subscriptionId);
            let storageAccount = yield storageArmClient.storageAccounts.get(this.taskParameters.customScriptsStorageAccount);
            let storageAccountResourceGroupName = utils.getResourceGroupNameFromUri(storageAccount.id);
            tl.debug("Listing storage access keys...");
            let accessKeys = yield storageArmClient.storageAccounts.listKeys(storageAccountResourceGroupName, this.taskParameters.customScriptsStorageAccount, null);
            return {
                name: this.taskParameters.customScriptsStorageAccount,
                primaryBlobUrl: storageAccount.properties.primaryEndpoints.blob,
                resourceGroupName: storageAccountResourceGroupName,
                primaryAccessKey: accessKeys[0]
            };
        });
    }
    _configureAppUsingCustomScriptExtension(client, resourceGroupName, osType) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!!this.taskParameters.customScriptsDirectory && !!this.taskParameters.customScript) {
                tl.debug("Preparing custom scripts...");
                let customScriptInfo = yield this._prepareCustomScripts(osType);
                //return;
                var extensionMetadata = this._getCustomScriptExtensionMetadata(osType);
                var customScriptExtension = {
                    name: "AzureVmssDeploymentTask",
                    properties: {
                        type: extensionMetadata.type,
                        publisher: extensionMetadata.publisher,
                        typeHandlerVersion: extensionMetadata.typeHandlerVersion,
                        autoUpgradeMinorVersion: true,
                        settings: {
                            "commandToExecute": customScriptInfo.command,
                            "fileUris": customScriptInfo.blobUris
                        },
                        protectedSettings: {
                            "storageAccountName": customScriptInfo.storageAccount.name,
                            "storageAccountKey": customScriptInfo.storageAccount.primaryAccessKey
                        }
                    }
                };
                var matchingExtension = yield this._getExistingCustomScriptExtension(client, resourceGroupName, customScriptExtension);
                // if extension already exists, use the same name as the existing extension.
                if (!!matchingExtension) {
                    customScriptExtension.name = matchingExtension.name;
                }
                yield this._installCustomScriptExtension(client, resourceGroupName, customScriptExtension);
            }
        });
    }
    _prepareCustomScripts(osType) {
        return __awaiter(this, void 0, void 0, function* () {
            // try to archive custom scripts so that it is more robust to transfer
            let archiveInfo = this._archiveCustomScripts(osType);
            let customScriptInfo = this._createCustomScriptInvoker(osType, archiveInfo);
            // upload custom script directory to blob storage
            try {
                var storageArmClient = new armStorage.StorageManagementClient(this.taskParameters.credentials, this.taskParameters.subscriptionId);
                customScriptInfo.storageAccount = yield this._getStorageAccountDetails();
                customScriptInfo.blobUris = yield this._uploadCustomScriptsToBlobService(customScriptInfo);
            }
            catch (error) {
                throw tl.loc("UploadingToStorageBlobsFailed", error.message ? error.message : error);
            }
            return customScriptInfo;
        });
    }
    _createCustomScriptInvoker(osType, archiveInfo) {
        let invokerScriptPath;
        let invokerCommand;
        let archiveFile = "";
        let packageDirectory = this.taskParameters.customScriptsDirectory;
        if (!!archiveInfo) {
            packageDirectory = archiveInfo.directory;
            archiveFile = archiveInfo.fileName;
        }
        let blobsPefixPath = this._getBlobsPrefixPath();
        if (osType === "Windows") {
            // escape powershell special characters. This is needed as this script will be executed in a powershell session
            let script = this.taskParameters.customScript.replace(/`/g, '``').replace(/\$/g, '`$');
            // put an extra quote to handle space in script name
            let quotedScript = `.\\\\"${script}\"`;
            // and escape quotes to handle this extra quote
            let escapedScript = quotedScript.replace(/'/g, "''").replace(/"/g, '"""');
            // escape powershell special characters
            let escapedArgs = "";
            if (this.taskParameters.customScriptArguments) {
                escapedArgs = this.taskParameters.customScriptArguments.replace(/`/g, '``').replace(/\$/g, '`$').replace(/'/g, "''").replace(/"/g, '"""');
            }
            invokerScriptPath = path.join(__dirname, "..", "Resources", "customScriptInvoker.ps1");
            invokerCommand = `powershell ./${blobsPefixPath}/customScriptInvoker.ps1 -zipName '${archiveFile}' -script '${escapedScript}' -scriptArgs '${escapedArgs}' -prefixPath '${blobsPefixPath}'`;
        }
        else {
            // escape shell special characters. This is needed as this script will be executed in a shell
            let script = this.taskParameters.customScript.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/`/g, '\\`').replace(/\$/g, '\\$');
            // put an extra quote to handle space in script name
            let quotedScript = `./\"${script}\"`;
            // and escape quotes to handle this extra quote...
            let escapedScript = quotedScript.replace(/'/g, "'\"'\"'");
            // escape shell special characters
            let escapedArgs = "";
            if (this.taskParameters.customScriptArguments) {
                escapedArgs = this.taskParameters.customScriptArguments.replace(/`/g, '\\`').replace(/\$/g, '\\$').replace(/'/g, "'\"'\"'");
            }
            invokerScriptPath = path.join(__dirname, "..", "Resources", "customScriptInvoker.sh");
            invokerCommand = `./customScriptInvoker.sh '${archiveFile}' '${escapedScript}' '${escapedArgs}'`;
        }
        // copy invoker script to same dir as archive
        tl.cp(invokerScriptPath, packageDirectory, "-f", false);
        console.log(tl.loc("CopiedInvokerScript", packageDirectory));
        tl.debug("Invoker command: " + invokerCommand);
        return {
            localDirPath: packageDirectory,
            command: invokerCommand,
            blobsPrefixPath: blobsPefixPath
        };
    }
    _archiveCustomScripts(osType) {
        if (!this.taskParameters.skipArchivingCustomScripts) {
            try {
                console.log(tl.loc("ArchivingCustomScripts", this.taskParameters.customScriptsDirectory));
                let archive = this._computeArchiveDetails(osType);
                if (!tl.exist(archive.directory)) {
                    tl.mkdirP(archive.directory);
                }
                // create archive file
                compress.createArchive(this.taskParameters.customScriptsDirectory, archive.compression, archive.filePath);
                console.log(tl.loc("CustomScriptsArchiveFile", archive.filePath));
                return archive;
            }
            catch (error) {
                tl.warning(tl.loc("CustomScriptsArchivingFailed") + " Error: " + error);
            }
        }
        else {
            console.log(tl.loc("SkippedArchivingCustomScripts"));
        }
        return null;
    }
    _getResourceGroupForVmss(client) {
        return new Promise((resolve, reject) => {
            client.virtualMachineScaleSets.list(null, (error, result, request, response) => {
                if (error) {
                    return reject(tl.loc("VMSSListFetchFailed", utils.getError(error)));
                }
                var vmssList = result;
                if (vmssList.length == 0) {
                    console.log(tl.loc("NoVMSSFound", this.taskParameters.vmssName));
                    return resolve();
                }
                var resourceGroupName;
                var osType;
                for (var i = 0; i < vmssList.length; i++) {
                    if (vmssList[i].name.toUpperCase() === this.taskParameters.vmssName.toUpperCase()) {
                        resourceGroupName = utils.getResourceGroupNameFromUri(vmssList[i].id);
                        osType = vmssList[i].properties.virtualMachineProfile.storageProfile.osDisk.osType;
                        break;
                    }
                }
                return resolve({ resourceGroupName: resourceGroupName, osType: osType });
            });
        });
    }
    _getExistingCustomScriptExtension(client, resourceGroupName, customScriptExtension) {
        return new Promise((resolve, reject) => {
            client.virtualMachineExtensions.list(resourceGroupName, this.taskParameters.vmssName, azureModel.ComputeResourceType.VirtualMachineScaleSet, null, (error, result, request, response) => {
                if (error) {
                    // Just log warning, do not fail
                    tl.warning(tl.loc("GetVMSSExtensionsListFailed", this.taskParameters.vmssName, utils.getError(error)));
                }
                var extensions = result || [];
                var matchingExtension = null;
                extensions.forEach((extension) => {
                    if (extension.properties.type === customScriptExtension.properties.type &&
                        extension.properties.publisher === customScriptExtension.properties.publisher) {
                        matchingExtension = extension;
                        return;
                    }
                });
                return resolve(matchingExtension);
            });
        });
    }
    _installCustomScriptExtension(client, resourceGroupName, customScriptExtension) {
        return new Promise((resolve, reject) => {
            client.virtualMachineExtensions.createOrUpdate(resourceGroupName, this.taskParameters.vmssName, azureModel.ComputeResourceType.VirtualMachineScaleSet, customScriptExtension.name, customScriptExtension, (error, result, request, response) => {
                if (error) {
                    return reject(tl.loc("SettingVMExtensionFailed", utils.getError(error)));
                }
                console.log(tl.loc("CustomScriptExtensionInstalled", customScriptExtension.name));
                return resolve();
            });
        });
    }
    _updateImageInternal(client, resourceGroupName) {
        return new Promise((resolve, reject) => {
            client.virtualMachineScaleSets.updateImage(resourceGroupName, this.taskParameters.vmssName, this.taskParameters.imageUrl, null, (error, result, request, response) => {
                if (error) {
                    return reject(tl.loc("VMSSImageUpdateFailed", this.taskParameters.vmssName, utils.getError(error)));
                }
                console.log(tl.loc("UpdatedVMSSImage"));
                return resolve();
            });
        });
    }
    _getCustomScriptExtensionMetadata(osType) {
        if (osType === "Windows") {
            return {
                type: "CustomScriptExtension",
                publisher: "Microsoft.Compute",
                typeHandlerVersion: "1.0"
            };
        }
        else if (osType === "Linux") {
            return {
                type: "CustomScript",
                publisher: "Microsoft.Azure.Extensions",
                typeHandlerVersion: "2.0"
            };
        }
    }
    _computeArchiveDetails(osType) {
        let archive = {};
        // create temp dir to store archived scripts
        // TODO: delete this dir
        archive.directory = path.join(os.tmpdir(), "vstsvmss" + Date.now().toString());
        // create archive name based on release/build info
        let archiveFileName = "cs";
        let archiveExt = osType === "Windows" ? ".zip" : ".tar.gz";
        archive.fileName = archiveFileName + archiveExt;
        archive.filePath = path.join(archive.directory, archive.fileName);
        // create zip archive for windows and .tar.gz archive for others
        // this will ensure that extracting archive is natively supported on VM
        archive.compression = osType === "Windows" ? "zip" : "targz";
        return archive;
    }
    _getBlobsPrefixPath() {
        let uniqueValue = Date.now().toString();
        let releaseId = tl.getVariable("release.releaseid");
        let environmentId = tl.getVariable("release.environmentid");
        let releaseAttempt = tl.getVariable("release.attemptnumber");
        let prefixFolderPath = null;
        if (!!releaseId && !!environmentId && !!releaseAttempt) {
            prefixFolderPath = util.format("%s-%s/%s/%s", releaseId, uniqueValue, environmentId, releaseAttempt);
        }
        else {
            prefixFolderPath = util.format("%s-%s", tl.getVariable("build.buildid"), uniqueValue);
        }
        return prefixFolderPath;
    }
}
exports.default = VirtualMachineScaleSet;
class StorageAccountInfo {
}
class CustomScriptsInfo {
}
class ArchiveInfo {
}
//# sourceMappingURL=VirtualMachineScaleSet.js.map
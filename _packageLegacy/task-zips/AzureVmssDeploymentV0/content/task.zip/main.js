"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const AzureVmssTaskParameters_1 = require("./models/AzureVmssTaskParameters");
const VirtualMachineScaleSet_1 = require("./operations/VirtualMachineScaleSet");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        var taskParameters = yield new AzureVmssTaskParameters_1.default().getAzureVmssTaskParameters();
        var vmssOperation = new VirtualMachineScaleSet_1.default(taskParameters);
        yield vmssOperation.execute();
    });
}
var taskManifestPath = path.join(__dirname, "task.json");
tl.debug("Setting resource path to " + taskManifestPath);
tl.setResourcePath(taskManifestPath);
run().then((result) => tl.setResult(tl.TaskResult.Succeeded, "")).catch((error) => tl.setResult(tl.TaskResult.Failed, error));
//# sourceMappingURL=main.js.map
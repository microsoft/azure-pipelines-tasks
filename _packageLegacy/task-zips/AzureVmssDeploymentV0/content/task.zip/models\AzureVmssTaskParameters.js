"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const azure_arm_endpoint_1 = require("azure-arm-rest/azure-arm-endpoint");
class AzureVmssTaskParameters {
    getAzureVmssTaskParameters() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                var connectedService = tl.getInput("ConnectedServiceName", true);
                this.subscriptionId = tl.getEndpointDataParameter(connectedService, "SubscriptionId", true);
                this.vmssName = tl.getInput("vmssName", true);
                this.vmssOsType = tl.getInput("vmssOsType", false);
                this.imageUrl = tl.getInput("imageUrl", false);
                this.action = tl.getInput("action");
                this.customScriptsDirectory = tl.getInput("customScriptsDirectory");
                this.customScript = tl.getInput("customScript");
                this.customScriptArguments = tl.getInput("customScriptArguments");
                this.customScriptsStorageAccount = tl.getInput("customScriptsStorageAccount");
                this.skipArchivingCustomScripts = tl.getBoolInput("skipArchivingCustomScripts");
                this.credentials = yield this.getARMCredentials(connectedService);
                return this;
            }
            catch (error) {
                throw new Error(tl.loc("TaskConstructorFailed", error.message));
            }
        });
    }
    getARMCredentials(connectedService) {
        return __awaiter(this, void 0, void 0, function* () {
            var azureEndpoint = yield new azure_arm_endpoint_1.AzureRMEndpoint(connectedService).getEndpoint();
            return azureEndpoint.applicationTokenCredentials;
        });
    }
}
exports.default = AzureVmssTaskParameters;
//# sourceMappingURL=AzureVmssTaskParameters.js.map
"use strict";
const path = require("path");
const tl = require("vsts-task-lib/task");
class Utils {
    static isNonEmpty(str) {
        return (!!str && !!str.trim());
    }
    static getError(error) {
        if (error && error.message) {
            return error.message;
        }
        return error;
    }
    static getResourceGroupNameFromUri(resourceUri) {
        if (Utils.isNonEmpty(resourceUri)) {
            resourceUri = resourceUri.toLowerCase();
            return resourceUri.substring(resourceUri.indexOf("resourcegroups/") + "resourcegroups/".length, resourceUri.indexOf("/providers"));
        }
        return "";
    }
    static normalizeRelativePath(inputPath) {
        if (tl.osType().match(/^Win/)) {
            var splitPath = inputPath.split(path.sep);
            return path.posix.join.apply(null, splitPath);
        }
        return inputPath;
    }
}
module.exports = Utils;
//# sourceMappingURL=Utils.js.map
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const task = require("vsts-task-lib/task");
const internal = require("./conda_internal");
/**
 * Check for a parameter at runtime.
 * Useful for conditionally-visible, required parameters.
 */
function assertParameter(value, propertyName) {
    if (!value) {
        throw new Error(task.loc('ParameterRequired', propertyName));
    }
    return value;
}
function condaEnvironment(parameters, platform) {
    return __awaiter(this, void 0, void 0, function* () {
        // Find Conda on the system
        const condaRoot = yield (() => __awaiter(this, void 0, void 0, function* () {
            const preinstalledConda = internal.findConda(platform);
            if (preinstalledConda) {
                return preinstalledConda;
            }
            else {
                throw new Error(task.loc('CondaNotFound'));
            }
        }))();
        if (parameters.updateConda) {
            yield internal.updateConda(condaRoot, platform);
        }
        internal.prependCondaToPath(condaRoot, platform);
        if (parameters.createCustomEnvironment) {
            const environmentName = assertParameter(parameters.environmentName, 'environmentName');
            const environmentsDir = path.join(condaRoot, 'envs');
            const environmentPath = path.join(environmentsDir, environmentName);
            if (fs.existsSync(environmentPath) && !parameters.cleanEnvironment) {
                console.log(task.loc('ReactivateExistingEnvironment', environmentPath));
            }
            else {
                if (fs.existsSync(environmentPath)) {
                    console.log(task.loc('CleanEnvironment', environmentPath));
                    task.rmRF(environmentPath);
                }
                yield internal.createEnvironment(environmentPath, parameters.packageSpecs, parameters.createOptions);
            }
            internal.activateEnvironment(environmentsDir, environmentName, platform);
        }
        else if (parameters.packageSpecs) {
            internal.installPackagesGlobally(parameters.packageSpecs, parameters.installOptions);
        }
    });
}
exports.condaEnvironment = condaEnvironment;

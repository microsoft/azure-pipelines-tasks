"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const fs = require("fs");
const armStorage = require("azure-arm-rest/azure-arm-storage");
const azure_arm_endpoint_1 = require("azure-arm-rest/azure-arm-endpoint");
function isNonEmpty(str) {
    return (!!str && !!str.trim());
}
function getResourceGroupNameFromUri(resourceUri) {
    if (isNonEmpty(resourceUri)) {
        resourceUri = resourceUri.toLowerCase();
        return resourceUri.substring(resourceUri.indexOf("resourcegroups/") + "resourcegroups/".length, resourceUri.indexOf("/providers"));
    }
    return "";
}
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        let tempDirectory = tl.getVariable('Agent.TempDirectory');
        let fileName = Math.random().toString(36).replace('0.', '');
        let file = path.resolve(tempDirectory, fileName);
        try {
            const taskManifestPath = path.join(__dirname, "task.json");
            tl.debug("Setting resource path to " + taskManifestPath);
            tl.setResourcePath(taskManifestPath);
            let connectionType = tl.getInput('ConnectedServiceNameSelector', true);
            if (connectionType === 'ConnectedServiceNameARM') {
                let connectedServiceName = tl.getInput('ConnectedServiceNameARM', true);
                let storageAccountName = tl.getInput('StorageAccountRM', true);
                var azureEndpoint = yield new azure_arm_endpoint_1.AzureRMEndpoint(connectedServiceName).getEndpoint();
                const storageArmClient = new armStorage.StorageManagementClient(azureEndpoint.applicationTokenCredentials, azureEndpoint.subscriptionID);
                let storageAccount = yield storageArmClient.storageAccounts.get(storageAccountName);
                let storageAccountResourceGroupName = getResourceGroupNameFromUri(storageAccount.id);
                let accessKeys = yield storageArmClient.storageAccounts.listKeys(storageAccountResourceGroupName, storageAccountName, null);
                let accessKey = accessKeys[0];
                let data = `/DestKey:\"${accessKey}\"`;
                let options = { encoding: "utf8" };
                fs.writeFileSync(file, data, options);
                tl.setTaskVariable('AFC_V2_ARM_STORAGE_KEY_FILE', file);
                tl.debug("Response file created");
            }
        }
        catch (error) {
            if (fs.existsSync(file)) {
                fs.unlinkSync(file);
            }
            console.log(tl.loc("AFC_PreexecutionJob_UnableToGetStorageKey", error));
        }
    });
}
run();

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const toolLib = require("vsts-task-tool-lib/tool");
const tl = require("vsts-task-lib/task");
const os = require("os");
const path = require("path");
const util = require("util");
let osPlat = os.platform();
let osArch = os.arch();
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let version = tl.getInput('version', true).trim();
            yield getGo(version);
        }
        catch (error) {
            tl.setResult(tl.TaskResult.Failed, error);
        }
    });
}
function getGo(version) {
    return __awaiter(this, void 0, void 0, function* () {
        // check cache
        let toolPath;
        toolPath = toolLib.findLocalTool('go', fixVersion(version));
        if (!toolPath) {
            // download, extract, cache
            toolPath = yield acquireGo(version);
            tl.debug("Go tool is cached under " + toolPath);
        }
        setGoEnvironmentVariables(toolPath);
        toolPath = path.join(toolPath, 'bin');
        //
        // prepend the tools path. instructs the agent to prepend for future tasks
        //
        toolLib.prependPath(toolPath);
    });
}
function acquireGo(version) {
    return __awaiter(this, void 0, void 0, function* () {
        //
        // Download - a tool installer intimately knows how to get the tool (and construct urls)
        //
        let fileName = getFileName(version);
        let downloadUrl = getDownloadUrl(fileName);
        let downloadPath = null;
        try {
            downloadPath = yield toolLib.downloadTool(downloadUrl);
        }
        catch (error) {
            tl.debug(error);
            // cannot localized the string here because to localize we need to set the resource file.
            // which can be set only once. vsts-task-tool-lib/tool, is already setting it to different file.
            // So left with no option but to hardcode the string. Other tasks are doing the same.
            throw (util.format("Failed to download version %s. Please verify that the version is valid and resolve any other issues. %s", version, error));
        }
        //make sure agent version is latest then 2.115.0
        tl.assertAgent('2.115.0');
        //
        // Extract
        //
        let extPath;
        extPath = tl.getVariable('Agent.TempDirectory');
        if (!extPath) {
            throw new Error("Expected Agent.TempDirectory to be set");
        }
        if (osPlat == 'win32') {
            extPath = yield toolLib.extractZip(downloadPath);
        }
        else {
            extPath = yield toolLib.extractTar(downloadPath);
        }
        //
        // Install into the local tool cache - node extracts with a root folder that matches the fileName downloaded
        //
        let toolRoot = path.join(extPath, "go");
        version = fixVersion(version);
        return yield toolLib.cacheDir(toolRoot, 'go', version);
    });
}
function getFileName(version) {
    let platform = osPlat == "win32" ? "windows" : osPlat;
    let arch = osArch == "x64" ? "amd64" : "386";
    let ext = osPlat == "win32" ? "zip" : "tar.gz";
    let filename = util.format("go%s.%s-%s.%s", version, platform, arch, ext);
    return filename;
}
function getDownloadUrl(filename) {
    return util.format("https://storage.googleapis.com/golang/%s", filename);
}
function setGoEnvironmentVariables(goRoot) {
    tl.setVariable('GOROOT', goRoot);
    let goPath = tl.getInput("goPath", false);
    let goBin = tl.getInput("goBin", false);
    // set GOPATH and GOBIN as user value
    if (!util.isNullOrUndefined(goPath)) {
        tl.setVariable("GOPATH", goPath);
    }
    if (!util.isNullOrUndefined(goBin)) {
        tl.setVariable("GOBIN", goBin);
    }
}
// This function is required to convert the version 1.10 to 1.10.0.
// Because caching utility accept only sementic version,
// which have patch number as well.
function fixVersion(version) {
    let versionPart = version.split(".");
    if (versionPart[1] == null) {
        //append minor and patch version if not available
        return version.concat(".0.0");
    }
    else if (versionPart[2] == null) {
        //append patch version if not available
        return version.concat(".0");
    }
    return version;
}
run();

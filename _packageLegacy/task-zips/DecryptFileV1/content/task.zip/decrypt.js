"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const tl = require("vsts-task-lib/task");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            //Process working directory
            var cwd = tl.getInput('cwd') || tl.getVariable('System.DefaultWorkingDirectory');
            tl.cd(cwd);
            var openssl = tl.tool(tl.which('openssl', true));
            openssl.arg(tl.getInput('cipher', true));
            var inFile = tl.getInput('inFile', true);
            openssl.arg(['-d', '-in', inFile]);
            openssl.arg('-out');
            var outFile = tl.getPathInput('outFile', false);
            if (fs.existsSync(outFile) && fs.lstatSync(outFile).isDirectory()) {
                openssl.arg(inFile + '.out');
            }
            else {
                openssl.arg(outFile);
            }
            openssl.arg(['-pass', 'pass:' + tl.getInput('passphrase')]);
            var code = yield openssl.exec();
            tl.setResult(tl.TaskResult.Succeeded, tl.loc('OpenSSLReturnCode', code));
        }
        catch (err) {
            tl.error(err.message);
            tl.setResult(tl.TaskResult.Failed, tl.loc('OpenSSLFailed', err.message));
        }
    });
}
run();

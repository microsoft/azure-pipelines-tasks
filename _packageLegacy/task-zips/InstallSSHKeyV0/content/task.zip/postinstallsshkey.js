"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const ps = require("process");
const util = require("./installsshkey-util");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            util.tryRestoreKnownHosts();
            let agentPid = tl.getTaskVariable(util.postKillAgentSetting);
            if (agentPid) {
                tl.debug('Killing SSH Agent PID: ' + agentPid);
                ps.kill(+agentPid);
            }
            else {
                let deleteKey = tl.getTaskVariable(util.postDeleteKeySetting);
                let sshTool = new util.SshToolRunner();
                sshTool.deleteKey(deleteKey);
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
    });
}
run();

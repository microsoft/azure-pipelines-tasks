"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const os = require("os");
const Q = require("q");
const path = require("path");
const process = require("process");
const child = require("child_process");
const tl = require("vsts-task-lib/task");
exports.postKillAgentSetting = 'INSTALL_SSH_KEY_KILL_SSH_AGENT_PID';
exports.postDeleteKeySetting = 'INSTALL_SSH_KEY_DELETE_KEY';
exports.postKnownHostsContentsSetting = 'INSTALL_SSH_KEY_KNOWN_HOSTS_CONTENTS';
exports.postKnownHostsLocationSetting = 'INSTALL_SSH_KEY_KNOWN_HOSTS_LOCATION';
exports.postKnownHostsDeleteFileSetting = 'INSTALL_SSH_KEY_KNOWN_HOSTS_FILE_DELETE';
exports.sshAgentPidEnvVariableKey = 'SSH_AGENT_PID';
exports.sshAgentSockEnvVariableKey = 'SSH_AUTH_SOCK';
function execSshAddPassphraseSync(tool, args, passphrase) {
    tl.debug('execSshAddPassphraseSync');
    var defer = Q.defer();
    let success = true;
    let cp = child.spawn(tool, args, {
        detached: true // required to work on macOS
    });
    var processLineBuffer = (data, strBuffer, onLine) => {
        try {
            var s = strBuffer + data.toString();
            var n = s.indexOf(os.EOL);
            while (n > -1) {
                var line = s.substring(0, n);
                onLine(line);
                // the rest of the string ...
                s = s.substring(n + os.EOL.length);
                n = s.indexOf(os.EOL);
            }
            strBuffer = s;
        }
        catch (err) {
            tl.debug('error processing line');
        }
    };
    var stdbuffer = '';
    cp.stdout.on('data', (data) => {
        process.stdout.write(data);
        processLineBuffer(data, stdbuffer, (line) => {
            tl.debug('stdline:' + line);
        });
    });
    var errbuffer = '';
    cp.stderr.on('data', (data) => {
        // ssh-add puts output on stderr
        process.stderr.write(data);
        processLineBuffer(data, errbuffer, (line) => {
            tl.debug('errline:' + line);
        });
    });
    cp.on('error', (err) => {
        defer.reject(new Error(tool + ' failed. ' + err.message));
    });
    cp.on('close', (code, signal) => {
        tl.debug('rc:' + code);
        if (stdbuffer.length > 0) {
            tl.debug('stdline:' + stdbuffer);
        }
        if (errbuffer.length > 0) {
            tl.debug('errline:' + errbuffer);
        }
        // Always ignore the return code
        tl.debug('success:' + success);
        if (!success) {
            defer.reject(new Error(tool + ' failed with return code: ' + code));
        }
        else {
            defer.resolve(success);
        }
    });
    tl.debug('writing passphrase');
    cp.stdin.write(passphrase);
    cp.stdin.end();
    tl.debug('passphrase complete');
    return defer.promise;
}
class SshToolRunner {
    constructor() {
        this.baseDir = tl.getVariable('Agent.HomeDirectory');
        this.sshGitExternalsDir = path.join('externals', path.join('Git', path.join('usr', path.join('bin'))));
    }
    getExecutable(executable) {
        let isWindows = os.type().match(/^Win/);
        if (isWindows && this.baseDir) {
            executable = path.join(this.baseDir, path.join(this.sshGitExternalsDir, executable));
            executable += '.exe';
        }
        return executable;
    }
    runAgent() {
        // Expected output sample:
        // SSH_AUTH_SOCK=/tmp/ssh-XVblDhTvcbC3/agent.24196; export SSH_AUTH_SOCK;
        // SSH_AGENT_PID=4644; export SSH_AGENT_PID; echo Agent pid 4644;
        let agentResults = tl.execSync(this.getExecutable('ssh-agent'), null);
        let elements = agentResults.stdout.split(';');
        for (let i = 0; i < elements.length; ++i) {
            let keyValue = elements[i].split('=');
            if (keyValue && keyValue.length >= 2) {
                let key = keyValue[0].trim();
                let value = keyValue[1].trim();
                tl.debug('Key=' + key + ' value=' + value);
                if (exports.sshAgentPidEnvVariableKey === key) {
                    tl.setVariable(key, value);
                    tl.setTaskVariable(exports.postKillAgentSetting, value);
                }
                else if (exports.sshAgentSockEnvVariableKey === key) {
                    tl.setVariable(key, value);
                }
            }
            else {
                tl.debug('Skipping ' + elements[i]);
            }
        }
    }
    installKey(publicKey, privateKeyLocation, passphrase) {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug('Get a list of the SSH keys in the agent');
            let results = tl.execSync(this.getExecutable('ssh-add'), '-L');
            let publicKeyComponents = publicKey.split(' ');
            if (publicKeyComponents.length <= 1) {
                throw tl.loc('SSHPublicKeyMalformed');
            }
            let publicKeyHash = publicKeyComponents[1];
            tl.debug('Checking for public SSH key: ' + publicKeyHash);
            if (results.stdout.indexOf(publicKeyHash) !== -1) {
                throw tl.loc('SSHKeyAlreadyInstalled');
            }
            tl.debug('Adding the SSH key to the agent ' + privateKeyLocation);
            let oldMode = fs.statSync(privateKeyLocation).mode;
            fs.chmodSync(privateKeyLocation, '600'); // requires user only permissions when adding to agent
            let installedSSH = false;
            if (passphrase) {
                installedSSH = yield execSshAddPassphraseSync(this.getExecutable('ssh-add'), [privateKeyLocation], passphrase);
            }
            else {
                results = tl.execSync(this.getExecutable('ssh-add'), privateKeyLocation);
                installedSSH = !results.error;
            }
            if (!installedSSH) {
                throw tl.loc('SSHKeyInstallFailed');
            }
            fs.chmodSync(privateKeyLocation, oldMode);
            tl.setTaskVariable(exports.postDeleteKeySetting, privateKeyLocation);
            results = tl.execSync(this.getExecutable('ssh-add'), null);
        });
    }
    deleteKey(key) {
        let deleteKey = tl.getTaskVariable(exports.postDeleteKeySetting);
        if (deleteKey) {
            tl.debug('Deleting Key: ' + deleteKey);
            tl.execSync(path.join(external, 'ssh-add.exe'), ['-d', deleteKey]);
        }
    }
}
exports.SshToolRunner = SshToolRunner;
function setKnownHosts(knownHostsEntry) {
    let knownHostsFolder = path.join(os.homedir(), '.ssh');
    let knownHostsFile = path.join(knownHostsFolder, 'known_hosts');
    let knownHostsContent = '';
    let knownHostsDeleteFileOnClose = 'true';
    if (!fs.existsSync(knownHostsFolder)) {
        fs.mkdirSync(knownHostsFolder);
    }
    else if (fs.existsSync(knownHostsFile)) {
        tl.debug('Read known_hosts');
        knownHostsDeleteFileOnClose = '';
        knownHostsContent = fs.readFileSync(knownHostsFile).toString();
    }
    tl.setTaskVariable(exports.postKnownHostsContentsSetting, knownHostsContent);
    tl.setTaskVariable(exports.postKnownHostsLocationSetting, knownHostsFile);
    tl.setTaskVariable(exports.postKnownHostsDeleteFileSetting, knownHostsDeleteFileOnClose);
    tl.debug('Inserting entry into known_hosts');
    fs.writeFileSync(knownHostsFile, knownHostsEntry + os.EOL);
}
exports.setKnownHosts = setKnownHosts;
function tryRestoreKnownHosts() {
    let knownHostsContents = tl.getTaskVariable(exports.postKnownHostsContentsSetting);
    let knownHostsLocation = tl.getTaskVariable(exports.postKnownHostsLocationSetting);
    let knownHostsDeleteFileOnExit = tl.getTaskVariable(exports.postKnownHostsDeleteFileSetting);
    tl.debug('Restoring known_hosts');
    if (knownHostsDeleteFileOnExit && knownHostsLocation) {
        fs.unlinkSync(knownHostsLocation);
    }
    else if (knownHostsContents && knownHostsLocation) {
        fs.writeFileSync(knownHostsLocation, knownHostsContents);
    }
    else if (knownHostsLocation || knownHostsContents) {
        tl.warning(tl.loc('CannotResetKnownHosts'));
        tl.debug('(location=' + knownHostsLocation + ' content=' + knownHostsContents + ')');
    }
}
exports.tryRestoreKnownHosts = tryRestoreKnownHosts;

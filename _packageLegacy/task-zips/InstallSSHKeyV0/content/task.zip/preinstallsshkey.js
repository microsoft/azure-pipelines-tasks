"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const secureFilesCommon = require("securefiles-common/securefiles-common");
const tl = require("vsts-task-lib/task");
const util = require("./installsshkey-util");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        let secureFileId;
        let secureFileHelpers;
        try {
            let publicKey = tl.getInput('sshPublicKey', true).trim();
            let knownHostsEntry = tl.getInput('hostName', true).trim();
            let passphrase = tl.getInput('sshPassphrase', false);
            passphrase = !passphrase ? passphrase : passphrase.trim();
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // download ssh key contents
            secureFileId = tl.getInput('sshKeySecureFile', true);
            secureFileHelpers = new secureFilesCommon.SecureFileHelpers();
            let privateKeyLocation = yield secureFileHelpers.downloadSecureFile(secureFileId);
            let sshTool = new util.SshToolRunner();
            let pid = tl.getVariable(util.sshAgentPidEnvVariableKey);
            let sock = tl.getVariable(util.sshAgentSockEnvVariableKey);
            tl.debug('PID=' + pid + ' SOCK=' + sock);
            if (!pid || !sock) {
                sshTool.runAgent();
            }
            yield sshTool.installKey(publicKey, privateKeyLocation, passphrase);
            util.setKnownHosts(knownHostsEntry);
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
        finally {
            // delete SSH key from temp location after installing
            if (secureFileId && secureFileHelpers) {
                secureFileHelpers.deleteSecureFile(secureFileId);
            }
        }
        tl.debug('End');
    });
}
run();

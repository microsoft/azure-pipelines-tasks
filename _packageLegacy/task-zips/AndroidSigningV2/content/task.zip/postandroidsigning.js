"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const tl = require("vsts-task-lib/task");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        let secureFileHelpers;
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            let keystoreFile = tl.getTaskVariable('KEYSTORE_FILE_PATH');
            if (keystoreFile && tl.exist(keystoreFile)) {
                fs.unlinkSync(keystoreFile);
                tl.debug('Deleted keystore file downloaded from the server: ' + keystoreFile);
            }
        }
        catch (err) {
            tl.warning(tl.loc('DeleteKeystoreFileFailed', err));
        }
    });
}
run();

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const del = require("del");
const path = require("path");
const tl = require("vsts-task-lib/task");
const dockercomposedigests_1 = require("./dockercomposedigests");
const dockercomposeconfig_1 = require("./dockercomposeconfig");
function run(connection) {
    var agentDirectory = tl.getVariable("Agent.HomeDirectory"), imageDigestComposeFile = path.join(agentDirectory, ".docker-compose.images" + Date.now() + ".yml");
    return dockercomposedigests_1.createImageDigestComposeFile(connection, imageDigestComposeFile)
        .then(() => dockercomposeconfig_1.run(connection, imageDigestComposeFile))
        .fin(() => {
        if (tl.exist(imageDigestComposeFile)) {
            del.sync(imageDigestComposeFile, { force: true });
        }
    });
}
exports.run = run;

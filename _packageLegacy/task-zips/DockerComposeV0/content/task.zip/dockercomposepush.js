"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const sourceUtils = require("docker-common/sourceutils");
const imageUtils = require("docker-common/containerimageutils");
function dockerPush(connection, imageName) {
    var command = connection.createCommand();
    command.arg("push");
    command.arg(imageName);
    return connection.execCommand(command);
}
function pushTag(promise, connection, imageName) {
    if (!promise) {
        return dockerPush(connection, imageName);
    }
    else {
        return promise.then(() => dockerPush(connection, imageName));
    }
}
function pushTags(connection, imageName) {
    var baseImageName = imageUtils.imageNameWithoutTag(imageName);
    var builtImageName = imageName + (baseImageName === imageName ? ":latest" : "");
    return dockerPush(connection, builtImageName)
        .then(function pushAdditionalTags() {
        var promise;
        tl.getDelimitedInput("additionalImageTags", "\n").forEach(tag => {
            promise = pushTag(promise, connection, baseImageName + ":" + tag);
        });
        return promise;
    })
        .then(function pushSourceTags() {
        var promise;
        var includeSourceTags = tl.getBoolInput("includeSourceTags");
        if (includeSourceTags) {
            sourceUtils.getSourceTags().forEach(tag => {
                promise = pushTag(promise, connection, baseImageName + ":" + tag);
            });
        }
        return promise;
    })
        .then(function pushLatestTag() {
        var includeLatestTag = tl.getBoolInput("includeLatestTag");
        if (baseImageName !== imageName && includeLatestTag) {
            return dockerPush(connection, baseImageName + ":latest");
        }
    });
}
function run(connection) {
    return connection.getImages(true)
        .then(images => {
        var promise;
        Object.keys(images).forEach(serviceName => {
            (imageName => {
                if (!promise) {
                    promise = pushTags(connection, imageName);
                }
                else {
                    promise = promise.then(() => pushTags(connection, imageName));
                }
            })(images[serviceName]);
        });
        return promise;
    });
}
exports.run = run;

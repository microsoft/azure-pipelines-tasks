"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const tl = require("vsts-task-lib/task");
const yaml = require("js-yaml");
function run(connection, imageDigestComposeFile) {
    return connection.getCombinedConfig(imageDigestComposeFile).then(output => {
        var removeBuildOptions = tl.getBoolInput("removeBuildOptions");
        if (removeBuildOptions) {
            var doc = yaml.safeLoad(output);
            for (var serviceName in doc.services || {}) {
                delete doc.services[serviceName].build;
            }
            output = yaml.safeDump(doc, { lineWidth: -1 });
        }
        var baseResolveDir = tl.getPathInput("baseResolveDirectory");
        if (baseResolveDir) {
            // This just searches the output string and replaces all
            // occurrences of the base resolve directory. This isn't
            // precisely accurate but is a good enough solution.
            var replaced = output;
            do {
                output = replaced;
                replaced = output.replace(baseResolveDir, ".");
            } while (replaced !== output);
        }
        var outputDockerComposeFile = tl.getPathInput("outputDockerComposeFile", true);
        fs.writeFileSync(outputDockerComposeFile, output);
    });
}
exports.run = run;

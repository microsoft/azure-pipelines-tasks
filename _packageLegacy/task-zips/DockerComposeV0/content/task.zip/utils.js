"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
function getFinalComposeFileName() {
    return ".docker-compose." + Date.now() + ".yml";
}
exports.getFinalComposeFileName = getFinalComposeFileName;
function writeFileSync(filename, data, options) {
    fs.writeFileSync(filename, data, options);
}
exports.writeFileSync = writeFileSync;

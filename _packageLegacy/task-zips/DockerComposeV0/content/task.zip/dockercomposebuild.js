"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const sourceUtils = require("docker-common/sourceutils");
const imageUtils = require("docker-common/containerimageutils");
function dockerTag(connection, source, target) {
    var command = connection.createCommand();
    command.arg("tag");
    command.arg(source);
    command.arg(target);
    return connection.execCommand(command);
}
function addTag(promise, connection, source, target) {
    if (!promise) {
        return dockerTag(connection, source, target);
    }
    else {
        return promise.then(() => dockerTag(connection, source, target));
    }
}
function addOtherTags(connection, imageName) {
    var baseImageName = imageUtils.imageNameWithoutTag(imageName);
    function addAdditionalTags() {
        var promise;
        tl.getDelimitedInput("additionalImageTags", "\n").forEach(tag => {
            promise = addTag(promise, connection, imageName, baseImageName + ":" + tag);
        });
        return promise;
    }
    function addSourceTags() {
        var promise;
        var includeSourceTags = tl.getBoolInput("includeSourceTags");
        if (includeSourceTags) {
            sourceUtils.getSourceTags().forEach(tag => {
                promise = addTag(promise, connection, imageName, baseImageName + ":" + tag);
            });
        }
        return promise;
    }
    function addLatestTag() {
        var includeLatestTag = tl.getBoolInput("includeLatestTag");
        if (baseImageName !== imageName && includeLatestTag) {
            return dockerTag(connection, imageName, baseImageName);
        }
    }
    var promise = addAdditionalTags();
    promise = !promise ? addSourceTags() : promise.then(addSourceTags);
    promise = !promise ? addLatestTag() : promise.then(addLatestTag);
    return promise;
}
function run(connection) {
    var command = connection.createComposeCommand();
    command.arg("build");
    return connection.execCommand(command)
        .then(() => connection.getImages(true))
        .then(images => {
        var promise;
        Object.keys(images).map(serviceName => images[serviceName]).forEach(imageName => {
            if (!promise) {
                promise = addOtherTags(connection, imageName);
            }
            else {
                promise = promise.then(() => addOtherTags(connection, imageName));
            }
        });
        return promise;
    });
}
exports.run = run;

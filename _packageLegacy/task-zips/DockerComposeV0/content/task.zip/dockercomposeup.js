"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
function run(connection) {
    var command = connection.createComposeCommand();
    command.arg("up");
    var detached = tl.getBoolInput("detached");
    if (detached) {
        command.arg("-d");
    }
    var buildImages = tl.getBoolInput("buildImages");
    if (buildImages) {
        command.arg("--build");
    }
    var abortOnContainerExit = tl.getBoolInput("abortOnContainerExit");
    if (!detached && abortOnContainerExit) {
        command.arg("--abort-on-container-exit");
    }
    return connection.execCommand(command);
}
exports.run = run;

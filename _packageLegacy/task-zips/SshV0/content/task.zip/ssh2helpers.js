"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const Q = require("q");
var Ssh2Client = require('ssh2').Client;
var Scp2Client = require('scp2');
class RemoteCommandOptions {
}
exports.RemoteCommandOptions = RemoteCommandOptions;
/**
 * Uses scp2 to copy a file to remote machine
 * @param scriptFile
 * @param scpConfig
 * @returns {Promise<string>|Promise<T>}
 */
function copyScriptToRemoteMachine(scriptFile, scpConfig) {
    var defer = Q.defer();
    Scp2Client.scp(scriptFile, scpConfig, (err) => {
        if (err) {
            defer.reject(tl.loc('RemoteCopyFailed', err));
        }
        else {
            tl.debug('Copied script file to remote machine at: ' + scpConfig.path);
            defer.resolve(scpConfig.path);
        }
    });
    return defer.promise;
}
exports.copyScriptToRemoteMachine = copyScriptToRemoteMachine;
/**
 * Sets up an SSH client connection, when promise is fulfilled, returns the connection object
 * @param sshConfig
 * @returns {Promise<any>|Promise<T>}
 */
function setupSshClientConnection(sshConfig) {
    var defer = Q.defer();
    var client = new Ssh2Client();
    client.on('ready', () => {
        defer.resolve(client);
    }).on('error', (err) => {
        defer.reject(err);
    }).connect(sshConfig);
    return defer.promise;
}
exports.setupSshClientConnection = setupSshClientConnection;
/**
 * Runs command on remote machine and returns success or failure
 * @param command
 * @param sshClient
 * @param options
 * @returns {Promise<string>|Promise<T>}
 */
function runCommandOnRemoteMachine(command, sshClient, options) {
    const defer = Q.defer();
    let stdErrWritten = false;
    if (!options) {
        tl.debug('Options not passed to runCommandOnRemoteMachine, setting defaults.');
        options = new RemoteCommandOptions();
        options.failOnStdErr = true;
    }
    tl.debug('command = ' + command);
    sshClient.exec(command, (err, stream) => {
        if (err) {
            defer.reject(tl.loc('RemoteCmdExecutionErr', err));
        }
        stream.on('close', (code, signal) => {
            tl.debug('code = ' + code + ', signal = ' + signal);
            //based on the options decide whether to fail the build or not if data was written to STDERR
            if (stdErrWritten && options.failOnStdErr) {
                defer.reject(tl.loc('RemoteCmdExecutionErr'));
            }
            else if (code && code !== 0) {
                defer.reject(tl.loc('RemoteCmdNonZeroExitCode', command, code));
            }
            else {
                //success case - code is undefined or code is 0
                defer.resolve('0');
            }
        }).on('data', (data) => {
            tl._writeLine(data);
        }).stderr.on('data', (data) => {
            stdErrWritten = true;
            tl.debug('stderr = ' + data);
            if (data && data.toString().trim() !== '') {
                tl.error(data);
            }
        });
    });
    return defer.promise;
}
exports.runCommandOnRemoteMachine = runCommandOnRemoteMachine;

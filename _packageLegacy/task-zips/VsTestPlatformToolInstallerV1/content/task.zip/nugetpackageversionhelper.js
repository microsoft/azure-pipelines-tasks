"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const perf = require("performance-now");
const ci = require("./cieventlogger");
const constants = require("./constants");
let startTime;
class NugetPackageVersionHelper {
    // Lists the latest version of the package available in the feed specified.
    getLatestPackageVersionNumber(packageSource, includePreRelease, nugetConfigFilePath) {
        const nugetTool = tl.tool(path.join(__dirname, 'nuget.exe'));
        ci.addToConsolidatedCi('includePreRelease', `${includePreRelease}`);
        // Only search by package id if the feed is the offial nuget feed, otherwise search by package name as not all feeds
        // support searching by package id
        nugetTool.arg(constants.list)
            .argIf(packageSource === constants.defaultPackageSource, `packageid:${constants.packageId}`)
            .argIf(packageSource !== constants.defaultPackageSource, `${constants.packageId}`)
            .argIf(includePreRelease, constants.preRelease)
            .arg(constants.noninteractive).arg(constants.source).arg(packageSource)
            .argIf(nugetConfigFilePath, constants.configFile)
            .argIf(nugetConfigFilePath, nugetConfigFilePath);
        startTime = perf();
        const result = nugetTool.execSync();
        ci.addToConsolidatedCi('ListLatestPackageTime', perf() - startTime);
        if (result.code !== 0 || !(result.stderr === null || result.stderr === undefined || result.stderr === '')) {
            tl.error(tl.loc('NugetErrorCode', result.code));
            ci.addToConsolidatedCi('listingPackagesFailed', 'true');
            throw new Error(tl.loc('ListPackagesFailed', result.code, result.stderr, result.stdout));
        }
        const listOfPackages = result.stdout.split('\r\n');
        let version;
        // parse the version number from the output string
        listOfPackages.forEach(nugetPackage => {
            if (nugetPackage.split(' ')[0] === constants.packageId) {
                version = nugetPackage.split(' ')[1];
                return;
            }
        });
        return version;
    }
}
exports.NugetPackageVersionHelper = NugetPackageVersionHelper;

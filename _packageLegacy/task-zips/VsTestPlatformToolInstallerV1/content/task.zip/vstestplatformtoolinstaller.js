"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const os = require("os");
const path = require("path");
const perf = require("performance-now");
const ci = require("./cieventlogger");
const constants = require("./constants");
const nugetfeedinstaller_1 = require("./nugetfeedinstaller");
const networkshareinstaller_1 = require("./networkshareinstaller");
let startTime;
// First function to be invoke starting the installation
function startInstaller() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            console.log(tl.loc('StartingInstaller'));
            console.log('==============================================================================');
            const osPlat = os.platform();
            ci.addToConsolidatedCi('operatingSystem', osPlat);
            ci.addToConsolidatedCi('result', constants.installationStatusFailed);
            // Fail the task if os is not windows
            if (osPlat !== 'win32') {
                ci.addToConsolidatedCi('failureReason', constants.unsupportedOS);
                tl.setResult(tl.TaskResult.Failed, tl.loc('OnlyWindowsOsSupported'));
                return;
            }
            // Read task inputs
            const packageFeedSelectorInput = tl.getInput(constants.packageFeedSelector, true);
            const versionSelectorInput = tl.getInput(constants.versionSelector, false);
            const testPlatformVersion = tl.getInput(constants.testPlatformVersion, false);
            const networkSharePath = tl.getInput(constants.netShare, false);
            const username = tl.getInput(constants.username, false);
            const password = tl.getInput(constants.password, false);
            const packageSource = constants.defaultPackageSource;
            ci.addToConsolidatedCi('packageFeedSelectorInput', packageFeedSelectorInput);
            tl.debug(`Selected package feed: ${packageFeedSelectorInput}`);
            switch (packageFeedSelectorInput.toLowerCase()) {
                case 'nugetorg':
                    tl.debug('Going via nuget org download flow.');
                    yield new nugetfeedinstaller_1.NugetFeedInstaller()
                        .installVsTestPlatformToolFromSpecifiedFeed(packageSource, testPlatformVersion, versionSelectorInput, null);
                    break;
                case 'customfeed':
                    tl.debug('Going via custom feed download flow.');
                    yield new nugetfeedinstaller_1.NugetFeedInstaller()
                        .installVsTestPlatformToolFromCustomFeed(packageSource, versionSelectorInput, testPlatformVersion, username, password);
                    break;
                case 'netshare':
                    tl.debug('Going via net share copy flow.');
                    yield new networkshareinstaller_1.NetworkShareInstaller().installVsTestPlatformToolFromNetworkShare(networkSharePath);
                    break;
            }
        }
        catch (error) {
            ci.publishEvent('Completed', { isSetupSuccessful: 'false' });
            tl.setResult(tl.TaskResult.Failed, error);
            return;
        }
        ci.addToConsolidatedCi('result', constants.installationStatusSucceeded);
    });
}
// Execution start
try {
    tl.setResourcePath(path.join(__dirname, 'task.json'));
    startTime = perf();
    startInstaller();
}
finally {
    ci.addToConsolidatedCi('executionTime', perf() - startTime);
    ci.fireConsolidatedCi();
}

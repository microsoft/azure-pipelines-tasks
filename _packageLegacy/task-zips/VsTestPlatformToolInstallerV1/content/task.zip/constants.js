"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// general constants
exports.toolFolderName = 'VsTest';
exports.downloadPath = 'downloadPath';
exports.defaultUsername = 'vstestPlatformToolInstaller';
exports.vsTestToolsInstallerInstalledToolLocation = 'VsTestToolsInstallerInstalledToolLocation';
// agent related constants
exports.agentTempDirectory = 'Agent.TempDirectory';
exports.agentWorkFolder = 'Agent.WorkFolder';
// external constants
exports.packageId = 'Microsoft.TestPlatform';
exports.defaultPackageSource = 'https://api.nuget.org/v3/index.json';
// nuget exe parameters
exports.list = 'list';
exports.install = 'install';
exports.sources = 'sources';
exports.add = 'Add';
exports.noninteractive = '-NonInteractive';
exports.name = '-Name';
exports.source = '-Source';
exports.version = '-Version';
exports.noCache = '-NoCache';
exports.usernameParam = '-Username';
exports.passwordParam = '-Password';
exports.configFile = '-ConfigFile';
exports.preRelease = '-PreRelease';
exports.directDownload = '-DirectDownload';
exports.outputDirectory = '-OutputDirectory';
// input fields
exports.netShare = 'netShare';
exports.username = 'username';
exports.password = 'password';
exports.versionSelector = 'versionSelector';
exports.packageFeedSelector = 'packageFeedSelector';
exports.testPlatformVersion = 'testPlatformVersion';
// input values
exports.nugetOrg = 'nugetOrg';
exports.customFeed = 'customFeed';
exports.latestStable = 'lateststable';
exports.specificVersion = 'specificversion';
exports.latestPrerelease = 'latestprerelease';
// CI related constants
exports.unsupportedOS = 'unsupportedOS';
exports.listingFailed = 'listingFailed';
exports.installationStatusFailed = 'failed';
exports.installationStatusSucceeded = 'succeeded';
exports.downloadFailed = 'downloadFailed';
exports.notExplicitVersion = 'notExplicitVersion';
exports.configFileWriteFailed = 'configFileWriteFailed';
exports.packageFileDoesNotExist = 'packageFileDoesNotExist';
exports.unexpectedPackageFileName = 'unexpectedPackageFileName';
// Regexes
exports.versionExtractionRegex = /microsoft\.testplatform\.(.*)\.nupkg/i;
// Long constants
exports.emptyNugetConfig = `<?xml version="1.0" encoding="utf-8"?>\n` +
    `<configuration>\n` +
    `</configuration>`;

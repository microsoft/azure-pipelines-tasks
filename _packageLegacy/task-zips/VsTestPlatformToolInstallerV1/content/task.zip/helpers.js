"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const fs = require("fs");
const os = require("os");
function setVsTestToolLocation(toolPath) {
    // Set the task variable so that the VsTest task can consume this path
    tl.setVariable('VsTestToolsInstallerInstalledToolLocation', toolPath);
    console.log(tl.loc('InstallationSuccessful', toolPath));
    tl.debug(`Set variable VsTestToolsInstallerInstalledToolLocation value to ${toolPath}.`);
}
exports.setVsTestToolLocation = setVsTestToolLocation;
function cleanUpTempConfigFile(tempConfigFilePath) {
    if (isNullEmptyOrUndefined(tempConfigFilePath)) {
        return;
    }
    try {
        fs.unlinkSync(tempConfigFilePath);
    }
    catch (error) {
        tl.debug(`Failed to delete temp config file ${tempConfigFilePath} with error ${error}.`);
    }
}
exports.cleanUpTempConfigFile = cleanUpTempConfigFile;
function pathExistsAsFile(path) {
    return tl.exist(path) && tl.stats(path).isFile();
}
exports.pathExistsAsFile = pathExistsAsFile;
function pathExistsAsDirectory(path) {
    return tl.exist(path) && tl.stats(path).isDirectory();
}
exports.pathExistsAsDirectory = pathExistsAsDirectory;
function GenerateTempFile(fileName) {
    return path.join(getTempFolder(), fileName);
}
exports.GenerateTempFile = GenerateTempFile;
function isNullEmptyOrUndefined(obj) {
    return obj === null || obj === '' || obj === undefined;
}
exports.isNullEmptyOrUndefined = isNullEmptyOrUndefined;
function isNullOrUndefined(obj) {
    return obj === null || obj === '' || obj === undefined;
}
exports.isNullOrUndefined = isNullOrUndefined;
function isNullOrWhitespace(input) {
    if (typeof input === 'undefined' || input === null) {
        return true;
    }
    return input.replace(/\s/g, '').length < 1;
}
exports.isNullOrWhitespace = isNullOrWhitespace;
function getTempFolder() {
    try {
        tl.assertAgent('2.115.0');
        const tmpDir = tl.getVariable('Agent.TempDirectory');
        return tmpDir;
    }
    catch (err) {
        tl.warning(tl.loc('UpgradeAgentMessage'));
        return os.tmpdir();
    }
}
exports.getTempFolder = getTempFolder;

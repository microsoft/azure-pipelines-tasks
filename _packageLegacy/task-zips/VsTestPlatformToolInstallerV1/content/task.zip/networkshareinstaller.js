"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const toolLib = require("vsts-task-tool-lib/tool");
const perf = require("performance-now");
const ci = require("./cieventlogger");
const constants = require("./constants");
const helpers = require("./helpers");
const nugetdownloadhelper_1 = require("./nugetdownloadhelper");
let startTime;
class NetworkShareInstaller {
    // Installs the test platform from a network share path provided by the user. The path should point to a .nupkg file.
    installVsTestPlatformToolFromNetworkShare(netSharePath) {
        return __awaiter(this, void 0, void 0, function* () {
            let vstestPlatformInstalledLocation;
            let packageSource;
            // Remove all double quotes from the path.
            netSharePath = netSharePath.replace(/["]+/g, '');
            tl.debug(`Attempting to fetch the vstest platform from the specified network share path ${netSharePath}.`);
            if (helpers.pathExistsAsFile(netSharePath)) {
                packageSource = path.dirname(netSharePath);
            }
            else {
                ci.addToConsolidatedCi('failureReason', constants.packageFileDoesNotExist);
                throw new Error(tl.loc('SpecifiedFileDoesNotExist', netSharePath));
            }
            const fileName = path.basename(netSharePath);
            const versionExtractionRegex = constants.versionExtractionRegex;
            const regexMatches = versionExtractionRegex.exec(fileName);
            if (!regexMatches || regexMatches.length !== 2) {
                ci.addToConsolidatedCi('failureReason', constants.unexpectedPackageFileName);
                throw new Error(tl.loc('UnexpectedFileName', fileName));
            }
            const testPlatformVersion = regexMatches[1];
            ci.addToConsolidatedCi('testPlatformVersion', testPlatformVersion);
            // If the version provided is not an explicit version (ie contains containing wildcards) then throw
            if (!toolLib.isExplicitVersion(testPlatformVersion)) {
                ci.publishEvent('InvalidVersionSpecified', { version: testPlatformVersion });
                ci.addToConsolidatedCi('failureReason', constants.notExplicitVersion);
                throw new Error(tl.loc('ProvideExplicitVersion', testPlatformVersion));
            }
            console.log(tl.loc('ParsedVersion', testPlatformVersion));
            tl.debug(`Looking for version ${testPlatformVersion} in the tools cache.`);
            startTime = perf();
            // Check cache for the specified version
            vstestPlatformInstalledLocation = toolLib.findLocalTool(constants.toolFolderName, testPlatformVersion);
            ci.addToConsolidatedCi('cacheLookupTime', perf() - startTime);
            // If found in the cache then set the tool location and return
            if (!helpers.isNullEmptyOrUndefined(vstestPlatformInstalledLocation)) {
                ci.addToConsolidatedCi('firstCacheLookupSucceeded', 'true');
                helpers.setVsTestToolLocation(vstestPlatformInstalledLocation);
                return;
            }
            ci.addToConsolidatedCi('firstCacheLookupSucceeded', 'false');
            vstestPlatformInstalledLocation = yield new nugetdownloadhelper_1.NugetDownloadHelper()
                .attemptPackageDownload(packageSource, testPlatformVersion, null);
            // Set the vstest platform tool location for the vstest task to consume
            helpers.setVsTestToolLocation(vstestPlatformInstalledLocation);
        });
    }
}
exports.NetworkShareInstaller = NetworkShareInstaller;

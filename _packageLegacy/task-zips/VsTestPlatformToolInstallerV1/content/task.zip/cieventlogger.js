"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const area = 'TestExecution';
const feature = 'VsTestToolsInstaller';
const consolidatedCiData = {};
function getDefaultProps() {
    return {
        releaseuri: tl.getVariable('Release.ReleaseUri'),
        releaseid: tl.getVariable('Release.ReleaseId'),
        builduri: tl.getVariable('Build.BuildUri'),
        buildid: tl.getVariable('Build.Buildid')
    };
}
function addToConsolidatedCi(key, value) {
    consolidatedCiData[key] = value;
}
exports.addToConsolidatedCi = addToConsolidatedCi;
function fireConsolidatedCi() {
    publishEvent('vstestToolInstallerConsolidatedCiEvent', consolidatedCiData);
}
exports.fireConsolidatedCi = fireConsolidatedCi;
function publishEvent(subFeature, properties) {
    try {
        tl.assertAgent('2.125.0');
        properties.subFeature = subFeature;
        publishTelemetry(area, feature, Object.assign(getDefaultProps(), properties));
    }
    catch (err) {
        tl.debug(`Unable to publish telemetry due to lower agent version.`);
    }
}
exports.publishEvent = publishEvent;
function publishTelemetry(area, feature, properties) {
    const data = JSON.stringify(properties);
    tl.debug('telemetry area: ' + area + ' feature: ' + feature + ' data: ' + data);
    tl.command('telemetry.publish', { 'area': area, 'feature': feature }, data);
}
exports.publishTelemetry = publishTelemetry;

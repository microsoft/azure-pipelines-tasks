"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
try {
    tl.setResourcePath(path.join(__dirname, "task.json"));
}
catch (error) {
    tl.setResult(tl.TaskResult.Failed, error);
}
class goExe {
    constructor() {
        this.command = "";
        this.argument = "";
        this.workingDir = "";
        this.command = tl.getInput("command", true).trim();
        if (this.command == "custom") {
            this.command = tl.getInput("customCommand", true).trim();
        }
        this.argument = tl.getInput("arguments", false);
        this.workingDir = tl.getInput("workingDirectory", false);
    }
    execute() {
        return __awaiter(this, void 0, void 0, function* () {
            let goPath = tl.which("go", true);
            let go = tl.tool(goPath);
            go.arg(this.command);
            go.line(this.argument);
            return yield go.exec({
                cwd: this.workingDir
            });
        });
    }
}
exports.goExe = goExe;
var exe = new goExe();
exe.execute().catch((reason) => tl.setResult(tl.TaskResult.Failed, tl.loc("TaskFailedWithError", reason)));
//# sourceMappingURL=main.js.map
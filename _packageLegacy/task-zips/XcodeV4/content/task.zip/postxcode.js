"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const sign = require("ios-signing-common/ios-signing-common");
const utils = require("./xcodeutils");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            //--------------------------------------------------------
            // Test publishing - publish even if tests fail
            //--------------------------------------------------------
            let testResultsFiles;
            const publishResults = tl.getBoolInput('publishJUnitResults', false);
            const useXcpretty = tl.getBoolInput('useXcpretty', false);
            const workingDir = tl.getPathInput('cwd');
            if (publishResults) {
                if (!useXcpretty) {
                    tl.warning(tl.loc('UseXcprettyForTestPublishing'));
                }
                else {
                    testResultsFiles = tl.resolve(workingDir, '**/build/reports/junit.xml');
                    if (testResultsFiles && 0 !== testResultsFiles.length) {
                        //check for pattern in testResultsFiles
                        let matchingTestResultsFiles;
                        if (testResultsFiles.indexOf('*') >= 0) {
                            tl.debug('Pattern found in testResultsFiles parameter');
                            matchingTestResultsFiles = tl.findMatch(workingDir, testResultsFiles, { followSymbolicLinks: false, followSpecifiedSymbolicLink: false }, { matchBase: true, nocase: true });
                        }
                        else {
                            tl.debug('No pattern found in testResultsFiles parameter');
                            matchingTestResultsFiles = [testResultsFiles];
                        }
                        if (!matchingTestResultsFiles) {
                            tl.warning(tl.loc('NoTestResultsFound', testResultsFiles));
                        }
                        else {
                            const tp = new tl.TestPublisher("JUnit");
                            tp.publish(matchingTestResultsFiles, false, "", "", "", true);
                        }
                    }
                }
            }
            //clean up the temporary keychain, so it is not used to search for code signing identity in future builds
            var keychainToDelete = utils.getTaskState('XCODE_KEYCHAIN_TO_DELETE');
            if (keychainToDelete) {
                try {
                    yield sign.deleteKeychain(keychainToDelete);
                }
                catch (err) {
                    tl.debug('Failed to delete temporary keychain. Error = ' + err);
                    tl.warning(tl.loc('TempKeychainDeleteFailed', keychainToDelete));
                }
            }
            //delete provisioning profile if specified
            var profileToDelete = utils.getTaskState('XCODE_PROFILE_TO_DELETE');
            if (profileToDelete) {
                try {
                    yield sign.deleteProvisioningProfile(profileToDelete);
                }
                catch (err) {
                    tl.debug('Failed to delete provisioning profile. Error = ' + err);
                    tl.warning(tl.loc('ProvProfileDeleteFailed', profileToDelete));
                }
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
    });
}
run();

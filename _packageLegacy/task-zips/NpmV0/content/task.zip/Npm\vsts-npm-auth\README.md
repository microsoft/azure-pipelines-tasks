# VSTS Auth helper for npm

Integrate npm and Visual Studio Team Services with this authentication bootstrapper.

## Get started

### Install and run the tool
```
npm install -g vsts-npm-auth
vsts-npm-auth -config path-to-your\.npmrc
```

## Integrate into a bootstrapper script

### Configure your .npmrc in your project directory
```
registry=https://my-visualstudio-dot-com-npm-feed-here
always-auth=true
```

### Configure your init bootstrapper
```bash
$ npm install -g vsts-npm-auth --registry https://registry.npmjs.com
$ vsts-npm-auth -config path-to-your\.npmrc
```

## Platform support
The auth helper is currently only functional on a Windows machine. Users on other platforms
will need to get a Personal Access Token from their Visual Studio Team Services account and
manually configure their user .npmrc
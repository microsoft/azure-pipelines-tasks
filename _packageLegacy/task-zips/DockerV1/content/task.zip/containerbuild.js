"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const sourceUtils = require("docker-common/sourceutils");
const imageUtils = require("docker-common/containerimageutils");
const URL = require("url");
const utils = require("./utils");
const util = require("util");
function findDockerFile(dockerfilepath) {
    if (dockerfilepath.indexOf('*') >= 0 || dockerfilepath.indexOf('?') >= 0) {
        tl.debug(tl.loc('ContainerPatternFound'));
        var buildFolder = tl.getVariable('System.DefaultWorkingDirectory');
        var allFiles = tl.find(buildFolder);
        var matchingResultsFiles = tl.match(allFiles, dockerfilepath, buildFolder, { matchBase: true });
        if (!matchingResultsFiles || matchingResultsFiles.length == 0) {
            throw new Error(tl.loc('ContainerDockerFileNotFound', dockerfilepath));
        }
        return matchingResultsFiles[0];
    }
    else {
        tl.debug(tl.loc('ContainerPatternNotFound'));
        return dockerfilepath;
    }
}
function addLabel(command, hostName, labelName, variableName) {
    var labelValue = tl.getVariable(variableName);
    if (labelValue) {
        command.arg(["--label", util.format("%s.image.%s=%s", hostName, labelName, labelValue)]);
    }
}
function addCommonLabels(command, hostName) {
    addLabel(command, hostName, "system.teamfoundationcollectionuri", "SYSTEM_TEAMFOUNDATIONCOLLECTIONURI");
    addLabel(command, hostName, "system.teamproject", "SYSTEM_TEAMPROJECT");
    addLabel(command, hostName, "build.repository.name", "BUILD_REPOSITORY_NAME");
}
function addBuildLabels(command, hostName) {
    addLabel(command, hostName, "build.repository.uri", "BUILD_REPOSITORY_URI");
    addLabel(command, hostName, "build.sourcebranchname", "BUILD_SOURCEBRANCHNAME");
    addLabel(command, hostName, "build.sourceversion", "BUILD_SOURCEVERSION");
    addLabel(command, hostName, "build.definitionname", "BUILD_DEFINITIONNAME");
    addLabel(command, hostName, "build.buildnumber", "BUILD_BUILDNUMBER");
    addLabel(command, hostName, "build.builduri", "BUILD_BUILDURI");
    addLabel(command, hostName, "build.requestedfor", "BUILD_REQUESTEDFOR");
}
function addReleaseLabels(command, hostName) {
    addLabel(command, hostName, "release.definitionname", "RELEASE_DEFINITIONNAME");
    addLabel(command, hostName, "release.releaseid", "RELEASE_RELEASEID");
    addLabel(command, hostName, "release.releaseweburl", "RELEASE_RELEASEWEBURL");
    addLabel(command, hostName, "release.deployment.requestedfor", "RELEASE_DEPLOYMENT_REQUESTEDFOR");
}
function getReverseDNSName() {
    var teamFoundationCollectionURI = tl.getVariable("SYSTEM_TEAMFOUNDATIONCOLLECTIONURI");
    if (teamFoundationCollectionURI) {
        var parsedUrl = URL.parse(teamFoundationCollectionURI);
        if (parsedUrl) {
            var hostName = parsedUrl.hostname.split(".").reverse().join(".");
            tl.debug(`Reverse DNS name ${hostName}`);
            return hostName;
        }
    }
    return null;
}
function run(connection) {
    var command = connection.createCommand();
    command.arg("build");
    var dockerfilepath = tl.getInput("dockerFile", true);
    var dockerFile = findDockerFile(dockerfilepath);
    if (!tl.exist(dockerFile)) {
        throw new Error(tl.loc('ContainerDockerFileNotFound', dockerfilepath));
    }
    command.arg(["-f", dockerFile]);
    var addDefaultLabels = tl.getBoolInput("addDefaultLabels");
    if (addDefaultLabels) {
        var hostName = getReverseDNSName();
        if (hostName) {
            var hostType = tl.getVariable("SYSTEM_HOSTTYPE");
            addCommonLabels(command, hostName);
            if (hostType === "build") {
                addBuildLabels(command, hostName);
            }
            else if (hostType === "release") {
                addReleaseLabels(command, hostName);
            }
        }
    }
    var commandArguments = tl.getInput("arguments", false);
    command.line(commandArguments);
    var imageName = utils.getImageName();
    var qualifyImageName = tl.getBoolInput("qualifyImageName");
    if (qualifyImageName) {
        imageName = connection.qualifyImageName(imageName);
    }
    command.arg(["-t", imageName]);
    var baseImageName = imageUtils.imageNameWithoutTag(imageName);
    var includeSourceTags = tl.getBoolInput("includeSourceTags");
    if (includeSourceTags) {
        sourceUtils.getSourceTags().forEach(tag => {
            command.arg(["-t", baseImageName + ":" + tag]);
        });
    }
    var includeLatestTag = tl.getBoolInput("includeLatestTag");
    if (baseImageName !== imageName && includeLatestTag) {
        command.arg(["-t", baseImageName]);
    }
    var memoryLimit = tl.getInput("memoryLimit");
    if (memoryLimit) {
        command.arg(["-m", memoryLimit]);
    }
    var context;
    var useDefaultContext = tl.getBoolInput("useDefaultContext");
    if (useDefaultContext) {
        context = path.dirname(dockerFile);
    }
    else {
        context = tl.getPathInput("buildContext");
    }
    command.arg(context);
    return connection.execCommand(command);
}
exports.run = run;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
function run(connection) {
    var command = connection.createCommand();
    var dockerCommand = tl.getInput("command", true);
    command.arg(dockerCommand);
    var commandArguments = tl.getInput("arguments", false);
    command.line(commandArguments);
    return connection.execCommand(command);
}
exports.run = run;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const fs = require("fs");
const sourceUtils = require("docker-common/sourceutils");
const imageUtils = require("docker-common/containerimageutils");
function getImageNames() {
    let imageNamesFilePath = tl.getPathInput("imageNamesPath", /* required */ true, /* check exists */ true);
    var enforceDockerNamingConvention = tl.getBoolInput("enforceDockerNamingConvention");
    let imageNames = fs.readFileSync(imageNamesFilePath, "utf-8").trim().replace(/\r\n|\r/gm, "\n").split("\n"); // \r\n windows and \r  mac new line chars
    if (!imageNames.length) {
        throw new Error(tl.loc("NoImagesInImageNamesFile", imageNamesFilePath));
    }
    return imageNames.map(n => (enforceDockerNamingConvention === true) ? imageUtils.generateValidImageName(n) : n);
}
exports.getImageNames = getImageNames;
function getImageName() {
    var enforceDockerNamingConvention = tl.getBoolInput("enforceDockerNamingConvention");
    var imageName = tl.getInput("imageName", true);
    if (enforceDockerNamingConvention === true) {
        return imageUtils.generateValidImageName(imageName);
    }
    return imageName;
}
exports.getImageName = getImageName;
function getImageMappings(connection, imageNames) {
    let qualifyImageName = tl.getBoolInput("qualifyImageName");
    let imageInfos = imageNames.map(imageName => {
        let qualifiedImageName = qualifyImageName ? connection.qualifyImageName(imageName) : imageName;
        return {
            sourceImageName: imageName,
            qualifiedImageName: qualifiedImageName,
            baseImageName: imageUtils.imageNameWithoutTag(qualifiedImageName),
            taggedImages: []
        };
    });
    let includeSourceTags = tl.getBoolInput("includeSourceTags");
    let includeLatestTag = tl.getBoolInput("includeLatestTag");
    let sourceTags = [];
    if (includeSourceTags) {
        sourceTags = sourceUtils.getSourceTags();
    }
    // For each of the image names, generate a mapping from the source image name to the target image.  The same source image name
    // may be listed more than once if there are multiple tags.  The target image names will be tagged based on the task configuration.
    for (let i = 0; i < imageInfos.length; i++) {
        let imageInfo = imageInfos[i];
        let imageSpecificTags = [];
        if (imageInfo.baseImageName === imageInfo.qualifiedImageName) {
            imageSpecificTags.push("latest");
        }
        else {
            imageInfo.taggedImages.push(imageInfo.qualifiedImageName);
            if (includeLatestTag) {
                imageSpecificTags.push("latest");
            }
        }
        sourceTags.concat(imageSpecificTags).forEach(tag => {
            imageInfo.taggedImages.push(imageInfo.baseImageName + ":" + tag);
        });
    }
    // Flatten the image infos into a mapping between the source images and each of their tagged target images
    let sourceToTargetMapping = [];
    imageInfos.forEach(imageInfo => {
        imageInfo.taggedImages.forEach(taggedImage => {
            sourceToTargetMapping.push({
                sourceImageName: imageInfo.sourceImageName,
                targetImageName: taggedImage
            });
        });
    });
    return sourceToTargetMapping;
}
exports.getImageMappings = getImageMappings;

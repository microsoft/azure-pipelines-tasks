"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const definitions = require("./definitions");
const TemplateFileProviderBase_1 = require("./TemplateFileProviderBase");
class CustomTemplateFileProvider extends TemplateFileProviderBase_1.default {
    constructor() {
        super();
    }
    register(packerHost) {
        packerHost.registerTemplateFileProvider(definitions.TemplateFileProviderTypes.Custom, this);
        tl.debug("registered custom template provider");
    }
    getTemplateFileLocation(packerHost) {
        if (!!this._templateFileLocation) {
            return this._templateFileLocation;
        }
        var initialTemplateFileLocation = packerHost.getTaskParameters().customTemplateLocation;
        tl.checkPath(initialTemplateFileLocation, tl.loc("CustomTemplateNotFoundErrorMessagePathName", initialTemplateFileLocation));
        this._templateFileLocation = initialTemplateFileLocation;
        return this._templateFileLocation;
    }
}
exports.default = CustomTemplateFileProvider;

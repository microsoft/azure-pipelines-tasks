"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var https = require('https');
var fs = require('fs');
const os = require("os");
const path = require("path");
const stream = require("stream");
var DecompressZip = require('decompress-zip');
const tl = require("vsts-task-lib/task");
// copy source file to destination folder. destination folder will be created if it does not exists, otherwise its contents will be overwritten.
function copyFile(sourceFile, destinationFolder) {
    tl.checkPath(sourceFile, tl.loc("CopySourceNotExists", sourceFile));
    if (!tl.exist(destinationFolder)) {
        console.log(tl.loc("CreatingDestinationDir", destinationFolder));
        tl.mkdirP(destinationFolder);
        console.log(tl.loc("CreatedDestinationDir", destinationFolder));
    }
    tl.cp(sourceFile, destinationFolder, "-f");
}
exports.copyFile = copyFile;
function download(url, downloadPath) {
    return __awaiter(this, void 0, void 0, function* () {
        var file = fs.createWriteStream(downloadPath);
        yield new Promise((resolve, reject) => {
            var req = https.request(url, res => {
                tl.debug("statusCode: " + res.statusCode);
                res.pipe(file);
                res.on("error", err => reject(err));
                res.on("end", () => {
                    tl.debug("File download completed");
                    resolve();
                });
            });
            req.on("error", err => {
                tl.debug(err);
                reject(err);
            });
            req.end();
        });
        file.end(null, null, file.close);
    });
}
exports.download = download;
function unzip(zipLocation, unzipLocation) {
    return __awaiter(this, void 0, void 0, function* () {
        var finishPromise = new Promise(function (resolve, reject) {
            if (tl.exist(unzipLocation)) {
                tl.rmRF(unzipLocation);
            }
            var unzipper = new DecompressZip(zipLocation);
            tl.debug('extracting ' + zipLocation + ' to ' + unzipLocation);
            unzipper.on('error', err => reject(err));
            unzipper.on('extract', log => {
                tl.debug('extracted ' + zipLocation + ' to ' + unzipLocation + ' Successfully');
                resolve(unzipLocation);
            });
            unzipper.extract({
                path: unzipLocation
            });
        });
        return finishPromise;
    });
}
exports.unzip = unzip;
function readJsonFile(filePath) {
    var content = null;
    if (tl.exist(filePath)) {
        var content = fs.readFileSync(filePath, 'utf8').toString();
        // remove BOM
        if (content.indexOf('\uFEFF') == 0) {
            content = content.slice(1);
        }
    }
    else {
        tl.debug('Json file not found: ' + filePath);
    }
    return content;
}
exports.readJsonFile = readJsonFile;
function generateTemporaryFilePath() {
    let filePath = path.resolve(tl.getVariable('Agent.TempDirectory'), Math.random().toString(36).replace('0.', '') + '.json');
    return filePath;
}
exports.generateTemporaryFilePath = generateTemporaryFilePath;
function getPackerVarFileContent(templateVariables) {
    let res = {};
    templateVariables.forEach((value, key) => {
        res[key] = value;
    });
    let content = JSON.stringify(res);
    return content;
}
exports.getPackerVarFileContent = getPackerVarFileContent;
function writeFile(filePath, content) {
    tl.writeFile(filePath, content);
}
exports.writeFile = writeFile;
function findMatch(root, patterns) {
    return tl.findMatch(root, patterns);
}
exports.findMatch = findMatch;
function getTempDirectory() {
    return os.tmpdir();
}
exports.getTempDirectory = getTempDirectory;
function getCurrentTime() {
    return new Date().getTime();
}
exports.getCurrentTime = getCurrentTime;
function getCurrentDirectory() {
    return __dirname;
}
exports.getCurrentDirectory = getCurrentDirectory;
function isGreaterVersion(firstVersion, secondVersion) {
    if (firstVersion.major > secondVersion.major) {
        return true;
    }
    else if (firstVersion.major === secondVersion.major && firstVersion.minor > secondVersion.minor) {
        return true;
    }
    else if (firstVersion.major === secondVersion.major && firstVersion.minor === secondVersion.minor && firstVersion.patch > secondVersion.patch) {
        return true;
    }
    return false;
}
exports.isGreaterVersion = isGreaterVersion;
function IsNullOrEmpty(str) {
    if (str === null || str === undefined || str === "") {
        return true;
    }
    return false;
}
exports.IsNullOrEmpty = IsNullOrEmpty;
function HasItems(arr) {
    if (arr === null || arr === undefined || arr.length === 0) {
        return false;
    }
    return true;
}
exports.HasItems = HasItems;
function sleep(time) {
    return new Promise((resolve) => setTimeout(resolve, time));
}
exports.sleep = sleep;
function deleteDirectory(dir) {
    if (!dir) {
        return;
    }
    if (tl.exist(dir)) {
        tl.debug("Cleaning-up directory " + dir);
        try {
            tl.rmRF(dir);
        }
        catch (error) { }
    }
}
exports.deleteDirectory = deleteDirectory;
// Extends stream.Writable to support parsing data as they are written
class StringWritable extends stream.Writable {
    constructor(options, parserCallback) {
        super(options);
        this._parserCallback = parserCallback;
    }
    _write(data, encoding, callback) {
        console.log(data.toString());
        if (!!this._parserCallback) {
            this._parserCallback(data.toString());
        }
        if (callback) {
            callback();
        }
    }
}
exports.StringWritable = StringWritable;
;
class PackerVersion {
    static convertFromString(versionString) {
        var parts = versionString.split('.');
        if (parts.length !== 3) {
            throw tl.loc("InvalidPackerVersionString", versionString);
        }
        return {
            major: parseInt(parts[0]),
            minor: parseInt(parts[1]),
            patch: parseInt(parts[2])
        };
    }
}
exports.PackerVersion = PackerVersion;

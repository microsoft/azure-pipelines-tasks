"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const azureGraph = require("azure-arm-rest/azure-graph");
const tl = require("vsts-task-lib/task");
const constants = require("./constants");
const definitions = require("./definitions");
// Provider for all template variables related to azure SPN. Reads service endpoint to get all necessary details.
class AzureSpnTemplateVariablesProvider {
    register(packerHost) {
        packerHost.registerTemplateVariablesProvider(definitions.VariablesProviderTypes.AzureSPN, this);
        tl.debug("registered SPN variables provider");
    }
    getTemplateVariables(packerHost) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!!this._spnVariables) {
                return this._spnVariables;
            }
            var taskParameters = packerHost.getTaskParameters();
            // if custom template is used, SPN variables are not required
            if (taskParameters.templateType === constants.TemplateTypeCustom) {
                this._spnVariables = new Map();
                return this._spnVariables;
            }
            this._spnVariables = new Map();
            var connectedService = taskParameters.serviceEndpoint;
            var subscriptionId = tl.getEndpointDataParameter(connectedService, "SubscriptionId", true);
            this._spnVariables.set(constants.TemplateVariableSubscriptionIdName, subscriptionId);
            this._spnVariables.set(constants.TemplateVariableClientIdName, tl.getEndpointAuthorizationParameter(connectedService, 'serviceprincipalid', false));
            this._spnVariables.set(constants.TemplateVariableClientSecretName, tl.getEndpointAuthorizationParameter(connectedService, 'serviceprincipalkey', false));
            this._spnVariables.set(constants.TemplateVariableTenantIdName, tl.getEndpointAuthorizationParameter(connectedService, 'tenantid', false));
            var spnObjectId = tl.getEndpointDataParameter(connectedService, "spnObjectId", true);
            // if we are creating windows VM and SPN object-id is not available in service endpoint, fetch it from Graph endpoint
            // NOP for nix
            if (!spnObjectId && taskParameters.osType.toLowerCase().match(/^win/)) {
                spnObjectId = yield this.getServicePrincipalObjectId(taskParameters.graphCredentials);
            }
            this._spnVariables.set(constants.TemplateVariableObjectIdName, spnObjectId);
            return this._spnVariables;
        });
    }
    getServicePrincipalObjectId(graphCredentials) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc("FetchingSPNDetailsRemotely", graphCredentials.getClientId()));
            var client = new azureGraph.GraphManagementClient(graphCredentials);
            var servicePrincipal = null;
            try {
                servicePrincipal = yield client.servicePrincipals.GetServicePrincipal(null);
            }
            catch (error) {
                throw tl.loc("FailedToFetchSPNDetailsRemotely", error.message);
            }
            var spnObjectId = "";
            if (!!servicePrincipal && !!servicePrincipal.objectId) {
                spnObjectId = servicePrincipal.objectId;
            }
            console.log(tl.loc("FetchedSPNDetailsRemotely", spnObjectId));
            return spnObjectId;
        });
    }
}
exports.default = AzureSpnTemplateVariablesProvider;

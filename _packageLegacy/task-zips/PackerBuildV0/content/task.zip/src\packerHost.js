"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const util = require("util");
const tl = require("vsts-task-lib/task");
const utils = require("./utilities");
const constants = require("./constants");
const definitions = require("./definitions");
const taskParameters_1 = require("./taskParameters");
class PackerHost {
    constructor() {
        this._templateFileProviders = {};
        this._templateVariablesProviders = {};
        this._taskParameters = new taskParameters_1.default();
    }
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            this._packerPath = yield this._getPackerPath();
            tl.debug("Packer path to be used by task: " + this._packerPath);
        });
    }
    // Will create and return packer toolrunner
    createPackerTool() {
        var command = tl.tool(this._packerPath);
        return command;
    }
    // Creates packer toolrunner with options
    // Also sets up parser which will parse output log on the fly
    execTool(command, outputParser) {
        var outputExtractorFunc = null;
        if (!!outputParser) {
            outputExtractorFunc = (line) => {
                outputParser.parse(line);
            };
        }
        var options = {
            outStream: new utils.StringWritable({ decodeStrings: false }, outputExtractorFunc),
            errStream: new utils.StringWritable({ decodeStrings: false })
        };
        return command.exec(options);
    }
    getTaskParameters() {
        return this._taskParameters;
    }
    getStagingDirectory() {
        if (!!this._stagingDirectory) {
            return this._stagingDirectory;
        }
        this._stagingDirectory = path.join(utils.getTempDirectory(), utils.getCurrentTime().toString());
        if (!tl.exist(this._stagingDirectory)) {
            tl.mkdirP(this._stagingDirectory);
        }
        console.log(tl.loc("CreatedStagingDirectory", this._stagingDirectory));
        return this._stagingDirectory;
    }
    getTemplateFileProvider() {
        if (this._taskParameters.templateType === constants.TemplateTypeCustom) {
            return this._templateFileProviders[definitions.TemplateFileProviderTypes.Custom];
        }
        else {
            return this._templateFileProviders[definitions.TemplateFileProviderTypes.BuiltIn];
        }
    }
    getTemplateVariablesProviders() {
        var taskInputTemplateVariablesProvider = this._templateVariablesProviders[definitions.VariablesProviderTypes.TaskInput];
        var azureSpnTemplateVariablesProvider = this._templateVariablesProviders[definitions.VariablesProviderTypes.AzureSPN];
        return [taskInputTemplateVariablesProvider, azureSpnTemplateVariablesProvider];
    }
    registerTemplateFileProvider(providerType, provider) {
        this._templateFileProviders[providerType] = provider;
    }
    registerTemplateVariablesProvider(providerType, provider) {
        this._templateVariablesProviders[providerType] = provider;
    }
    cleanup() {
        try {
            utils.deleteDirectory(this._stagingDirectory);
        }
        catch (err) {
            tl.warning(tl.loc("CouldNotDeleteStagingDirectory", this._stagingDirectory));
        }
    }
    _getPackerPath() {
        return __awaiter(this, void 0, void 0, function* () {
            var installedPackerPath = tl.which("packer", false);
            var installedPackerVersion = this._getPackerVersion(installedPackerPath);
            console.log(tl.loc("InstalledPackerVersion", installedPackerVersion));
            if (!installedPackerVersion ||
                utils.isGreaterVersion(utils.PackerVersion.convertFromString(constants.CurrentSupportedPackerVersionString), utils.PackerVersion.convertFromString(installedPackerVersion))) {
                console.log(tl.loc("DownloadingPackerRequired", constants.CurrentSupportedPackerVersionString, constants.CurrentSupportedPackerVersionString));
                var downloadPath = path.join(this.getStagingDirectory(), "packer.zip");
                var packerDownloadUrl = util.format(constants.PackerDownloadUrlFormat, constants.CurrentSupportedPackerVersionString, constants.CurrentSupportedPackerVersionString, this._getPackerZipNamePrefix());
                tl.debug("Downloading packer from url: " + packerDownloadUrl);
                yield utils.download(packerDownloadUrl, downloadPath);
                console.log(tl.loc("DownloadingPackerCompleted", downloadPath));
                var extractedPackerLocation = path.join(this.getStagingDirectory(), "packer");
                yield utils.unzip(downloadPath, extractedPackerLocation);
                if (tl.osType().match(/^Win/)) {
                    var packerPath = path.join(extractedPackerLocation, "packer.exe");
                }
                else {
                    var packerPath = path.join(extractedPackerLocation, "packer");
                }
                console.log(tl.loc("ExtractingPackerCompleted", packerPath));
                yield this._waitForPackerExecutable(packerPath);
                return packerPath;
            }
            else {
                return installedPackerPath;
            }
        });
    }
    _getPackerVersion(packerPath) {
        if (!!packerPath && tl.exist(packerPath)) {
            // if failed to get version, do not fail task
            try {
                return tl.tool(packerPath).arg("--version").execSync().stdout.trim();
            }
            catch (err) { }
        }
        return null;
    }
    _waitForPackerExecutable(packerPath) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!!packerPath && tl.exist(packerPath)) {
                var iterationCount = 0;
                do {
                    // query version to check if packer executable is ready
                    var result = tl.tool(packerPath).arg("--version").execSync();
                    if (result.code != 0 && result.error && result.error.message.indexOf("EBUSY") != -1) {
                        iterationCount++;
                        console.log(tl.loc("PackerToolBusy"));
                        yield utils.sleep(1000);
                    }
                    else {
                        break;
                    }
                } while (iterationCount <= 10);
            }
        });
    }
    _getPackerZipNamePrefix() {
        if (tl.osType().match(/^Win/)) {
            return 'windows_amd64';
        }
        else if (tl.osType().match(/^Linux/)) {
            return 'linux_amd64';
        }
        else if (tl.osType().match(/^Darwin/)) {
            return 'darwin_amd64';
        }
        throw tl.loc("OSNotSupportedForRunningPacker");
    }
}
exports.default = PackerHost;

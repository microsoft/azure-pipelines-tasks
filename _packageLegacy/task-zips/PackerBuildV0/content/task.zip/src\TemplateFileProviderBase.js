"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const util = require("util");
const tl = require("vsts-task-lib/task");
const utils = require("./utilities");
class TemplateFileProviderBase {
    moveTemplateFile(initialTemplateFileLocation, dest) {
        console.log(tl.loc("OriginalTemplateLocation", initialTemplateFileLocation));
        console.log(tl.loc("CopyingTemplate", initialTemplateFileLocation, dest));
        utils.copyFile(initialTemplateFileLocation, dest);
        console.log(tl.loc("TempTemplateLocation", dest));
        // construct new full path for template file
        var templateFileName = path.basename(initialTemplateFileLocation);
        var tempFileLocation = path.join(dest, templateFileName);
        this._templateFileLocation = tempFileLocation;
        tl.debug("template location: " + tempFileLocation);
    }
    readTemplateFileJson() {
        var content = utils.readJsonFile(this._templateFileLocation);
        var templateJson = null;
        try {
            templateJson = JSON.parse(content);
        }
        catch (err) {
            throw (tl.loc("ParsingTemplateFileContentFailed", this._templateFileLocation, err));
        }
        return templateJson;
    }
    saveUpdatedTemplateFile(content, newNameSuffix) {
        if (utils.IsNullOrEmpty(content)) {
            return;
        }
        var templateFileName = path.basename(this._templateFileLocation, '.json');
        var templateDir = path.dirname(this._templateFileLocation);
        var updatedTemplateFileName = util.format("%s%s.json", templateFileName, newNameSuffix);
        var tempFileLocation = path.join(templateDir, updatedTemplateFileName);
        utils.writeFile(tempFileLocation, content);
        this._templateFileLocation = tempFileLocation;
        tl.debug("updated template location: " + tempFileLocation);
    }
    updateTemplateBuilderSection(additionalBuilderParameters) {
        if (!(Object.keys(additionalBuilderParameters).length === 0 && additionalBuilderParameters.constructor === Object)) {
            var templateJson = this.readTemplateFileJson();
            for (var key in additionalBuilderParameters) {
                for (var index = 0; index < templateJson["builders"].length; index++) {
                    var builder = templateJson["builders"][index];
                    builder[key] = additionalBuilderParameters[key];
                }
            }
            var newContent = JSON.stringify(templateJson);
            this.saveUpdatedTemplateFile(newContent, "-builderUpdated");
        }
    }
    cleanup() {
        if (!this._templateFileLocation) {
            return;
        }
        var templateFileDirectory = path.dirname(this._templateFileLocation);
        try {
            utils.deleteDirectory(templateFileDirectory);
        }
        catch (err) {
            tl.warning(tl.loc("CouldNotDeleteTemporaryTemplateDirectory", templateFileDirectory));
        }
    }
}
exports.default = TemplateFileProviderBase;

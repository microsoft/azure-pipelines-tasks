"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const util = require("util");
const tl = require("vsts-task-lib/task");
const utils = require("../utilities");
function run(packerHost) {
    return __awaiter(this, void 0, void 0, function* () {
        var command = packerHost.createPackerTool();
        command.arg("validate");
        // add all variables
        var variableProviders = packerHost.getTemplateVariablesProviders();
        for (var provider of variableProviders) {
            var variables = yield provider.getTemplateVariables(packerHost);
            let filePath = utils.generateTemporaryFilePath();
            let content = utils.getPackerVarFileContent(variables);
            utils.writeFile(filePath, content);
            command.arg(util.format("%s=%s", '-var-file', filePath));
        }
        command.arg(packerHost.getTemplateFileProvider().getTemplateFileLocation(packerHost));
        console.log(tl.loc("ExecutingPackerValidate"));
        var result = command.execSync();
        if (result.code != 0) {
            throw tl.loc("PackerValidateFailed");
        }
    });
}
exports.run = run;

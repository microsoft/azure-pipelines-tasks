"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const packerHost_1 = require("./packerHost");
const packerFix = require("./operations/packerFix");
const packerValidate = require("./operations/packerValidate");
const packerBuild = require("./operations/packerBuild");
const builtInTemplateFileProvider_1 = require("./builtInTemplateFileProvider");
const customTemplateFileProvider_1 = require("./customTemplateFileProvider");
const azureSpnTemplateVariablesProvider_1 = require("./azureSpnTemplateVariablesProvider");
const taskInputTemplateVariablesProvider_1 = require("./taskInputTemplateVariablesProvider");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        var host = new packerHost_1.default();
        yield host.initialize();
        // register providers
        registerProviders(host);
        // run packer commands
        try {
            packerFix.run(host);
            yield packerValidate.run(host);
            yield packerBuild.run(host);
            console.log(tl.loc("PackerBuildCompleted"));
        }
        finally {
            cleanup(host);
        }
    });
}
function registerProviders(host) {
    // register built-in templates provider. This provider provides built-in packer templates used by task
    var builtInTemplateFileProvider = new builtInTemplateFileProvider_1.default();
    builtInTemplateFileProvider.register(host);
    // register built-in templates provider. This provider provides built-in packer templates used by task
    var customTemplateFileProvider = new customTemplateFileProvider_1.default();
    customTemplateFileProvider.register(host);
    // register variables provider which will provide task inputs as variables for packer template
    var taskInputTemplateVariablesProvider = new taskInputTemplateVariablesProvider_1.default();
    taskInputTemplateVariablesProvider.register(host);
    //register SPN variables provider which will fetch SPN data as variables for packer template
    var spnVariablesProvider = new azureSpnTemplateVariablesProvider_1.default();
    spnVariablesProvider.register(host);
}
function cleanup(host) {
    var fileProvider = host.getTemplateFileProvider();
    fileProvider.cleanup();
    host.cleanup();
}
var taskManifestPath = path.join(__dirname, "..//task.json");
tl.debug("Setting resource path to " + taskManifestPath);
tl.setResourcePath(taskManifestPath);
run().then((result) => tl.setResult(tl.TaskResult.Succeeded, "")).catch((error) => tl.setResult(tl.TaskResult.Failed, error));

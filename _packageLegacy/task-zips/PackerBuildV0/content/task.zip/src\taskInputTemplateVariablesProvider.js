"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const constants = require("./constants");
const definitions = require("./definitions");
const utils = require("./utilities");
// provider for all template variables which are derived from task input(apart from azure subscription input which is read by AzureSpnVariablesProvider)
class TaskInputTemplateVariablesProvider {
    constructor() {
    }
    register(packerHost) {
        packerHost.registerTemplateVariablesProvider(definitions.VariablesProviderTypes.TaskInput, this);
        tl.debug("registered task input variables provider");
    }
    getTemplateVariables(packerHost) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!!this._templateVariables) {
                return this._templateVariables;
            }
            var taskParameters = packerHost.getTaskParameters();
            // custom template variables
            if (taskParameters.templateType === constants.TemplateTypeCustom) {
                this._templateVariables = new Map();
                var customTemplateParameters = taskParameters.customTemplateParameters;
                for (var key in customTemplateParameters) {
                    this._templateVariables.set(key, customTemplateParameters[key]);
                }
                return this._templateVariables;
            }
            // VM specific variables
            this._templateVariables = new Map();
            this._templateVariables.set(constants.TemplateVariableResourceGroupName, taskParameters.resourceGroup);
            this._templateVariables.set(constants.TemplateVariableStorageAccountName, taskParameters.storageAccount);
            if (taskParameters.baseImageSource === constants.BaseImageSourceCustomVhd) {
                this._templateVariables.set(constants.TemplateVariableImageUrlName, taskParameters.customBaseImageUrl);
            }
            else {
                this._templateVariables.set(constants.TemplateVariableImagePublisherName, taskParameters.imagePublisher);
                this._templateVariables.set(constants.TemplateVariableImageOfferName, taskParameters.imageOffer);
                this._templateVariables.set(constants.TemplateVariableImageSkuName, taskParameters.imageSku);
            }
            this._templateVariables.set(constants.TemplateVariableLocationName, taskParameters.location);
            var capturePrefix = tl.getVariable('release.releaseName') || tl.getVariable('build.buildnumber') || "vstscapture";
            this._templateVariables.set(constants.TemplateVariableCapturePrefixName, capturePrefix);
            this._templateVariables.set(constants.TemplateVariableSkipCleanName, taskParameters.skipTempFileCleanupDuringVMDeprovision.toString());
            // user deployment script specific variables
            var deployScriptPath = taskParameters.deployScriptPath;
            var packagePath = taskParameters.packagePath;
            this._templateVariables.set(constants.TemplateVariableScriptRelativePathName, deployScriptPath);
            this._templateVariables.set(constants.TemplateVariablePackagePathName, packagePath);
            this._templateVariables.set(constants.TemplateVariablePackageName, path.basename(packagePath));
            if (!utils.IsNullOrEmpty(taskParameters.deployScriptArguments)) {
                this._templateVariables.set(constants.TemplateVariableScriptArgumentsName, taskParameters.deployScriptArguments);
            }
            return this._templateVariables;
        });
    }
}
exports.default = TaskInputTemplateVariablesProvider;

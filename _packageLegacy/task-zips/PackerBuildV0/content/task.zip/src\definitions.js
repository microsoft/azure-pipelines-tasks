"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var TemplateFileProviderTypes;
(function (TemplateFileProviderTypes) {
    TemplateFileProviderTypes[TemplateFileProviderTypes["BuiltIn"] = 0] = "BuiltIn";
    TemplateFileProviderTypes[TemplateFileProviderTypes["Custom"] = 1] = "Custom";
})(TemplateFileProviderTypes = exports.TemplateFileProviderTypes || (exports.TemplateFileProviderTypes = {}));
var VariablesProviderTypes;
(function (VariablesProviderTypes) {
    VariablesProviderTypes[VariablesProviderTypes["AzureSPN"] = 0] = "AzureSPN";
    VariablesProviderTypes[VariablesProviderTypes["TaskInput"] = 1] = "TaskInput";
})(VariablesProviderTypes = exports.VariablesProviderTypes || (exports.VariablesProviderTypes = {}));

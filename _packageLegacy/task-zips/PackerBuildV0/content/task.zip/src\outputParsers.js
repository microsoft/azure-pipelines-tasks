"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util = require("util");
const utils = require("./utilities");
const tl = require("vsts-task-lib/task");
class OutputVariablesParser {
    constructor(outputExtractionKeys) {
        this._outputExtractionKeys = outputExtractionKeys;
        this._extractedOutputs = new Map();
    }
    parse(log) {
        if (utils.IsNullOrEmpty(log) || !utils.HasItems(this._outputExtractionKeys)) {
            return;
        }
        tl.debug("Parsing log line to extract output...");
        tl.debug("/*************************************");
        tl.debug(log);
        tl.debug("**************************************/");
        this._outputExtractionKeys.forEach((key) => {
            var keyValue = this._extractOutputValue(log, key);
            if (keyValue !== null) {
                this._extractedOutputs.set(key, keyValue);
            }
        });
    }
    getExtractedOutputs() {
        return this._extractedOutputs;
    }
    _extractOutputValue(log, key) {
        var matchingInfoStartIndex = log.search(util.format("(\\n|\\r|\\u2028|\\u2029|^)%s: .*(\\n|\\r|\\u2028|\\u2029)", key));
        tl.debug("Match start index: " + matchingInfoStartIndex);
        if (matchingInfoStartIndex !== -1) {
            var padding = 1;
            if (log.startsWith(key)) {
                padding = 0;
            }
            var matchingInfo = log.substring(matchingInfoStartIndex + key.length + padding + 1).trim(); // one extra character is for ':' preceding the key
            var matchingInfoEndIndex = matchingInfo.search("(\\n|\\r|\\u2028|\\u2029)");
            tl.debug("Match end index: " + matchingInfoEndIndex);
            if (matchingInfoEndIndex !== -1) {
                matchingInfo = matchingInfo.substring(0, matchingInfoEndIndex).trim();
            }
            var matchingValue = matchingInfo;
            tl.debug("...found match for key " + key + " value: " + matchingValue);
            return matchingValue;
        }
        return null;
    }
}
exports.default = OutputVariablesParser;

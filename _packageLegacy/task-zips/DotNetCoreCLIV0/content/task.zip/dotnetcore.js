"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const tl = require("vsts-task-lib/task");
const path = require("path");
const fs = require("fs");
const nutil = require("nuget-task-common/Utility");
var archiver = require('archiver');
class dotNetExe {
    constructor() {
        this.outputArgument = "";
        this.remainingArguments = [];
        this.command = tl.getInput("command");
        this.projects = tl.getInput("projects", false);
        this.arguments = tl.getInput("arguments", false);
        this.publishWebProjects = tl.getBoolInput("publishWebProjects", false);
        this.zipAfterPublish = tl.getBoolInput("zipAfterPublish", false);
    }
    execute() {
        return __awaiter(this, void 0, void 0, function* () {
            tl.setResourcePath(path.join(__dirname, "task.json"));
            var dotnetPath = tl.which("dotnet", true);
            this.extractOutputArgument();
            // Use empty string when no project file is specified to operate on the current directory
            var projectFiles = [""];
            if (this.projects || (this.isPublishCommand() && this.publishWebProjects)) {
                projectFiles = this.getProjectFiles();
            }
            for (var fileIndex in projectFiles) {
                var projectFile = projectFiles[fileIndex];
                try {
                    var dotnet = tl.tool(dotnetPath);
                    dotnet.arg(this.command);
                    dotnet.arg(projectFile);
                    if (this.remainingArguments.length > 0) {
                        dotnet.arg(this.remainingArguments);
                    }
                    if (this.isPublishCommand() && this.outputArgument) {
                        var output = dotNetExe.getModifiedOutputForProjectFile(this.outputArgument, projectFile);
                        dotnet.arg("--output");
                        dotnet.arg(output);
                    }
                    var result = dotnet.execSync();
                    if (result.code != 0) {
                        var error = result.stderr.replace("\r", "%0D");
                        tl.error(error.replace("\n", "%0A"));
                        tl.setResult(result.code, tl.loc("dotnetCommandFailed", result.code));
                    }
                    yield this.zipAfterPublishIfRequired(projectFile);
                }
                catch (err) {
                    tl.setResult(1, err.message);
                }
            }
        });
    }
    zipAfterPublishIfRequired(projectFile) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.isPublishCommand() && this.zipAfterPublish) {
                var outputSource = "";
                if (this.outputArgument) {
                    outputSource = dotNetExe.getModifiedOutputForProjectFile(this.outputArgument, projectFile);
                }
                else {
                    var pattern = path.dirname(projectFile) + "/**/publish";
                    var files = nutil.resolveFilterSpec(pattern, "", true, true);
                    for (var fileIndex in files) {
                        var file = files[fileIndex];
                        if (fs.lstatSync(file).isDirectory) {
                            outputSource = file;
                            break;
                        }
                    }
                }
                tl.debug("Zip Source: " + outputSource);
                if (outputSource) {
                    var outputTarget = outputSource + ".zip";
                    yield this.zip(outputSource, outputTarget);
                    tl.rmRF(outputSource, true);
                }
                else {
                    tl.warning(tl.loc("noPublishFolderFoundToZip", projectFile));
                }
            }
        });
    }
    zip(source, target) {
        tl.debug("Zip arguments: Source: " + source + " , target: " + target);
        return new Promise((resolve, reject) => {
            var output = fs.createWriteStream(target);
            output.on('close', function () {
                tl.debug('Successfully created archive ' + target);
                resolve(target);
            });
            output.on('error', function (error) {
                reject(error);
            });
            var archive = archiver('zip');
            archive.pipe(output);
            archive.directory(source, '/');
            archive.finalize();
        });
    }
    extractOutputArgument() {
        if (!this.arguments || !this.arguments.trim()) {
            return;
        }
        var argString = this.arguments.trim();
        var isOutputOption = false;
        var inQuotes = false;
        var escaped = false;
        var arg = '';
        var i = 0;
        var append = function (c) {
            // we only escape double quotes.
            if (escaped && c !== '"') {
                arg += '\\';
            }
            arg += c;
            escaped = false;
        };
        var nextArg = function () {
            arg = '';
            for (; i < argString.length; i++) {
                var c = argString.charAt(i);
                if (c === '"') {
                    if (!escaped) {
                        inQuotes = !inQuotes;
                    }
                    else {
                        append(c);
                    }
                    continue;
                }
                if (c === "\\" && inQuotes && !escaped) {
                    escaped = true;
                    continue;
                }
                if (c === ' ' && !inQuotes) {
                    if (arg.length > 0) {
                        return arg.trim();
                    }
                    continue;
                }
                append(c);
            }
            if (arg.length > 0) {
                return arg.trim();
            }
            return null;
        };
        var token = nextArg();
        while (token) {
            var tokenUpper = token.toUpperCase();
            if (this.isPublishCommand() && (tokenUpper === "--OUTPUT" || tokenUpper === "-O")) {
                isOutputOption = true;
            }
            else if (isOutputOption) {
                this.outputArgument = token;
                isOutputOption = false;
            }
            else {
                this.remainingArguments.push(token);
            }
            token = nextArg();
        }
    }
    getProjectFiles() {
        var projectPattern = this.projects;
        var searchWebProjects = this.isPublishCommand() && this.publishWebProjects;
        if (searchWebProjects) {
            projectPattern = "**/project.json;**/*.csproj;**/*.vbproj";
        }
        var projectFiles = nutil.resolveFilterSpec(projectPattern, tl.getVariable("System.DefaultWorkingDirectory") || process.cwd(), true);
        if (!projectFiles || !projectFiles.length) {
            tl.warning(tl.loc("noProjectFilesFound"));
            return [];
        }
        if (searchWebProjects) {
            projectFiles = projectFiles.filter(function (file, index, files) {
                var directory = path.dirname(file);
                return tl.exist(path.join(directory, "web.config"))
                    || tl.exist(path.join(directory, "wwwroot"));
            });
            if (!projectFiles.length) {
                tl.warning(tl.loc("noWebProjctFound"));
            }
        }
        return projectFiles;
    }
    isPublishCommand() {
        return this.command === "publish";
    }
    static getModifiedOutputForProjectFile(outputBase, projectFile) {
        return path.join(outputBase, path.basename(path.dirname(projectFile)));
    }
}
exports.dotNetExe = dotNetExe;
var exe = new dotNetExe();
exe.execute().catch((reason) => tl.setResult(1, reason));

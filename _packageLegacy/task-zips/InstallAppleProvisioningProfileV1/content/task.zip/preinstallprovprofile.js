"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const sign = require("ios-signing-common/ios-signing-common");
const secureFilesCommon = require("securefiles-common/securefiles-common");
const tl = require("vsts-task-lib/task");
const os = require("os");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        let secureFileId;
        let secureFileHelpers;
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // Check platform is macOS since demands are not evaluated on Hosted pools
            if (os.platform() !== 'darwin') {
                throw new Error(tl.loc('InstallRequiresMac'));
            }
            if (tl.getInput('provisioningProfileLocation') === 'secureFiles') {
                // download decrypted contents
                secureFileId = tl.getInput('provProfileSecureFile', true);
                secureFileHelpers = new secureFilesCommon.SecureFileHelpers();
                let provProfilePath = yield secureFileHelpers.downloadSecureFile(secureFileId);
                if (tl.exist(provProfilePath)) {
                    const info = yield sign.installProvisioningProfile(provProfilePath);
                    tl.setTaskVariable('APPLE_PROV_PROFILE_UUID', info.provProfileUUID);
                    // set the provisioning profile output variable.
                    tl.setVariable('provisioningProfileUuid', info.provProfileUUID);
                    tl.setVariable('provisioningProfileName', info.provProfileName);
                    // Set the legacy variable that doesn't use the task's refName, unlike our output variables.
                    // If there are multiple InstallAppleCertificate tasks, the last one wins.
                    tl.setVariable('APPLE_PROV_PROFILE_UUID', info.provProfileUUID);
                }
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
        finally {
            // delete provisioning profile from temp location after installing
            if (secureFileId && secureFileHelpers) {
                secureFileHelpers.deleteSecureFile(secureFileId);
            }
        }
    });
}
run();

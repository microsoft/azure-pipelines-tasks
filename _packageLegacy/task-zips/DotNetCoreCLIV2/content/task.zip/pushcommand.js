"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const auth = require("nuget-task-common/Authentication");
const commandHelper = require("nuget-task-common/CommandHelper");
const locationHelpers = require("nuget-task-common/LocationHelpers");
const nutil = require("nuget-task-common/Utility");
const path = require("path");
const tl = require("vsts-task-lib/task");
const NuGetConfigHelper2_1 = require("nuget-task-common/NuGetConfigHelper2");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        let buildIdentityDisplayName = null;
        let buildIdentityAccount = null;
        try {
            // Get list of files to publish
            const searchPatternInput = tl.getPathInput("searchPatternPush", true, false);
            let findOptions = {};
            let matchOptions = {};
            let searchPatterns = nutil.getPatternsArrayFromInput(searchPatternInput);
            const filesList = tl.findMatch(undefined, searchPatterns, findOptions, matchOptions);
            filesList.forEach(packageFile => {
                if (!tl.stats(packageFile).isFile()) {
                    throw new Error(tl.loc("Error_PushNotARegularFile", packageFile));
                }
            });
            if (filesList.length < 1) {
                tl.setResult(tl.TaskResult.Failed, tl.loc("Info_NoPackagesMatchedTheSearchPattern"));
                return;
            }
            // Get the info the type of feed
            let nugetFeedType = tl.getInput("nuGetFeedType") || "internal";
            // Make sure the feed type is an expected one
            let normalizedNuGetFeedType = ["internal", "external"].find(x => nugetFeedType.toUpperCase() === x.toUpperCase());
            if (!normalizedNuGetFeedType) {
                throw new Error(tl.loc("UnknownFeedType", nugetFeedType));
            }
            nugetFeedType = normalizedNuGetFeedType;
            let serviceUri = tl.getEndpointUrl("SYSTEMVSSCONNECTION", false);
            let urlPrefixes = yield locationHelpers.assumeNuGetUriPrefixes(serviceUri);
            tl.debug(`discovered URL prefixes: ${urlPrefixes}`);
            // Note to readers: This variable will be going away once we have a fix for the location service for
            // customers behind proxies
            let testPrefixes = tl.getVariable("DotNetCoreCLITask.ExtraUrlPrefixesForTesting");
            if (testPrefixes) {
                urlPrefixes = urlPrefixes.concat(testPrefixes.split(";"));
                tl.debug(`all URL prefixes: ${urlPrefixes}`);
            }
            // Setting up auth info
            let accessToken = auth.getSystemAccessToken();
            const isInternalFeed = nugetFeedType === "internal";
            let useCredConfig = useCredentialConfiguration(isInternalFeed);
            let internalAuthInfo = new auth.InternalAuthInfo(urlPrefixes, accessToken, /*useCredProvider*/ null, useCredConfig);
            let configFile = null;
            let apiKey;
            let credCleanup = () => { return; };
            // dotnet nuget push does not currently accept a --config-file parameter
            // so we are going to work around this by creating a temporary working directory for dotnet with
            // a nuget config file it will load by default.
            const tempNuGetConfigDirectory = path.join(NuGetConfigHelper2_1.NuGetConfigHelper2.getTempNuGetConfigBasePath(), "NuGet_" + tl.getVariable("build.buildId"));
            const tempNuGetPath = path.join(tempNuGetConfigDirectory, "nuget.config");
            tl.mkdirP(tempNuGetConfigDirectory);
            let feedUri = undefined;
            let authInfo;
            let nuGetConfigHelper;
            if (isInternalFeed) {
                authInfo = new auth.NuGetExtendedAuthInfo(internalAuthInfo);
                nuGetConfigHelper = new NuGetConfigHelper2_1.NuGetConfigHelper2(null, null, /* nugetConfigPath */ authInfo, { credProviderFolder: null, extensionsDisabled: true }, tempNuGetPath, false /* useNugetToModifyConfigFile */);
                const internalFeedId = tl.getInput("feedPublish");
                feedUri = yield nutil.getNuGetFeedRegistryUrl(accessToken, internalFeedId, null);
                nuGetConfigHelper.addSourcesToTempNuGetConfig([{ feedName: internalFeedId, feedUri: feedUri, isInternal: true }]);
                configFile = nuGetConfigHelper.tempNugetConfigPath;
                credCleanup = () => { tl.rmRF(tempNuGetConfigDirectory); };
                apiKey = "VSTS";
            }
            else {
                const externalAuthArr = commandHelper.GetExternalAuthInfoArray("externalEndpoint");
                authInfo = new auth.NuGetExtendedAuthInfo(internalAuthInfo, externalAuthArr);
                nuGetConfigHelper = new NuGetConfigHelper2_1.NuGetConfigHelper2(null, null, /* nugetConfigPath */ authInfo, { credProviderFolder: null, extensionsDisabled: true }, tempNuGetPath, false /* useNugetToModifyConfigFile */);
                const externalAuth = externalAuthArr[0];
                if (!externalAuth) {
                    tl.setResult(tl.TaskResult.Failed, tl.loc("Error_NoSourceSpecifiedForPush"));
                    return;
                }
                nuGetConfigHelper.addSourcesToTempNuGetConfig([externalAuth.packageSource]);
                feedUri = externalAuth.packageSource.feedUri;
                configFile = nuGetConfigHelper.tempNugetConfigPath;
                credCleanup = () => { tl.rmRF(tempNuGetConfigDirectory); };
                let authType = externalAuth.authType;
                switch (authType) {
                    case (auth.ExternalAuthType.UsernamePassword):
                    case (auth.ExternalAuthType.Token):
                        apiKey = "RequiredApiKey";
                        break;
                    case (auth.ExternalAuthType.ApiKey):
                        let apiKeyAuthInfo = externalAuth;
                        apiKey = apiKeyAuthInfo.apiKey;
                        break;
                    default:
                        break;
                }
            }
            yield nuGetConfigHelper.setAuthForSourcesInTempNuGetConfigAsync();
            const dotnetPath = tl.which("dotnet", true);
            try {
                for (const packageFile of filesList) {
                    yield dotNetNuGetPushAsync(dotnetPath, packageFile, feedUri, apiKey, configFile, tempNuGetConfigDirectory);
                }
            }
            finally {
                credCleanup();
            }
            tl.setResult(tl.TaskResult.Succeeded, tl.loc("PackagesPublishedSuccessfully"));
        }
        catch (err) {
            tl.error(err);
            if (buildIdentityDisplayName || buildIdentityAccount) {
                tl.warning(tl.loc("BuildIdentityPermissionsHint", buildIdentityDisplayName, buildIdentityAccount));
            }
            tl.setResult(tl.TaskResult.Failed, tl.loc("PackagesFailedToPublish"));
        }
    });
}
exports.run = run;
function dotNetNuGetPushAsync(dotnetPath, packageFile, feedUri, apiKey, configFile, workingDirectory) {
    let dotnet = tl.tool(dotnetPath);
    dotnet.arg("nuget");
    dotnet.arg("push");
    dotnet.arg(packageFile);
    dotnet.arg("--source");
    dotnet.arg(feedUri);
    dotnet.arg("--api-key");
    dotnet.arg(apiKey);
    // dotnet.exe v1 and v2 do not accept the --verbosity parameter for the "nuget push"" command, although it does for other commands
    return dotnet.exec({ cwd: workingDirectory });
}
function useCredentialConfiguration(isInternalFeed) {
    // if we are pushing to an internal on-premises server, then credential configuration is not possible
    // and integrated authentication must be used
    let useCredConfig = !(isInternalFeed && commandHelper.isOnPremisesTfs());
    if (!useCredConfig) {
        tl.debug("Push to internal OnPrem server detected. Credential configuration will be skipped.");
    }
    return useCredConfig;
}

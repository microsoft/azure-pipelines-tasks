"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const utility = require("./Common/utility");
const locationHelpers = require("nuget-task-common/LocationHelpers");
const auth = require("nuget-task-common/Authentication");
const NuGetConfigHelper2_1 = require("nuget-task-common/NuGetConfigHelper2");
const path = require("path");
const nutil = require("nuget-task-common/Utility");
const commandHelper = require("nuget-task-common/CommandHelper");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        let buildIdentityDisplayName = null;
        let buildIdentityAccount = null;
        try {
            const projectSearch = tl.getDelimitedInput("projects", "\n", false);
            // if no projectSearch strings are given, use "" to operate on the current directory
            const projectFiles = utility.getProjectFiles(projectSearch);
            if (projectFiles.length == 0) {
                tl.setResult(tl.TaskResult.Failed, tl.loc("Info_NoFilesMatchedTheSearchPattern"));
                return;
            }
            const noCache = tl.getBoolInput("noCache");
            const verbosity = tl.getInput("verbosityRestore");
            let packagesDirectory = tl.getPathInput("packagesDirectory");
            if (!tl.filePathSupplied("packagesDirectory")) {
                packagesDirectory = null;
            }
            // Setting up auth-related variables
            tl.debug('Setting up auth');
            const serviceUri = tl.getEndpointUrl("SYSTEMVSSCONNECTION", false);
            let urlPrefixes = yield locationHelpers.assumeNuGetUriPrefixes(serviceUri);
            tl.debug(`Discovered URL prefixes: ${urlPrefixes}`);
            // Note to readers: This variable will be going away once we have a fix for the location service for
            // customers behind proxies
            let testPrefixes = tl.getVariable("DotNetCoreCLITask.ExtraUrlPrefixesForTesting");
            if (testPrefixes) {
                urlPrefixes = urlPrefixes.concat(testPrefixes.split(";"));
                tl.debug(`All URL prefixes: ${urlPrefixes}`);
            }
            let accessToken = auth.getSystemAccessToken();
            let externalAuthArr = commandHelper.GetExternalAuthInfoArray("externalEndpoints");
            const authInfo = new auth.NuGetExtendedAuthInfo(new auth.InternalAuthInfo(urlPrefixes, accessToken, /*useCredProvider*/ null, /*useCredConfig*/ true), externalAuthArr);
            // Setting up sources, either from provided config file or from feed selection
            tl.debug('Setting up sources');
            let nuGetConfigPath = undefined;
            let selectOrConfig = tl.getInput("selectOrConfig");
            // This IF is here in order to provide a value to nuGetConfigPath (if option selected, if user provided it)
            // and then pass it into the config helper
            if (selectOrConfig === "config") {
                nuGetConfigPath = tl.getPathInput("nugetConfigPath", false, true);
                if (!tl.filePathSupplied("nugetConfigPath")) {
                    nuGetConfigPath = undefined;
                }
            }
            // If there was no nuGetConfigPath, NuGetConfigHelper will create one
            let nuGetConfigHelper = new NuGetConfigHelper2_1.NuGetConfigHelper2(null, nuGetConfigPath, authInfo, { credProviderFolder: null, extensionsDisabled: true }, null /* tempConfigPath */, false /* useNugetToModifyConfigFile */);
            let credCleanup = () => { return; };
            // Now that the NuGetConfigHelper was initialized with all the known information we can proceed
            // and check if the user picked the 'select' option to fill out the config file if needed
            if (selectOrConfig === "select") {
                let sources = new Array();
                let feed = tl.getInput("feedRestore");
                if (feed) {
                    let feedUrl = yield nutil.getNuGetFeedRegistryUrl(accessToken, feed, null);
                    sources.push({
                        feedName: feed,
                        feedUri: feedUrl,
                        isInternal: true
                    });
                }
                let includeNuGetOrg = tl.getBoolInput("includeNuGetOrg", false);
                if (includeNuGetOrg) {
                    sources.push({
                        feedName: "NuGetOrg",
                        feedUri: locationHelpers.NUGET_ORG_V3_URL,
                        isInternal: false
                    });
                }
                // Creating NuGet.config for the user
                if (sources.length > 0) {
                    tl.debug(`Adding the following sources to the config file: ${sources.map(x => x.feedName).join(';')}`);
                    nuGetConfigHelper.addSourcesToTempNuGetConfig(sources);
                    credCleanup = () => { tl.rmRF(nuGetConfigHelper.tempNugetConfigPath); };
                    nuGetConfigPath = nuGetConfigHelper.tempNugetConfigPath;
                }
                else {
                    tl.debug('No sources were added to the temp NuGet.config file');
                }
            }
            // Setting creds in the temp NuGet.config if needed
            yield nuGetConfigHelper.setAuthForSourcesInTempNuGetConfigAsync();
            const configFile = nuGetConfigHelper.tempNugetConfigPath;
            const dotnetPath = tl.which("dotnet", true);
            try {
                for (const projectFile of projectFiles) {
                    yield dotNetRestoreAsync(dotnetPath, projectFile, packagesDirectory, configFile, noCache, verbosity);
                }
            }
            finally {
                credCleanup();
            }
            tl.setResult(tl.TaskResult.Succeeded, tl.loc("PackagesInstalledSuccessfully"));
        }
        catch (err) {
            tl.error(err);
            if (buildIdentityDisplayName || buildIdentityAccount) {
                tl.warning(tl.loc("BuildIdentityPermissionsHint", buildIdentityDisplayName, buildIdentityAccount));
            }
            tl.setResult(tl.TaskResult.Failed, tl.loc("PackagesFailedToInstall"));
        }
    });
}
exports.run = run;
function dotNetRestoreAsync(dotnetPath, projectFile, packagesDirectory, configFile, noCache, verbosity) {
    let dotnet = tl.tool(dotnetPath);
    dotnet.arg("restore");
    if (projectFile) {
        dotnet.arg(projectFile);
    }
    if (packagesDirectory) {
        dotnet.arg("--packages");
        dotnet.arg(packagesDirectory);
    }
    dotnet.arg("--configfile");
    dotnet.arg(configFile);
    if (noCache) {
        dotnet.arg("--no-cache");
    }
    if (verbosity && verbosity !== "-") {
        dotnet.arg("--verbosity");
        dotnet.arg(verbosity);
    }
    return dotnet.exec({ cwd: path.dirname(projectFile) });
}

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
var http = require('http');
var DecompressZip = require('decompress-zip');
var path = require('path');
const tl = require("vsts-task-lib/task");
const vsts = require("vso-node-api/WebApi");
const ApiVersion = "3.0-preview.1";
tl.setResourcePath(path.join(__dirname, 'task.json'));
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        let feedId = tl.getInput("feed");
        let regexGuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
        let packageId = tl.getInput("definition");
        if (!regexGuid.test(packageId)) {
            packageId = "Nuget_" + tl.getInput("definition");
        }
        let version = tl.getInput("version");
        let downloadPath = tl.getInput("downloadPath");
        let collectionUrl = tl.getVariable("System.TeamFoundationCollectionUri");
        var accessToken = getAuthToken();
        var credentialHandler = vsts.getBearerHandler(accessToken);
        var vssConnection = new vsts.WebApi(collectionUrl, credentialHandler);
        var coreApi = vssConnection.getCoreApi();
        yield downloadPackage(collectionUrl, credentialHandler, feedId, packageId, version, downloadPath);
    });
}
function getAuthToken() {
    var auth = tl.getEndpointAuthorization('SYSTEMVSSCONNECTION', false);
    if (auth.scheme.toLowerCase() === 'oauth') {
        return auth.parameters['AccessToken'];
    }
    else {
        throw new Error(tl.loc("CredentialsNotFound"));
    }
}
function downloadPackage(collectionUrl, credentialHandler, feedId, packageId, version, downloadPath) {
    return __awaiter(this, void 0, void 0, function* () {
        var feedsUrl = collectionUrl.replace(".visualstudio.com", ".feeds.visualstudio.com");
        var feedConnection = new vsts.WebApi(feedsUrl, credentialHandler);
        var packagesUrl = collectionUrl.replace(".visualstudio.com", ".pkgs.visualstudio.com");
        var packageConnection = new vsts.WebApi(packagesUrl, credentialHandler);
        var packageUrl = yield getNuGetPackageUrl(feedConnection.getCoreApi().vsoClient, feedId, packageId);
        yield new Promise((resolve, reject) => {
            feedConnection.getCoreApi().restClient.get(packageUrl, ApiVersion, null, { responseIsCollection: false }, function (error, status, result) {
                return __awaiter(this, void 0, void 0, function* () {
                    if (!!error || status != 200) {
                        return reject(tl.loc("FailedToGetPackageMetadata", error));
                    }
                    var packageType = result.protocolType.toLowerCase();
                    var packageName = result.name;
                    if (packageType == "nuget") {
                        var getDownloadUrlPromise = getDownloadUrl(packageConnection.getCoreApi().vsoClient, feedId, packageName, version);
                        getDownloadUrlPromise.catch((error) => {
                            return reject(error);
                        });
                        var downloadUrl = yield getDownloadUrlPromise;
                        if (!tl.exist(downloadPath)) {
                            tl.mkdirP(downloadPath);
                        }
                        var zipLocation = path.resolve(downloadPath, "../", packageName) + ".zip";
                        var unzipLocation = path.join(downloadPath, "");
                        console.log(tl.loc("StartingDownloadOfPackage", packageName, zipLocation));
                        var downloadNugetPackagePromise = downloadNugetPackage(packageConnection.getCoreApi(), downloadUrl, zipLocation);
                        downloadNugetPackagePromise.catch((error) => {
                            return reject(error);
                        });
                        yield downloadNugetPackagePromise;
                        console.log(tl.loc("ExtractingNugetPackage", packageName, unzipLocation));
                        var unzipPromise = unzip(zipLocation, unzipLocation);
                        unzipPromise.catch((error) => {
                            return reject(error);
                        });
                        yield unzipPromise;
                        if (tl.exist(zipLocation)) {
                            tl.rmRF(zipLocation, false);
                        }
                        return resolve();
                    }
                    else {
                        return reject(tl.loc("PackageTypeNotSupported"));
                    }
                });
            });
        });
    });
}
exports.downloadPackage = downloadPackage;
function getNuGetPackageUrl(vsoClient, feedId, packageId) {
    return __awaiter(this, void 0, void 0, function* () {
        var PackagingAreaName = "Packaging";
        var PackageAreaId = "7A20D846-C929-4ACC-9EA2-0D5A7DF1B197";
        return new Promise((resolve, reject) => {
            var getVersioningDataPromise = vsoClient.getVersioningData(ApiVersion, PackagingAreaName, PackageAreaId, { feedId: feedId, packageId: packageId });
            getVersioningDataPromise.then((result) => {
                return resolve(result.requestUrl);
            });
            getVersioningDataPromise.catch((error) => {
                return reject(error);
            });
        });
    });
}
exports.getNuGetPackageUrl = getNuGetPackageUrl;
function getDownloadUrl(vsoClient, feedId, packageName, version) {
    return __awaiter(this, void 0, void 0, function* () {
        var NugetArea = "NuGet";
        var PackageVersionContentResourceId = "6EA81B8C-7386-490B-A71F-6CF23C80B388";
        return new Promise((resolve, reject) => {
            var getVersioningDataPromise = vsoClient.getVersioningData(ApiVersion, NugetArea, PackageVersionContentResourceId, { feedId: feedId, packageName: packageName, packageVersion: version });
            getVersioningDataPromise.then((result) => {
                return resolve(result.requestUrl);
            });
            getVersioningDataPromise.catch((error) => {
                return reject(error);
            });
        });
    });
}
exports.getDownloadUrl = getDownloadUrl;
function downloadNugetPackage(coreApi, downloadUrl, downloadPath) {
    return __awaiter(this, void 0, void 0, function* () {
        var file = fs.createWriteStream(downloadPath);
        yield new Promise((resolve, reject) => {
            var accept = coreApi.restClient.createAcceptHeader("application/zip", ApiVersion);
            coreApi.restClient.httpClient.getStream(downloadUrl, accept, function (error, status, result) {
                tl.debug("Downloading package from url: " + downloadUrl);
                tl.debug("Download status: " + status);
                if (!!error || status != 200) {
                    return reject(tl.loc("FailedToDownloadNugetPackage", downloadUrl, error));
                }
                result.pipe(file);
                result.on("end", () => {
                    console.log(tl.loc("PackageDownloadSuccessful"));
                    return resolve();
                });
                result.on("error", err => {
                    return reject(tl.loc("FailedToDownloadNugetPackage", downloadUrl, err));
                });
            });
        });
        file.end(null, null, file.close);
    });
}
exports.downloadNugetPackage = downloadNugetPackage;
function unzip(zipLocation, unzipLocation) {
    return __awaiter(this, void 0, void 0, function* () {
        yield new Promise(function (resolve, reject) {
            if (tl.exist(unzipLocation)) {
                tl.rmRF(unzipLocation, false);
            }
            tl.debug('Extracting ' + zipLocation + ' to ' + unzipLocation);
            var unzipper = new DecompressZip(zipLocation);
            unzipper.on('error', err => {
                return reject(tl.loc("ExtractionFailed", err));
            });
            unzipper.on('extract', log => {
                tl.debug('Extracted ' + zipLocation + ' to ' + unzipLocation + ' successfully');
                return resolve();
            });
            unzipper.extract({
                path: unzipLocation
            });
        });
    });
}
exports.unzip = unzip;
main()
    .then((result) => tl.setResult(tl.TaskResult.Succeeded, ""))
    .catch((error) => tl.setResult(tl.TaskResult.Failed, error));

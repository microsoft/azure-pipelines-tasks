"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            var cmake = tl.tool(tl.which('cmake', true));
            var cwd = tl.getPathInput('cwd', true, false);
            tl.mkdirP(cwd);
            tl.cd(cwd);
            cmake.line(tl.getInput('cmakeArgs', false));
            var code = yield cmake.exec();
            tl.setResult(tl.TaskResult.Succeeded, tl.loc('CMakeReturnCode', code));
        }
        catch (err) {
            tl.error(err.message);
            tl.setResult(tl.TaskResult.Failed, tl.loc('CMakeFailed', err.message));
        }
    });
}
run();

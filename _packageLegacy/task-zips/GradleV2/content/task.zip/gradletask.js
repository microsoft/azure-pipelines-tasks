"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const fs = require("fs");
const path = require("path");
const os = require("os");
const sqGradle = require("codeanalysis-common/gradlesonar");
const CodeAnalysisOrchestrator_1 = require("codeanalysis-common/Common/CodeAnalysisOrchestrator");
const BuildOutput_1 = require("codeanalysis-common/Common/BuildOutput");
const PmdTool_1 = require("codeanalysis-common/Common/PmdTool");
const CheckstyleTool_1 = require("codeanalysis-common/Common/CheckstyleTool");
const FindbugsTool_1 = require("codeanalysis-common/Common/FindbugsTool");
const codecoveragefactory_1 = require("codecoverage-tools/codecoveragefactory");
const ccUtil = require("codecoverage-tools/codecoverageutilities");
const javacommons = require("java-common/java-common");
const systemToken = require("utility-common/accesstoken");
const accessTokenEnvSetting = 'VSTS_ENV_ACCESS_TOKEN';
// Configure the JVM associated with this run.
function setGradleOpts(gradleOptions) {
    if (gradleOptions) {
        process.env['GRADLE_OPTS'] = gradleOptions;
        tl.debug(`GRADLE_OPTS is now set to ${gradleOptions}`);
    }
}
function publishTestResults(publishJUnitResults, testResultsFiles) {
    if (publishJUnitResults) {
        let matchingTestResultsFiles = [];
        // check for pattern in testResultsFiles
        if (testResultsFiles.indexOf('*') >= 0 || testResultsFiles.indexOf('?') >= 0) {
            tl.debug('Pattern found in testResultsFiles parameter');
            let buildFolder = tl.getVariable('System.DefaultWorkingDirectory');
            let allFiles = tl.find(buildFolder);
            matchingTestResultsFiles = tl.match(allFiles, testResultsFiles, { matchBase: true });
        }
        else {
            tl.debug('No pattern found in testResultsFiles parameter');
            matchingTestResultsFiles = [testResultsFiles];
        }
        if (!matchingTestResultsFiles || matchingTestResultsFiles.length === 0) {
            tl.warning('No test result files matching ' + testResultsFiles + ' were found, so publishing JUnit test results is being skipped.');
            return 0;
        }
        let tp = new tl.TestPublisher('JUnit');
        tp.publish(matchingTestResultsFiles, true, '', '', '', true);
    }
}
function enableCodeCoverage(wrapperScript, isCodeCoverageOpted, classFilter, classFilesDirectories, codeCoverageTool, workingDirectory, reportDirectoryName, summaryFileName, isMultiModule) {
    let buildProps = {};
    buildProps['buildfile'] = path.join(workingDirectory, 'build.gradle');
    buildProps['classfilter'] = classFilter;
    buildProps['classfilesdirectories'] = classFilesDirectories;
    buildProps['summaryfile'] = summaryFileName;
    buildProps['reportdirectory'] = reportDirectoryName;
    buildProps['ismultimodule'] = String(isMultiModule);
    let ccEnabler = new codecoveragefactory_1.CodeCoverageEnablerFactory().getTool('gradle', codeCoverageTool.toLowerCase());
    return ccEnabler.enableCodeCoverage(buildProps);
}
function isMultiModuleProject(wrapperScript) {
    let gradleBuild = tl.tool(wrapperScript);
    gradleBuild.arg('properties');
    gradleBuild.line(tl.getInput('options', false));
    let data = gradleBuild.execSync().stdout;
    if (typeof data !== 'undefined' && data) {
        let regex = new RegExp('subprojects: .*');
        let subProjects = regex.exec(data);
        tl.debug('Data: ' + subProjects);
        if (typeof subProjects !== 'undefined' && subProjects && subProjects.length > 0) {
            tl.debug('Sub Projects info: ' + subProjects.toString());
            return (subProjects.join(',').toLowerCase() !== 'subprojects: []');
        }
    }
    return false;
}
function publishCodeCoverage(isCodeCoverageOpted, failIfCoverageEmpty, codeCoverageTool, summaryFile, reportDirectory) {
    return __awaiter(this, void 0, void 0, function* () {
        if (isCodeCoverageOpted) {
            tl.debug('publishCodeCoverage');
            if (failIfCoverageEmpty && (yield ccUtil.isCodeCoverageFileEmpty(summaryFile, codeCoverageTool))) {
                throw tl.loc('NoCodeCoverage');
            }
            if (tl.exist(summaryFile)) {
                tl.debug('Summary file = ' + summaryFile);
                tl.debug('Report directory = ' + reportDirectory);
                tl.debug('Publishing code coverage results to TFS');
                let ccPublisher = new tl.CodeCoveragePublisher();
                ccPublisher.publish(codeCoverageTool, summaryFile, reportDirectory, '');
            }
            else {
                tl.warning('No code coverage results found to be published. This could occur if there were no tests executed or there was a build failure. Check the gradle output for details.');
            }
        }
    });
}
function configureWrapperScript(wrapperScript) {
    let script = wrapperScript;
    let isWindows = os.type().match(/^Win/);
    if (isWindows) {
        // append .bat extension name on Windows platform
        if (!script.endsWith('bat')) {
            tl.debug('Append .bat extension name to gradlew script.');
            script += '.bat';
        }
    }
    if (fs.existsSync(script)) {
        // (The exists check above is not necessary, but we need to avoid this call when we are running L0 tests.)
        // Make sure the wrapper script is executable
        fs.chmodSync(script, '755');
    }
    return script;
}
// update JAVA_HOME if user selected specific JDK version or set path manually
function setJavaHome(javaHomeSelection) {
    let specifiedJavaHome;
    let javaTelemetryData;
    if (javaHomeSelection === 'JDKVersion') {
        tl.debug('Using JDK version to find and set JAVA_HOME');
        let jdkVersion = tl.getInput('jdkVersion');
        let jdkArchitecture = tl.getInput('jdkArchitecture');
        javaTelemetryData = { "jdkVersion": jdkVersion };
        if (jdkVersion !== 'default') {
            specifiedJavaHome = javacommons.findJavaHome(jdkVersion, jdkArchitecture);
        }
    }
    else {
        tl.debug('Using path from user input to set JAVA_HOME');
        let jdkUserInputPath = tl.getPathInput('jdkUserInputPath', true, true);
        specifiedJavaHome = jdkUserInputPath;
        javaTelemetryData = { "jdkVersion": "custom" };
    }
    javacommons.publishJavaTelemetry('Gradle', javaTelemetryData);
    if (specifiedJavaHome) {
        tl.debug('Set JAVA_HOME to ' + specifiedJavaHome);
        process.env['JAVA_HOME'] = specifiedJavaHome;
    }
}
function getExecOptions() {
    var env = process.env;
    env[accessTokenEnvSetting] = systemToken.getSystemAccessToken();
    return {
        env: env,
    };
}
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // Configure wrapperScript
            let wrapperScript = tl.getPathInput('wrapperScript', true, true);
            wrapperScript = configureWrapperScript(wrapperScript);
            // Set working directory
            let workingDirectory = tl.getPathInput('cwd', false, true);
            tl.cd(workingDirectory);
            let javaHomeSelection = tl.getInput('javaHomeSelection', true);
            let codeCoverageTool = tl.getInput('codeCoverageTool');
            let isCodeCoverageOpted = (typeof codeCoverageTool !== 'undefined' && codeCoverageTool && codeCoverageTool.toLowerCase() !== 'none');
            let failIfCodeCoverageEmpty = tl.getBoolInput('failIfCoverageEmpty');
            let publishJUnitResults = tl.getBoolInput('publishJUnitResults');
            let testResultsFiles = tl.getInput('testResultsFiles', true);
            let inputTasks = tl.getDelimitedInput('tasks', ' ', true);
            let buildOutput = new BuildOutput_1.BuildOutput(tl.getVariable('System.DefaultWorkingDirectory'), BuildOutput_1.BuildEngine.Gradle);
            //START: Get gradleRunner ready to run
            let gradleRunner = tl.tool(wrapperScript);
            if (isCodeCoverageOpted && inputTasks.indexOf('clean') === -1) {
                gradleRunner.arg('clean'); //if user opts for code coverage, we append clean functionality to make sure any uninstrumented class files are removed
            }
            gradleRunner.line(tl.getInput('options', false));
            gradleRunner.arg(inputTasks);
            //END: Get gb ready to run
            // Set JAVA_HOME based on any user input
            setJavaHome(javaHomeSelection);
            // Set any provided gradle options
            let gradleOptions = tl.getInput('gradleOpts');
            setGradleOpts(gradleOptions);
            // START: Enable code coverage (if desired)
            let reportDirectoryName = 'CCReport43F6D5EF';
            let reportDirectory = path.join(workingDirectory, reportDirectoryName);
            let summaryFile = null;
            let reportingTaskName = '';
            try {
                if (isCodeCoverageOpted) {
                    tl.debug('Option to enable code coverage was selected and is being applied.');
                    let classFilter = tl.getInput('classFilter');
                    let classFilesDirectories = tl.getInput('classFilesDirectories');
                    // START: determine isMultiModule
                    let isMultiModule = isMultiModuleProject(wrapperScript);
                    let summaryFileName;
                    if (codeCoverageTool.toLowerCase() === 'jacoco') {
                        summaryFileName = 'summary.xml';
                        if (isMultiModule) {
                            reportingTaskName = 'jacocoRootReport';
                        }
                        else {
                            reportingTaskName = 'jacocoTestReport';
                        }
                    }
                    else if (codeCoverageTool.toLowerCase() === 'cobertura') {
                        summaryFileName = 'coverage.xml';
                        reportingTaskName = 'cobertura';
                    }
                    summaryFile = path.join(reportDirectory, summaryFileName);
                    // END: determine isMultiModule
                    // Clean the report directory before enabling code coverage
                    tl.rmRF(reportDirectory, true);
                    yield enableCodeCoverage(wrapperScript, isCodeCoverageOpted, classFilter, classFilesDirectories, codeCoverageTool, workingDirectory, reportDirectoryName, summaryFileName, isMultiModule);
                }
                tl.debug('Enabled code coverage successfully');
            }
            catch (err) {
                tl.warning('Failed to enable code coverage: ' + err);
            }
            if (reportingTaskName && reportingTaskName !== '') {
                gradleRunner.arg(reportingTaskName);
            }
            // END: Enable code coverage (if desired)
            let codeAnalysisOrchestrator = new CodeAnalysisOrchestrator_1.CodeAnalysisOrchestrator([new CheckstyleTool_1.CheckstyleTool(buildOutput, 'checkstyleAnalysisEnabled'),
                new FindbugsTool_1.FindbugsTool(buildOutput, 'findbugsAnalysisEnabled'),
                new PmdTool_1.PmdTool(buildOutput, 'pmdAnalysisEnabled')]);
            // Enable SonarQube Analysis (if desired)
            let isSonarQubeEnabled = tl.getBoolInput('sqAnalysisEnabled', false);
            if (isSonarQubeEnabled) {
                // Looks like: 'SonarQube analysis is enabled.'
                console.log(tl.loc('codeAnalysis_ToolIsEnabled'), 'SonarQube');
                gradleRunner = sqGradle.applyEnabledSonarQubeArguments(gradleRunner);
            }
            gradleRunner = codeAnalysisOrchestrator.configureBuild(gradleRunner);
            // START: Run code analysis
            let gradleResult;
            let statusFailed = false;
            let analysisError;
            try {
                gradleResult = yield gradleRunner.exec(getExecOptions());
                tl.debug(`Gradle result: ${gradleResult}`);
            }
            catch (err) {
                console.error(err);
                tl.debug('taskRunner fail');
                gradleResult = -1;
                statusFailed = true;
                analysisError = err;
            }
            tl.debug('Processing code analysis results');
            codeAnalysisOrchestrator.publishCodeAnalysisResults();
            // We should always publish test results and code coverage
            publishTestResults(publishJUnitResults, testResultsFiles);
            yield publishCodeCoverage(isCodeCoverageOpted, failIfCodeCoverageEmpty, codeCoverageTool, summaryFile, reportDirectory);
            if (gradleResult === 0) {
                tl.setResult(tl.TaskResult.Succeeded, 'Build succeeded.');
            }
            else if (gradleResult === -1 && statusFailed === true) {
                tl.setResult(tl.TaskResult.Failed, analysisError);
            }
            else {
                tl.setResult(tl.TaskResult.Failed, 'Build failed.');
            }
            // END: Run code analysis
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
    });
}
run();

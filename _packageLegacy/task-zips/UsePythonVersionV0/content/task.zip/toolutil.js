"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const task = require("vsts-task-lib/task");
/**
 * Like `prependPath` from vsts-task-tool-lib, but does not check whether the directory exists.
 * TODO move this to vsts-task-tool-lib
 */
function prependPathSafe(toolPath) {
    task.assertAgent('2.115.0');
    console.log(task.loc('PrependPath', toolPath));
    const newPath = toolPath + path.delimiter + process.env['PATH'];
    task.debug('new Path: ' + newPath);
    process.env['PATH'] = newPath;
    // instruct the agent to set this path on future tasks
    console.log('##vso[task.prependpath]' + toolPath);
}
exports.prependPathSafe = prependPathSafe;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const task = require("vsts-task-lib/task");
// TODO move this to vsts-task-lib 
var Platform;
(function (Platform) {
    Platform[Platform["Windows"] = 0] = "Windows";
    Platform[Platform["MacOS"] = 1] = "MacOS";
    Platform[Platform["Linux"] = 2] = "Linux";
})(Platform = exports.Platform || (exports.Platform = {}));
/**
 * Determine the operating system the build agent is running on.
 * TODO move this to vsts-task-lib
 */
function getPlatform() {
    switch (process.platform) {
        case 'win32': return Platform.Windows;
        case 'darwin': return Platform.MacOS;
        case 'linux': return Platform.Linux;
        default: throw Error(task.loc('PlatformNotRecognized'));
    }
}
exports.getPlatform = getPlatform;

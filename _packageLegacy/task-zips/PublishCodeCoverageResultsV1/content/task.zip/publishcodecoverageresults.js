"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const ccUtil = require("codecoverage-tools/codecoverageutilities");
// Main entry point of this task.
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Initialize localization
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // Get input values
            var codeCoverageTool = tl.getInput('codeCoverageTool', true);
            var summaryFileLocation = tl.getInput('summaryFileLocation', true);
            var reportDirectory = tl.getInput('reportDirectory');
            var additionalFiles = tl.getInput('additionalCodeCoverageFiles');
            var failIfCoverageIsEmpty = tl.getBoolInput('failIfCoverageEmpty');
            var workingDirectory = tl.getVariable('System.DefaultWorkingDirectory');
            // Resolve the summary file path.
            // It may contain wildcards allowing the path to change between builds, such as for:
            // $(System.DefaultWorkingDirectory)\artifacts***$(Configuration)\testresults\coverage\cobertura.xml
            var resolvedSummaryFile = resolvePathToSingleItem(workingDirectory, summaryFileLocation);
            if (failIfCoverageIsEmpty && (yield ccUtil.isCodeCoverageFileEmpty(resolvedSummaryFile, codeCoverageTool))) {
                throw tl.loc('NoCodeCoverage');
            }
            else if (!tl.exist(resolvedSummaryFile)) {
                tl.warning(tl.loc('NoCodeCoverage'));
            }
            else {
                // Resolve the report directory.
                // It may contain wildcards allowing the path to change between builds, such as for:
                // $(System.DefaultWorkingDirectory)\artifacts***$(Configuration)\testresults\coverage
                var resolvedReportDirectory = resolvePathToSingleItem(workingDirectory, reportDirectory);
                // Get any 'Additional Files' to publish as build artifacts
                if (additionalFiles) {
                    // Does the 'Additional Files' value contain wildcards?
                    if (containsWildcard(additionalFiles)) {
                        // Resolve matches of the 'Additional Files' pattern
                        var additionalFileMatches = tl.findMatch(workingDirectory, additionalFiles, { followSymbolicLinks: false, followSpecifiedSymbolicLink: false }, { matchBase: true });
                    }
                    else {
                        // Use the specific additional file (no wildcards)
                        var additionalFileMatches = [additionalFiles];
                    }
                    additionalFileMatches = additionalFileMatches.filter(file => pathExistsAsFile(file));
                    tl.debug(tl.loc('FoundNMatchesForPattern', additionalFileMatches.length, additionalFiles));
                }
                // Publish code coverage data
                var ccPublisher = new tl.CodeCoveragePublisher();
                ccPublisher.publish(codeCoverageTool, resolvedSummaryFile, resolvedReportDirectory, additionalFileMatches);
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
    });
}
// Resolves the specified path to a single item based on whether it contains wildcards
function resolvePathToSingleItem(workingDirectory, pathInput) {
    // Default to using the specific pathInput value
    var resolvedPath = pathInput;
    // Does the pathInput value contain wildcards?
    if (pathInput && containsWildcard(pathInput)) {
        // Resolve matches of the pathInput pattern
        var pathMatches = tl.findMatch(workingDirectory, pathInput, { followSymbolicLinks: false, followSpecifiedSymbolicLink: false });
        tl.debug(tl.loc('FoundNMatchesForPattern', pathMatches.length, pathInput));
        // Were any matches found?
        if (pathMatches.length == 0) {
            resolvedPath = undefined;
        }
        else {
            // Select the path to be used from the matches
            resolvedPath = pathMatches[0];
            // If more than one path matches, use the first and issue a warning
            if (pathMatches.length > 1) {
                tl.warning(tl.loc('MultipleSummaryFilesFound', resolvedPath));
            }
        }
    }
    // Return resolved path
    return resolvedPath;
}
// Gets whether the specified input value contains a wildcard character.
function containsWildcard(inputValue) {
    return inputValue.indexOf('*') >= 0 ||
        inputValue.indexOf('?') >= 0;
}
// Gets whether the specified path exists as file.
function pathExistsAsFile(path) {
    try {
        return tl.stats(path).isFile();
    }
    catch (error) {
        tl.debug(error);
        return false;
    }
}
run();

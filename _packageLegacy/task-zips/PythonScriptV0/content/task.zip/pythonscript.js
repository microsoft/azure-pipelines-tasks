"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const task = require("vsts-task-lib/task");
const uuidV4 = require("uuid/v4");
/**
 * Check for a parameter at runtime.
 * Useful for conditionally-visible, required parameters.
 */
function assertParameter(value, propertyName) {
    if (!value) {
        throw new Error(task.loc('ParameterRequired', propertyName));
    }
    return value;
}
// TODO Enable with TypeScript 2.8 (ensures correct property name in the error message)
// function assertParameter<T extends keyof TaskParameters>(parameters: TaskParameters, propertyName: T): NonNullable<TaskParameters[T]> {
//     const param = parameters[propertyName];
//     if (!param) {
//         throw new Error(task.loc('ParameterRequired', propertyName));
//     }
//     return param!;
// }
function pythonScript(parameters) {
    return __awaiter(this, void 0, void 0, function* () {
        // Get the script to run
        const scriptPath = yield (() => __awaiter(this, void 0, void 0, function* () {
            if (parameters.scriptSource.toLowerCase() === 'filepath') {
                const scriptPath = assertParameter(parameters.scriptPath, 'scriptPath');
                if (!fs.statSync(scriptPath).isFile()) {
                    throw new Error(task.loc('NotAFile', scriptPath));
                }
                return scriptPath;
            }
            else {
                const script = assertParameter(parameters.script, 'script');
                // Write the script to disk
                task.assertAgent('2.115.0');
                const tempDirectory = task.getVariable('agent.tempDirectory');
                task.checkPath(tempDirectory, `${tempDirectory} (agent.tempDirectory)`);
                const scriptPath = path.join(tempDirectory, `${uuidV4()}.py`);
                yield fs.writeFileSync(scriptPath, script, { encoding: 'utf8' });
                return scriptPath;
            }
        }))();
        // Create the tool runner
        const pythonPath = parameters.pythonInterpreter || task.which('python');
        const python = task.tool(pythonPath).arg(scriptPath);
        // Calling `line` with a falsy argument returns `undefined`, so can't chain this call
        if (parameters.arguments) {
            python.line(parameters.arguments);
        }
        // Run the script
        // Use `any` to work around what I suspect are bugs with `IExecOptions`'s type annotations:
        // - optional fields need to be typed as optional
        // - `errStream` and `outStream` should be `NodeJs.WritableStream`, not `NodeJS.Writable`
        yield python.exec({
            cwd: parameters.workingDirectory,
            failOnStdErr: parameters.failOnStderr,
            // Direct all output to stdout, otherwise the output may appear out-of-order since Node buffers its own stdout but not stderr
            errStream: process.stdout,
            outStream: process.stdout,
            ignoreReturnCode: false
        });
    });
}
exports.pythonScript = pythonScript;

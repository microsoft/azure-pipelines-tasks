"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const task = require("vsts-task-lib/task");
const pythonscript_1 = require("./pythonscript");
(() => __awaiter(this, void 0, void 0, function* () {
    try {
        task.setResourcePath(path.join(__dirname, 'task.json'));
        yield pythonscript_1.pythonScript({
            scriptSource: task.getInput('scriptSource'),
            scriptPath: task.getPathInput('scriptPath'),
            script: task.getInput('script'),
            arguments: task.getInput('arguments'),
            pythonInterpreter: task.getInput('pythonInterpreter'),
            workingDirectory: task.getPathInput('workingDirectory'),
            failOnStderr: task.getBoolInput('failOnStderr')
        });
        task.setResult(task.TaskResult.Succeeded, "");
    }
    catch (error) {
        task.setResult(task.TaskResult.Failed, error.message);
    }
}))();

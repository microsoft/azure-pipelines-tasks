"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const clusterconnection_1 = require("./clusterconnection");
const kubectl = require("./kubernetescommand");
const kubectlConfigMap = require("./kubernetesconfigmap");
const kubectlSecret = require("./kubernetessecret");
const acrauthenticationtokenprovider_1 = require("docker-common/registryauthenticationprovider/acrauthenticationtokenprovider");
const genericauthenticationtokenprovider_1 = require("docker-common/registryauthenticationprovider/genericauthenticationtokenprovider");
tl.setResourcePath(path.join(__dirname, '..', 'task.json'));
// Change to any specified working directory
tl.cd(tl.getInput("cwd"));
// get the registry server authentication provider 
var registryType = tl.getInput("containerRegistryType", true);
var authenticationProvider;
if (registryType == "Azure Container Registry") {
    authenticationProvider = new acrauthenticationtokenprovider_1.default(tl.getInput("azureSubscriptionEndpoint"), tl.getInput("azureContainerRegistry"));
}
else {
    authenticationProvider = new genericauthenticationtokenprovider_1.default(tl.getInput("dockerRegistryEndpoint"));
}
var registryAuthenticationToken = authenticationProvider.getAuthenticationToken();
// open kubectl connection and run the command
var connection = new clusterconnection_1.default();
try {
    connection.open(tl.getInput("kubernetesServiceEndpoint")).then(() => { return run(connection, registryAuthenticationToken); }).then(() => {
        tl.setResult(tl.TaskResult.Succeeded, "");
        connection.close();
    }).catch((error) => {
        tl.setResult(tl.TaskResult.Failed, error.message);
        connection.close();
    });
}
catch (error) {
    tl.setResult(tl.TaskResult.Failed, error.message);
}
function run(clusterConnection, registryAuthenticationToken) {
    return __awaiter(this, void 0, void 0, function* () {
        var secretName = tl.getInput("secretName", false);
        var configMapName = tl.getInput("configMapName", false);
        if (secretName) {
            yield kubectlSecret.run(clusterConnection, registryAuthenticationToken, secretName);
        }
        if (configMapName) {
            yield kubectlConfigMap.run(clusterConnection, configMapName);
        }
        yield executeKubectlCommand(clusterConnection);
    });
}
// execute kubectl command
function executeKubectlCommand(clusterConnection) {
    var command = tl.getInput("command", true);
    var result = "";
    var ouputVariableName = tl.getInput("kubectlOutput", false);
    return kubectl.run(clusterConnection, command, (data) => result += data)
        .fin(function cleanup() {
        if (ouputVariableName) {
            tl.setVariable(ouputVariableName, result);
        }
    });
}

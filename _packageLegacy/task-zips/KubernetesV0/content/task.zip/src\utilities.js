"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var https = require('https');
var fs = require('fs');
const path = require("path");
const tl = require("vsts-task-lib/task");
const os = require("os");
const util = require("util");
const downloadutility = require("utility-common/downloadutility");
function getTempDirectory() {
    return tl.getVariable('agent.tempDirectory') || os.tmpdir();
}
exports.getTempDirectory = getTempDirectory;
function getCurrentTime() {
    return new Date().getTime();
}
exports.getCurrentTime = getCurrentTime;
function getNewUserDirPath() {
    var userDir = path.join(getTempDirectory(), "kubectlTask");
    ensureDirExists(userDir);
    userDir = path.join(userDir, getCurrentTime().toString());
    ensureDirExists(userDir);
    return userDir;
}
exports.getNewUserDirPath = getNewUserDirPath;
function ensureDirExists(dirPath) {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath);
    }
}
function getKubectlVersion(versionSpec, checkLatest) {
    return __awaiter(this, void 0, void 0, function* () {
        let version = "v1.6.6";
        if (checkLatest) {
            return getStableKubectlVersion();
        }
        else if (versionSpec) {
            if (versionSpec === "1.7") {
                // Backward compat handle
                tl.warning(tl.loc("UsingLatestStableVersion"));
                return getStableKubectlVersion();
            }
            else if (!versionSpec.startsWith("v")) {
                version = "v".concat(versionSpec);
            }
            else {
                version = versionSpec;
            }
        }
        return version;
    });
}
exports.getKubectlVersion = getKubectlVersion;
function getStableKubectlVersion() {
    return __awaiter(this, void 0, void 0, function* () {
        var stableVersion = "v1.6.6";
        var version;
        var stableVersionUrl = "https://storage.googleapis.com/kubernetes-release/release/stable.txt";
        var downloadPath = path.join(getTempDirectory(), getCurrentTime().toString() + ".txt");
        return downloadutility.download(stableVersionUrl, downloadPath, false, true).then((resolve) => {
            version = fs.readFileSync(downloadPath, "utf8").toString().trim();
            if (!version) {
                version = stableVersion;
            }
            return version;
        }, (reject) => {
            tl.debug(reject);
            tl.warning(tl.loc('DownloadStableVersionFailed', stableVersionUrl, stableVersion));
            return stableVersion;
        });
    });
}
exports.getStableKubectlVersion = getStableKubectlVersion;
function downloadKubectl(version, kubectlPath) {
    return __awaiter(this, void 0, void 0, function* () {
        var kubectlURL = getkubectlDownloadURL(version);
        tl.debug(tl.loc('DownloadingKubeCtlFromUrl', kubectlURL));
        var kubectlPathTmp = kubectlPath + ".tmp";
        return downloadutility.download(kubectlURL, kubectlPathTmp, false, true).then((res) => {
            tl.cp(kubectlPathTmp, kubectlPath, "-f");
            fs.chmod(kubectlPath, "777");
            assertFileExists(kubectlPath);
            return kubectlPath;
        }, (reason) => {
            //Download kubectl client failed.
            throw new Error(tl.loc('DownloadKubeCtlFailed', version));
        });
    });
}
exports.downloadKubectl = downloadKubectl;
function getkubectlDownloadURL(version) {
    switch (os.type()) {
        case 'Linux':
            return util.format("https://storage.googleapis.com/kubernetes-release/release/%s/bin/linux/amd64/kubectl", version);
        case 'Darwin':
            return util.format("https://storage.googleapis.com/kubernetes-release/release/%s/bin/darwin/amd64/kubectl", version);
        default:
        case 'Windows_NT':
            return util.format("https://storage.googleapis.com/kubernetes-release/release/%s/bin/windows/amd64/kubectl.exe", version);
    }
}
function assertFileExists(path) {
    if (!fs.existsSync(path)) {
        tl.error(tl.loc('FileNotFoundException', path));
        throw new Error(tl.loc('FileNotFoundException', path));
    }
}
exports.assertFileExists = assertFileExists;

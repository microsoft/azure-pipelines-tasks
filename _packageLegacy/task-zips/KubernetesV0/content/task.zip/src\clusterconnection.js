"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const tl = require("vsts-task-lib/task");
const utils = require("./utilities");
const os = require("os");
const kubectlutility = require("utility-common/kubectlutility");
class ClusterConnection {
    constructor() {
        this.kubectlPath = tl.which("kubectl", false);
        this.userDir = utils.getNewUserDirPath();
    }
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.kubectlPath || !fs.existsSync(this.kubectlPath)) {
                return this.getKubectl().then((kubectlpath) => {
                    this.kubectlPath = kubectlpath;
                });
            }
        });
    }
    createCommand() {
        var command = tl.tool(this.kubectlPath);
        if (this.kubeconfigFile) {
            command.arg("--kubeconfig");
            command.arg(this.kubeconfigFile);
        }
        return command;
    }
    // open kubernetes connection
    open(kubernetesEndpoint) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.initialize().then(() => {
                var authorizationType = tl.getEndpointDataParameter(kubernetesEndpoint, 'authorizationType', true);
                var kubeconfig = null;
                if (authorizationType == null || authorizationType === "Kubeconfig") {
                    if (kubernetesEndpoint) {
                        kubeconfig = tl.getEndpointAuthorizationParameter(kubernetesEndpoint, 'kubeconfig', false);
                    }
                }
                else if (authorizationType === "ServiceAccount") {
                    kubeconfig = kubectlutility.createKubeconfig(kubernetesEndpoint);
                }
                this.kubeconfigFile = path.join(this.userDir, "config");
                fs.writeFileSync(this.kubeconfigFile, kubeconfig);
            });
        });
    }
    // close kubernetes connection
    close() {
        // all configuration are in agent temp directory. Hence automatically deleted.
    }
    //excute kubernetes command
    execCommand(command, options) {
        var errlines = [];
        command.on("errline", line => {
            errlines.push(line);
        });
        return command.exec(options).fail(error => {
            errlines.forEach(line => tl.error(line));
            throw error;
        });
    }
    getExecutableExtention() {
        if (os.type().match(/^Win/)) {
            return ".exe";
        }
        return "";
    }
    getKubectl() {
        return __awaiter(this, void 0, void 0, function* () {
            let versionOrLocation = tl.getInput("versionOrLocation");
            if (versionOrLocation === "location") {
                let pathToKubectl = tl.getPathInput("specifyLocation", true, true);
                fs.chmod(pathToKubectl, "777");
                return pathToKubectl;
            }
            else if (versionOrLocation === "version") {
                tl.debug(tl.loc("DownloadingClient"));
                var kubectlPath = path.join(this.userDir, "kubectl") + this.getExecutableExtention();
                let versionSpec = tl.getInput("versionSpec");
                let checkLatest = tl.getBoolInput('checkLatest', false);
                return utils.getKubectlVersion(versionSpec, checkLatest).then((version) => {
                    return utils.downloadKubectl(version, kubectlPath);
                });
            }
        });
    }
}
exports.default = ClusterConnection;

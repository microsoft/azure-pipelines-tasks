"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const AzureRmWebAppDeploymentProvider_1 = require("./AzureRmWebAppDeploymentProvider");
const tl = require("vsts-task-lib/task");
const FileTransformsUtility_1 = require("../operations/FileTransformsUtility");
const ParameterParser = require("../operations/parameterparser");
const TaskParameters_1 = require("../operations/TaskParameters");
const runFromZipAppSetting = '-WEBSITE_RUN_FROM_ZIP 1';
class WindowsWebAppRunFromZipProvider extends AzureRmWebAppDeploymentProvider_1.AzureRmWebAppDeploymentProvider {
    DeployWebAppStep() {
        return __awaiter(this, void 0, void 0, function* () {
            var webPackage = yield FileTransformsUtility_1.FileTransformsUtility.applyTransformations(this.taskParams.Package.getPath(), this.taskParams);
            if (this.taskParams.UseWebDeploy && this.taskParams.DeploymentType === TaskParameters_1.DeploymentType.runFromZip) {
                var _isMSBuildPackage = yield this.taskParams.Package.isMSBuildPackage();
                if (_isMSBuildPackage) {
                    throw Error(tl.loc("Publishusingzipdeploynotsupportedformsbuildpackage"));
                }
                else if (this.taskParams.VirtualApplication) {
                    throw Error(tl.loc("Publishusingzipdeploynotsupportedforvirtualapplication"));
                }
                else if (this.taskParams.Package.isWarFile()) {
                    throw Error(tl.loc("Publishusingzipdeploydoesnotsupportwarfile"));
                }
            }
            tl.debug("Initiated deployment via kudu service for webapp package : ");
            var customApplicationSetting = ParameterParser.parse(runFromZipAppSetting);
            yield this.appServiceUtility.updateAndMonitorAppSettings(customApplicationSetting);
            yield this.kuduServiceUtility.zipDeploy(webPackage, true, this.taskParams.TakeAppOfflineFlag, { slotName: this.appService.getSlot() });
            yield this.PostDeploymentStep();
        });
    }
    UpdateDeploymentStatus(isDeploymentSuccess) {
        const _super = name => super[name];
        return __awaiter(this, void 0, void 0, function* () {
            if (this.taskParams.ScriptType && this.kuduServiceUtility) {
                yield _super("UpdateDeploymentStatus").call(this, isDeploymentSuccess);
            }
        });
    }
}
exports.WindowsWebAppRunFromZipProvider = WindowsWebAppRunFromZipProvider;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConnectionType = {
    PublishProfile: "PublishProfile",
    AzureRM: "AzureRM"
};
exports.SiteRoot = '/site/wwwroot';
exports.PublishProfileXml = {
    ExcludeApp_Data: "ExcludeApp_Data",
    EnableMSDeployAppOffline: "EnableMSDeployAppOffline",
    SkipExtraFilesOnServer: "SkipExtraFilesOnServer",
    SiteUrlToLaunchAfterPublish: "SiteUrlToLaunchAfterPublish",
    MSDeployServiceURL: "MSDeployServiceURL",
    DeployIisAppPath: "DeployIisAppPath",
    MSDeploy: "MSDeploy",
    UserName: "UserName"
};

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const TaskParameters_1 = require("../operations/TaskParameters");
const Constant = require("../operations/Constants");
const PublishProfileWebAppDeploymentProvider_1 = require("./PublishProfileWebAppDeploymentProvider");
const BuiltInLinuxWebAppDeploymentProvider_1 = require("./BuiltInLinuxWebAppDeploymentProvider");
const WindowsWebAppWebDeployProvider_1 = require("./WindowsWebAppWebDeployProvider");
const WindowsWebAppZipDeployProvider_1 = require("./WindowsWebAppZipDeployProvider");
const WindowsWebAppRunFromZipProvider_1 = require("./WindowsWebAppRunFromZipProvider");
const ContainerWebAppDeploymentProvider_1 = require("./ContainerWebAppDeploymentProvider");
const tl = require("vsts-task-lib/task");
class DeploymentFactory {
    static GetDeploymentProvider(taskParams) {
        return __awaiter(this, void 0, void 0, function* () {
            switch (taskParams.ConnectionType) {
                case Constant.ConnectionType.PublishProfile:
                    return new PublishProfileWebAppDeploymentProvider_1.PublishProfileWebAppDeploymentProvider(taskParams);
                case Constant.ConnectionType.AzureRM:
                    if (taskParams.isLinuxApp) {
                        if (taskParams.isBuiltinLinuxWebApp) {
                            return new BuiltInLinuxWebAppDeploymentProvider_1.BuiltInLinuxWebAppDeploymentProvider(taskParams);
                        }
                        else if (taskParams.isContainerWebApp) {
                            return new ContainerWebAppDeploymentProvider_1.ContainerWebAppDeploymentProvider(taskParams);
                        }
                        else {
                            throw new Error(tl.loc('InvalidImageSourceType'));
                        }
                    }
                    else {
                        if (taskParams.UseWebDeploy && taskParams.DeploymentType === TaskParameters_1.DeploymentType.webDeploy) {
                            return new WindowsWebAppWebDeployProvider_1.WindowsWebAppWebDeployProvider(taskParams);
                        }
                        else if (taskParams.UseWebDeploy && taskParams.DeploymentType === TaskParameters_1.DeploymentType.zipDeploy) {
                            return new WindowsWebAppZipDeployProvider_1.WindowsWebAppZipDeployProvider(taskParams);
                        }
                        else if (taskParams.UseWebDeploy && taskParams.DeploymentType === TaskParameters_1.DeploymentType.runFromZip) {
                            return new WindowsWebAppRunFromZipProvider_1.WindowsWebAppRunFromZipProvider(taskParams);
                        }
                        else {
                            var _isMSBuildPackage = yield taskParams.Package.isMSBuildPackage();
                            if (_isMSBuildPackage || taskParams.VirtualApplication || taskParams.Package.isWarFile()) {
                                return new WindowsWebAppWebDeployProvider_1.WindowsWebAppWebDeployProvider(taskParams);
                            }
                            else if (taskParams.ScriptType) {
                                return new WindowsWebAppZipDeployProvider_1.WindowsWebAppZipDeployProvider(taskParams);
                            }
                            else {
                                return new WindowsWebAppRunFromZipProvider_1.WindowsWebAppRunFromZipProvider(taskParams);
                            }
                        }
                    }
                default:
                    throw new Error(tl.loc('InvalidConnectionType'));
            }
        });
    }
}
exports.DeploymentFactory = DeploymentFactory;

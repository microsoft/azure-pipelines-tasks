"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const basecommand_1 = require("./basecommand");
class helmcli extends basecommand_1.default {
    constructor() {
        super(true);
        this.arguments = [];
    }
    getTool() {
        return "helm";
    }
    login() {
    }
    logout() {
    }
    setCommand(command) {
        this.command = command;
    }
    getCommand() {
        return this.command;
    }
    addArgument(argument) {
        this.arguments.push(argument);
    }
    getArguments() {
        return this.arguments;
    }
    execHelmCommand() {
        var command = this.createCommand();
        command.arg(this.command);
        this.arguments.forEach((value) => {
            command.line(value);
        });
        this.execCommandSync(command);
    }
}
exports.default = helmcli;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const helmcli_1 = require("./helmcli");
const kubernetescli_1 = require("./kubernetescli");
const helmutil = require("./utils");
const fs = require("fs");
const commonCommandOptions = require("./commoncommandoption");
tl.setResourcePath(path.join(__dirname, '..', 'task.json'));
function getKubeConfigFilePath() {
    var userdir = helmutil.getTaskTempDir();
    return path.join(userdir, "config");
}
function getClusterType() {
    var connectionType = tl.getInput("connectionType", true);
    if (connectionType === "Azure Resource Manager") {
        return require("./clusters/armkubernetescluster");
    }
    return require("./clusters/generickubernetescluster");
}
// get kubeconfig file path
function getKubeConfigFile() {
    return __awaiter(this, void 0, void 0, function* () {
        return getClusterType().getKubeConfig().then((config) => {
            var configFilePath = getKubeConfigFilePath();
            tl.debug(tl.loc("KubeConfigFilePath", configFilePath));
            fs.writeFileSync(configFilePath, config);
            return configFilePath;
        });
    });
}
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        var kubeconfigfilePath = yield getKubeConfigFile();
        var kubectlCli = new kubernetescli_1.default(kubeconfigfilePath);
        var helmCli = new helmcli_1.default();
        kubectlCli.login();
        helmCli.login();
        try {
            runHelm(helmCli);
        }
        catch (err) {
            // not throw error so that we can logout from helm and kubernetes
            tl.setResult(tl.TaskResult.Failed, err.message);
        }
        finally {
            helmutil.deleteFile(kubeconfigfilePath);
            kubectlCli.logout();
            helmCli.logout();
        }
    });
}
function runHelm(helmCli) {
    var command = tl.getInput("command", true);
    var helmCommandMap = {
        "init": "./helmcommands/helminit",
        "install": "./helmcommands/helminstall",
        "package": "./helmcommands/helmpackage",
        "upgrade": "./helmcommands/helmupgrade"
    };
    var commandImplementation = require("./helmcommands/uinotimplementedcommands");
    if (command in helmCommandMap) {
        commandImplementation = require(helmCommandMap[command]);
    }
    //set command
    helmCli.setCommand(command);
    // add arguments
    commonCommandOptions.addArguments(helmCli);
    commandImplementation.addArguments(helmCli);
    // execute command
    helmCli.execHelmCommand();
}
run().then(() => {
    // do nothing
}, (reason) => {
    tl.setResult(tl.TaskResult.Failed, reason);
});

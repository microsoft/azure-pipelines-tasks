"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const tlssetting_1 = require("./../tlssetting");
function addArguments(helmCli) {
    var waitForTiller = tl.getBoolInput('waitForExecution', false);
    var canaryimage = tl.getBoolInput('canaryimage', false);
    var upgradeTiller = tl.getBoolInput('upgradetiller', false);
    var argumentsInput = tl.getInput("arguments", false);
    var enableTls = tl.getBoolInput("enableTls", false);
    if (canaryimage) {
        helmCli.addArgument("--canary-image");
    }
    if (upgradeTiller) {
        helmCli.addArgument("--upgrade");
    }
    if (waitForTiller) {
        helmCli.addArgument("--wait");
    }
    if (enableTls) {
        tlssetting_1.addTillerTlsSettings(helmCli);
    }
    if (argumentsInput) {
        helmCli.addArgument(argumentsInput);
    }
}
exports.addArguments = addArguments;

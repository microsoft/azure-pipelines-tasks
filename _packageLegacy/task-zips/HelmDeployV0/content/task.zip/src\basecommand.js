"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
class basecommand {
    constructor(required) {
        this.toolPath = tl.which(this.getTool(), required);
    }
    getToolPath() {
        return this.toolPath;
    }
    createCommand() {
        var command = tl.tool(this.toolPath);
        return command;
    }
    execCommand(command, options) {
        var errlines = [];
        command.on("stderr", line => {
            errlines.push(line);
        });
        command.on("error", line => {
            errlines.push(line);
        });
        return command.exec(options).fail(error => {
            errlines.forEach(line => tl.error(line));
            throw error;
        });
    }
    execCommandSync(command, options) {
        basecommand.handleExecResult(command.execSync(options));
    }
    IsInstalled() {
        return !!this.getToolPath();
    }
    static handleExecResult(execResult) {
        if (execResult.code != tl.TaskResult.Succeeded || !!execResult.error || !!execResult.stderr) {
            tl.debug('execResult: ' + JSON.stringify(execResult));
            tl.setResult(tl.TaskResult.Failed, execResult.stderr);
        }
    }
}
exports.default = basecommand;

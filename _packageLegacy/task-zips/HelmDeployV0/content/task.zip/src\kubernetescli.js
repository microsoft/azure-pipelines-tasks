"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const basecommand_1 = require("./basecommand");
class kubernetescli extends basecommand_1.default {
    constructor(kubeconfigPath) {
        super(true);
        this.kubeconfigPath = kubeconfigPath;
    }
    getTool() {
        return "kubectl";
    }
    login() {
        process.env["KUBECONFIG"] = this.kubeconfigPath;
    }
    logout() {
        delete process.env["KUBECONFIG"];
    }
}
exports.default = kubernetescli;

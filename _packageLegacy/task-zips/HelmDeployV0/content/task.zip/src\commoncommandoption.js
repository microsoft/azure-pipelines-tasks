"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
function addArguments(helmCli) {
    var tillernamespace = tl.getInput("tillernamespace", false);
    var debugMode = tl.getVariable('system.debug');
    if (tillernamespace) {
        helmCli.addArgument("--tiller-namespace ".concat(tillernamespace));
    }
    if (debugMode === 'true') {
        helmCli.addArgument("--debug");
    }
}
exports.addArguments = addArguments;

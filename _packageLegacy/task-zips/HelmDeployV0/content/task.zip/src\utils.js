"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require('fs');
const path = require("path");
const tl = require("vsts-task-lib/task");
const os = require("os");
function getTempDirectory() {
    return tl.getVariable('agent.tempDirectory') || os.tmpdir();
}
exports.getTempDirectory = getTempDirectory;
function getCurrentTime() {
    return new Date().getTime();
}
exports.getCurrentTime = getCurrentTime;
function getTaskTempDir() {
    var userDir = path.join(getTempDirectory(), "helmTask");
    ensureDirExists(userDir);
    userDir = path.join(userDir, getCurrentTime().toString());
    ensureDirExists(userDir);
    return userDir;
}
exports.getTaskTempDir = getTaskTempDir;
function deleteFile(filepath) {
    if (fs.existsSync(filepath)) {
        fs.unlinkSync(filepath);
    }
}
exports.deleteFile = deleteFile;
function resolvePath(path) {
    if (path.indexOf('*') >= 0 || path.indexOf('?') >= 0) {
        tl.debug(tl.loc('PatternFoundInPath', path));
        var rootFolder = tl.getVariable('System.DefaultWorkingDirectory');
        var allPaths = tl.find(rootFolder);
        var matchingResultsFiles = tl.match(allPaths, path, rootFolder, { matchBase: true });
        if (!matchingResultsFiles || matchingResultsFiles.length == 0) {
            throw new Error(tl.loc('CantResolvePatternInPath', path));
        }
        return matchingResultsFiles[0];
    }
    else {
        tl.debug(tl.loc('PatternNotFoundInFilePath', path));
        return path;
    }
}
exports.resolvePath = resolvePath;
function ensureDirExists(dirPath) {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath);
    }
}

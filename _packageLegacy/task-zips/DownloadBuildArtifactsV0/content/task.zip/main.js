"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
var path = require('path');
var url = require('url');
var fs = require('fs');
const tl = require("vsts-task-lib/task");
const WebApi_1 = require("./vso-node-api/WebApi");
const BuildInterfaces_1 = require("./vso-node-api/interfaces/BuildInterfaces");
const engine = require("artifact-engine/Engine");
const providers = require("artifact-engine/Providers");
const webHandlers = require("artifact-engine/Providers/typed-rest-client/Handlers");
var taskJson = require('./task.json');
tl.setResourcePath(path.join(__dirname, 'task.json'));
const area = 'DownloadBuildArtifacts';
function getDefaultProps() {
    var hostType = (tl.getVariable('SYSTEM.HOSTTYPE') || "").toLowerCase();
    return {
        hostType: hostType,
        definitionName: '[NonEmail:' + (hostType === 'release' ? tl.getVariable('RELEASE.DEFINITIONNAME') : tl.getVariable('BUILD.DEFINITIONNAME')) + ']',
        processId: hostType === 'release' ? tl.getVariable('RELEASE.RELEASEID') : tl.getVariable('BUILD.BUILDID'),
        processUrl: hostType === 'release' ? tl.getVariable('RELEASE.RELEASEWEBURL') : (tl.getVariable('SYSTEM.TEAMFOUNDATIONSERVERURI') + tl.getVariable('SYSTEM.TEAMPROJECT') + '/_build?buildId=' + tl.getVariable('BUILD.BUILDID')),
        taskDisplayName: tl.getVariable('TASK.DISPLAYNAME'),
        jobid: tl.getVariable('SYSTEM.JOBID'),
        agentVersion: tl.getVariable('AGENT.VERSION'),
        agentOS: tl.getVariable('AGENT.OS'),
        agentName: tl.getVariable('AGENT.NAME'),
        version: taskJson.version
    };
}
function publishEvent(feature, properties) {
    try {
        var splitVersion = (process.env.AGENT_VERSION || '').split('.');
        var major = parseInt(splitVersion[0] || '0');
        var minor = parseInt(splitVersion[1] || '0');
        let telemetry = '';
        if (major > 2 || (major == 2 && minor >= 120)) {
            telemetry = `##vso[telemetry.publish area=${area};feature=${feature}]${JSON.stringify(Object.assign(getDefaultProps(), properties))}`;
        }
        else {
            if (feature === 'reliability') {
                let reliabilityData = properties;
                telemetry = "##vso[task.logissue type=error;code=" + reliabilityData.issueType + ";agentVersion=" + tl.getVariable('Agent.Version') + ";taskId=" + area + "-" + JSON.stringify(taskJson.version) + ";]" + reliabilityData.errorMessage;
            }
        }
        console.log(telemetry);
        ;
    }
    catch (err) {
        tl.warning("Failed to log telemetry, error: " + err);
    }
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        var promise = new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
            var buildType = tl.getInput("buildType", true);
            var isCurrentBuild = buildType.toLowerCase() === 'current';
            var isSpecificBuildWithTriggering = tl.getBoolInput("specificBuildWithTriggering", false);
            var projectId = null;
            var definitionId = null;
            var definitionIdSpecified = null;
            var definitionIdTriggered = null;
            var buildId = null;
            var buildVersionToDownload = tl.getInput("buildVersionToDownload", false);
            var branchName = tl.getInput("branchName", false);
            ;
            var downloadPath = tl.getInput("downloadPath", true);
            var downloadType = tl.getInput("downloadType", true);
            var endpointUrl = tl.getVariable("System.TeamFoundationCollectionUri");
            var accessToken = tl.getEndpointAuthorizationParameter('SYSTEMVSSCONNECTION', 'AccessToken', false);
            var credentialHandler = WebApi_1.getHandlerFromToken(accessToken);
            var webApi = new WebApi_1.WebApi(endpointUrl, credentialHandler);
            var debugMode = tl.getVariable('System.Debug');
            var isVerbose = debugMode ? debugMode.toLowerCase() != 'false' : false;
            var parallelLimit = +tl.getInput("parallelizationLimit", false);
            var retryLimit = parseInt(tl.getVariable("VSTS_HTTP_RETRY")) ? parseInt(tl.getVariable("VSTS_HTTP_RETRY")) : 4;
            var templatePath = path.join(__dirname, 'vsts.handlebars.txt');
            var buildApi = webApi.getBuildApi();
            var artifacts = [];
            var itemPattern = tl.getInput("itemPattern", false) || '**';
            if (isCurrentBuild) {
                projectId = tl.getVariable("System.TeamProjectId");
                definitionId = '';
                buildId = parseInt(tl.getVariable("Build.BuildId"));
            }
            else {
                var releaseAlias = tl.getVariable("release.triggeringartifact.alias");
                var triggeringBuildFound = false;
                definitionIdSpecified = tl.getInput("definition", true);
                if (isSpecificBuildWithTriggering) {
                    let hostType = tl.getVariable('system.hostType');
                    if ((hostType && hostType.toUpperCase() != 'BUILD')) {
                        // try to use alias to grab triggering artifact for release, starting with definition to verify parity with specified definition
                        definitionIdTriggered = tl.getVariable("release.artifacts." + releaseAlias + ".definitionId");
                        if (definitionIdTriggered == definitionIdSpecified) {
                            // populate values using the triggering build
                            projectId = tl.getVariable("release.artifacts." + releaseAlias + ".projectId");
                            definitionId = definitionIdTriggered;
                            buildId = parseInt(tl.getVariable("release.artifacts." + releaseAlias + ".buildId"));
                            // verify that the triggerring bruild's info was found
                            if (projectId && definitionId && buildId) {
                                triggeringBuildFound = true;
                            }
                        }
                    }
                    else {
                        //Verify that the triggering build's definition is the same as the specified definition
                        definitionIdTriggered = tl.getVariable("build.triggeredBy.definitionId");
                        if (definitionIdTriggered == definitionIdSpecified) {
                            // populate values using the triggering build
                            projectId = tl.getVariable("build.triggeredBy.projectId");
                            definitionId = definitionIdTriggered;
                            buildId = parseInt(tl.getVariable("build.triggeredBy.buildId"));
                            // verify that the triggerring bruild's info was found
                            if (projectId && definitionId && buildId) {
                                triggeringBuildFound = true;
                            }
                        }
                    }
                }
                if (!triggeringBuildFound) {
                    // Triggering build info not found, or requested, default to specified build info
                    projectId = tl.getInput("project", true);
                    definitionId = definitionIdSpecified;
                    buildId = parseInt(tl.getInput("buildId", buildVersionToDownload == "specific"));
                }
            }
            // verify that buildId belongs to the definition selected
            if (definitionId) {
                var build;
                if (buildVersionToDownload != "specific") {
                    var branchNameFilter = (buildVersionToDownload == "latest") ? null : branchName;
                    // get latest successful build filtered by branch
                    var buildsForThisDefinition = yield executeWithRetries("getBuildId", () => buildApi.getBuilds(projectId, [parseInt(definitionId)], null, null, null, null, null, null, BuildInterfaces_1.BuildStatus.Completed, BuildInterfaces_1.BuildResult.Succeeded, null, null, null, null, null, null, BuildInterfaces_1.BuildQueryOrder.FinishTimeDescending, branchNameFilter), retryLimit).catch((reason) => {
                        reject(reason);
                        return;
                    });
                    if (!buildsForThisDefinition || buildsForThisDefinition.length == 0) {
                        if (buildVersionToDownload == "latestFromBranch")
                            reject(tl.loc("LatestBuildFromBranchNotFound", branchNameFilter));
                        else
                            reject(tl.loc("LatestBuildNotFound"));
                        return;
                    }
                    build = buildsForThisDefinition[0];
                    console.log(tl.loc("LatestBuildFound", build.id));
                    buildId = build.id;
                }
                if (!build) {
                    build = yield executeWithRetries("getBuild", () => buildApi.getBuild(buildId, projectId), retryLimit).catch((reason) => {
                        reject(reason);
                        return;
                    });
                }
                if (build) {
                    if (!build.definition || build.definition.id !== parseInt(definitionId)) {
                        reject(tl.loc("BuildIdBuildDefinitionMismatch", buildId, definitionId));
                        return;
                    }
                }
                else {
                    reject(tl.loc("BuildNotFound", buildId));
                    return;
                }
            }
            console.log(tl.loc("DownloadingArtifactsForBuild", buildId));
            // populate itempattern and artifacts based on downloadType
            if (downloadType === 'single') {
                var artifactName = tl.getInput("artifactName", true);
                var artifact = yield executeWithRetries("getArtifact", () => buildApi.getArtifact(buildId, artifactName, projectId), retryLimit).catch((reason) => {
                    reject(reason);
                    return;
                });
                if (!artifact) {
                    reject(tl.loc("BuildArtifactNotFound", artifactName, buildId));
                    return;
                }
                artifacts.push(artifact);
            }
            else {
                var buildArtifacts = yield executeWithRetries("getArtifacts", () => buildApi.getArtifacts(buildId, projectId), retryLimit).catch((reason) => {
                    reject(reason);
                });
                if (!buildArtifacts) {
                    tl.warning(tl.loc("NoArtifactsFound", buildId));
                    resolve();
                    return;
                }
                console.log(tl.loc("LinkedArtifactCount", buildArtifacts.length));
                artifacts = artifacts.concat(buildArtifacts);
            }
            if (artifacts) {
                var downloadPromises = [];
                artifacts.forEach(function (artifact, index, artifacts) {
                    return __awaiter(this, void 0, void 0, function* () {
                        let downloaderOptions = new engine.ArtifactEngineOptions();
                        downloaderOptions.itemPattern = itemPattern;
                        downloaderOptions.verbose = isVerbose;
                        if (parallelLimit) {
                            downloaderOptions.parallelProcessingLimit = parallelLimit;
                        }
                        if (artifact.resource.type.toLowerCase() === "container") {
                            let downloader = new engine.ArtifactEngine();
                            console.log(tl.loc("DownloadingContainerResource", artifact.resource.data));
                            var containerParts = artifact.resource.data.split('/');
                            if (containerParts.length < 3) {
                                throw new Error(tl.loc("FileContainerInvalidArtifactData"));
                            }
                            var containerId = parseInt(containerParts[1]);
                            var containerPath = containerParts.slice(2, containerParts.length).join('/');
                            var itemsUrl = endpointUrl + "/_apis/resources/Containers/" + containerId + "?itemPath=" + encodeURIComponent(containerPath) + "&isShallow=true&api-version=4.1-preview.4";
                            console.log(tl.loc("DownloadArtifacts", artifact.name, itemsUrl));
                            var variables = {};
                            var handler = new webHandlers.PersonalAccessTokenCredentialHandler(accessToken);
                            var webProvider = new providers.WebProvider(itemsUrl, templatePath, variables, handler);
                            var fileSystemProvider = new providers.FilesystemProvider(downloadPath);
                            downloadPromises.push(downloader.processItems(webProvider, fileSystemProvider, downloaderOptions).catch((reason) => {
                                reject(reason);
                            }));
                        }
                        else if (artifact.resource.type.toLowerCase() === "filepath") {
                            let downloader = new engine.ArtifactEngine();
                            let downloadUrl = artifact.resource.data;
                            let artifactName = artifact.name.replace('/', '\\');
                            let artifactLocation = path.join(downloadUrl, artifactName);
                            if (!fs.existsSync(artifactLocation)) {
                                console.log(tl.loc("ArtifactNameDirectoryNotFound", artifactLocation, downloadUrl));
                                artifactLocation = downloadUrl;
                            }
                            console.log(tl.loc("DownloadArtifacts", artifact.name, artifactLocation));
                            var fileShareProvider = new providers.FilesystemProvider(artifactLocation, artifactName);
                            var fileSystemProvider = new providers.FilesystemProvider(downloadPath);
                            downloadPromises.push(downloader.processItems(fileShareProvider, fileSystemProvider, downloaderOptions).catch((reason) => {
                                reject(reason);
                            }));
                        }
                        else {
                            console.log(tl.loc("UnsupportedArtifactType", artifact.resource.type));
                        }
                    });
                });
                Promise.all(downloadPromises).then(() => {
                    console.log(tl.loc('ArtifactsSuccessfullyDownloaded', downloadPath));
                    resolve();
                }).catch((error) => {
                    reject(error);
                });
            }
        }));
        return promise;
    });
}
function executeWithRetries(operationName, operation, retryCount) {
    var executePromise = new Promise((resolve, reject) => {
        executeWithRetriesImplementation(operationName, operation, retryCount, resolve, reject);
    });
    return executePromise;
}
function executeWithRetriesImplementation(operationName, operation, currentRetryCount, resolve, reject) {
    operation().then((result) => {
        resolve(result);
    }).catch((error) => {
        if (currentRetryCount <= 0) {
            tl.error(tl.loc("OperationFailed", operationName, error));
            reject(error);
        }
        else {
            console.log(tl.loc('RetryingOperation', operationName, currentRetryCount));
            currentRetryCount = currentRetryCount - 1;
            setTimeout(() => executeWithRetriesImplementation(operationName, operation, currentRetryCount, resolve, reject), 4 * 1000);
        }
    });
}
main()
    .then((result) => tl.setResult(tl.TaskResult.Succeeded, ""))
    .catch((err) => {
    publishEvent('reliability', { issueType: 'error', errorMessage: JSON.stringify(err, Object.getOwnPropertyNames(err)) });
    tl.setResult(tl.TaskResult.Failed, err);
});

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const url_1 = require("url");
const Q = require("q");
const tl = require("vsts-task-lib/task");
const tr = require("vsts-task-lib/toolrunner");
const constants_1 = require("./constants");
const util = require("npm-common/util");
const telemetry = require("utility-common/telemetry");
class NpmToolRunner extends tr.ToolRunner {
    constructor(workingDirectory, npmrc, overrideProjectNpmrc) {
        super('npm');
        this.workingDirectory = workingDirectory;
        this.npmrc = npmrc;
        this.overrideProjectNpmrc = overrideProjectNpmrc;
        this.projectNpmrc = () => path.join(this.workingDirectory, '.npmrc');
        this.on('debug', (message) => {
            tl.debug(message);
        });
        let debugVar = tl.getVariable('System.Debug') || '';
        if (debugVar.toLowerCase() === 'true') {
            this.dbg = true;
        }
        let cacheOptions = { silent: true };
        if (!tl.stats(workingDirectory).isDirectory()) {
            throw new Error(tl.loc('WorkingDirectoryNotDirectory'));
        }
        this.cacheLocation = tl.execSync('npm', 'config get cache', this._prepareNpmEnvironment(cacheOptions)).stdout.trim();
    }
    exec(options) {
        options = this._prepareNpmEnvironment(options);
        this._saveProjectNpmrc();
        return super.exec(options).then((code) => {
            this._restoreProjectNpmrc();
            return code;
        }, (reason) => {
            this._restoreProjectNpmrc();
            return this._printDebugLog(this._getDebugLogPath(options)).then((value) => {
                throw reason;
            });
        });
    }
    execSync(options) {
        options = this._prepareNpmEnvironment(options);
        this._saveProjectNpmrc();
        const execResult = super.execSync(options);
        this._restoreProjectNpmrc();
        if (execResult.code !== 0) {
            telemetry.logResult('Packaging', 'npm', execResult.code);
            this._printDebugLogSync(this._getDebugLogPath(options));
            throw new Error(tl.loc('NpmFailed', execResult.code));
        }
        return execResult;
    }
    static _getProxyFromEnvironment() {
        let proxyUrl = tl.getVariable('agent.proxyurl');
        if (proxyUrl) {
            let proxy = url_1.parse(proxyUrl);
            let proxyUsername = tl.getVariable('agent.proxyusername') || '';
            let proxyPassword = tl.getVariable('agent.proxypassword') || '';
            let auth = `${proxyUsername}:${proxyPassword}`;
            proxy.auth = auth;
            return url_1.format(proxy);
        }
        return undefined;
    }
    _prepareNpmEnvironment(options) {
        options = options || {};
        options.cwd = this.workingDirectory;
        if (options.env === undefined) {
            options.env = process.env;
        }
        if (this.dbg || tl.getBoolInput(constants_1.NpmTaskInput.Verbose, false)) {
            options.env['NPM_CONFIG_LOGLEVEL'] = 'verbose';
        }
        if (this.npmrc) {
            options.env['NPM_CONFIG_USERCONFIG'] = this.npmrc;
        }
        let proxy = NpmToolRunner._getProxyFromEnvironment();
        if (proxy) {
            tl.debug(`Using proxy "${proxy}" for npm`);
            options.env['NPM_CONFIG_PROXY'] = proxy;
            options.env['NPM_CONFIG_HTTPS-PROXY'] = proxy;
        }
        let config = tl.execSync('npm', `config list ${this.dbg ? '-l' : ''}`, options);
        return options;
    }
    _getDebugLogPath(options) {
        // check cache
        const logs = tl.findMatch(path.join(this.cacheLocation, '_logs'), '*-debug.log');
        if (logs && logs.length > 0) {
            const debugLog = logs[logs.length - 1];
            console.log(tl.loc('FoundNpmDebugLog', debugLog));
            return debugLog;
        }
        // check working dir
        const cwd = options && options.cwd ? options.cwd : process.cwd;
        const debugLog = path.join(cwd, 'npm-debug.log');
        tl.debug(tl.loc('TestDebugLog', debugLog));
        if (tl.exist(debugLog)) {
            console.log(tl.loc('FoundNpmDebugLog', debugLog));
            return debugLog;
        }
        tl.warning(tl.loc('DebugLogNotFound'));
        return undefined;
    }
    _printDebugLog(log) {
        if (!log) {
            return Q.fcall(() => { });
        }
        return Q.nfcall(fs.readFile, log, 'utf-8').then((data) => {
            console.log(data);
        });
    }
    _printDebugLogSync(log) {
        if (!log) {
            return;
        }
        console.log(fs.readFileSync(log, 'utf-8'));
    }
    _saveProjectNpmrc() {
        if (this.overrideProjectNpmrc) {
            tl.debug(tl.loc('OverridingProjectNpmrc', this.projectNpmrc()));
            util.saveFile(this.projectNpmrc());
            tl.rmRF(this.projectNpmrc());
        }
    }
    _restoreProjectNpmrc() {
        if (this.overrideProjectNpmrc) {
            tl.debug(tl.loc('RestoringProjectNpmrc'));
            util.restoreFile(this.projectNpmrc());
        }
    }
}
exports.NpmToolRunner = NpmToolRunner;

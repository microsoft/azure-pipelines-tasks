"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const constants_1 = require("./constants");
const npmCustom = require("./npmcustom");
const npmPublish = require("./npmpublish");
const telemetry = require("utility-common/telemetry");
const util = require("npm-common/util");
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        tl.setResourcePath(path.join(__dirname, 'task.json'));
        yield _logNpmStartupVariables();
        const command = tl.getInput(constants_1.NpmTaskInput.Command);
        switch (command) {
            case constants_1.NpmCommand.Install:
                return npmCustom.run(constants_1.NpmCommand.Install);
            case constants_1.NpmCommand.Publish:
                return npmPublish.run();
            case constants_1.NpmCommand.Custom:
                return npmCustom.run();
            default:
                tl.setResult(tl.TaskResult.Failed, tl.loc('UnknownCommand', command));
                return;
        }
    });
}
function _logNpmStartupVariables() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Log the NPM version
            let version;
            try {
                let syncResult = tl.execSync('npm', '--version');
                if (syncResult.stdout) {
                    version = syncResult.stdout.trim();
                }
            }
            catch (err) {
                tl.debug(`Unable to get NPM config info. Err:( ${err} )`);
            }
            // Log the NPM registries
            let command = tl.getInput(constants_1.NpmTaskInput.Command);
            let npmRegistriesAry;
            let registryUrlAry = [];
            switch (command) {
                case constants_1.NpmCommand.Install:
                case constants_1.NpmCommand.Custom:
                    npmRegistriesAry = yield npmCustom.getCustomRegistries();
                    break;
                case constants_1.NpmCommand.Publish:
                    npmRegistriesAry = [yield npmPublish.getPublishRegistry()];
                    break;
            }
            for (let registry of npmRegistriesAry) {
                registryUrlAry.push(registry.url);
            }
            let npmTelem = {
                'command': command,
                'verbose': tl.getInput(constants_1.NpmTaskInput.Verbose),
                'customRegistry': tl.getInput(constants_1.NpmTaskInput.CustomRegistry),
                'customFeed': tl.getInput(constants_1.NpmTaskInput.CustomFeed),
                'customEndpoint': tl.getInput(constants_1.NpmTaskInput.CustomEndpoint),
                'publishRegistry': tl.getInput(constants_1.NpmTaskInput.PublishRegistry),
                'publishFeed': tl.getInput(constants_1.NpmTaskInput.PublishFeed),
                'publishEndpoint': tl.getInput(constants_1.NpmTaskInput.PublishEndpoint),
                'npmVersion': version,
                'registries': registryUrlAry
            };
            telemetry.emitTelemetry('Packaging', 'npm', npmTelem);
        }
        catch (err) {
            tl.debug(`Unable to log NPM task telemetry. Err:( ${err} )`);
        }
    });
}
main().catch(error => {
    tl.rmRF(util.getTempPath());
    tl.setResult(tl.TaskResult.Failed, error);
});

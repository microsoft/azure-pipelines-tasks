"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const constants_1 = require("./constants");
const npmregistry_1 = require("npm-common/npmregistry");
const npmtoolrunner_1 = require("./npmtoolrunner");
const util = require("npm-common/util");
function run(command) {
    return __awaiter(this, void 0, void 0, function* () {
        let workingDir = tl.getInput(constants_1.NpmTaskInput.WorkingDir) || process.cwd();
        let npmrc = util.getTempNpmrcPath();
        let npmRegistries = yield getCustomRegistries();
        let overrideNpmrc = (tl.getInput(constants_1.NpmTaskInput.CustomRegistry) == constants_1.RegistryLocation.Feed) ? true : false;
        for (let registry of npmRegistries) {
            if (registry.authOnly === false) {
                tl.debug(tl.loc('UsingRegistry', registry.url));
                util.appendToNpmrc(npmrc, `registry=${registry.url}\n`);
            }
            tl.debug(tl.loc('AddingAuthRegistry', registry.url));
            util.appendToNpmrc(npmrc, `${registry.auth}\n`);
        }
        let npm = new npmtoolrunner_1.NpmToolRunner(workingDir, npmrc, overrideNpmrc);
        npm.line(command || tl.getInput(constants_1.NpmTaskInput.CustomCommand, true));
        npm.execSync();
        tl.rmRF(npmrc);
        tl.rmRF(util.getTempPath());
    });
}
exports.run = run;
function getCustomRegistries() {
    return __awaiter(this, void 0, void 0, function* () {
        let workingDir = tl.getInput(constants_1.NpmTaskInput.WorkingDir) || process.cwd();
        let npmRegistries = yield util.getLocalNpmRegistries(workingDir);
        let registryLocation = tl.getInput(constants_1.NpmTaskInput.CustomRegistry);
        switch (registryLocation) {
            case constants_1.RegistryLocation.Feed:
                tl.debug(tl.loc('UseFeed'));
                let feedId = tl.getInput(constants_1.NpmTaskInput.CustomFeed, true);
                npmRegistries.push(yield npmregistry_1.NpmRegistry.FromFeedId(feedId));
                break;
            case constants_1.RegistryLocation.Npmrc:
                tl.debug(tl.loc('UseNpmrc'));
                const endpointIds = tl.getDelimitedInput(constants_1.NpmTaskInput.CustomEndpoint, ',');
                if (endpointIds && endpointIds.length > 0) {
                    yield Promise.all(endpointIds.map((e) => __awaiter(this, void 0, void 0, function* () {
                        npmRegistries.push(yield npmregistry_1.NpmRegistry.FromServiceEndpoint(e, true));
                    })));
                }
                break;
        }
        return npmRegistries;
    });
}
exports.getCustomRegistries = getCustomRegistries;

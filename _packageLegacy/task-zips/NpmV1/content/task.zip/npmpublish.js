"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const constants_1 = require("./constants");
const npmregistry_1 = require("npm-common/npmregistry");
const npmtoolrunner_1 = require("./npmtoolrunner");
const util = require("npm-common/util");
function run(command) {
    return __awaiter(this, void 0, void 0, function* () {
        let workingDir = tl.getInput(constants_1.NpmTaskInput.WorkingDir) || process.cwd();
        let npmrc = util.getTempNpmrcPath();
        let npmRegistry = yield getPublishRegistry();
        tl.debug(tl.loc('PublishRegistry', npmRegistry.url));
        util.appendToNpmrc(npmrc, `registry=${npmRegistry.url}\n`);
        util.appendToNpmrc(npmrc, `${npmRegistry.auth}\n`);
        // For publish, always override their project .npmrc
        let npm = new npmtoolrunner_1.NpmToolRunner(workingDir, npmrc, true);
        npm.line('publish');
        npm.execSync();
        tl.rmRF(npmrc);
        tl.rmRF(util.getTempPath());
    });
}
exports.run = run;
function getPublishRegistry() {
    return __awaiter(this, void 0, void 0, function* () {
        let npmRegistry;
        let registryLocation = tl.getInput(constants_1.NpmTaskInput.PublishRegistry);
        switch (registryLocation) {
            case constants_1.RegistryLocation.Feed:
                tl.debug(tl.loc('PublishFeed'));
                let feedId = tl.getInput(constants_1.NpmTaskInput.PublishFeed, true);
                npmRegistry = yield npmregistry_1.NpmRegistry.FromFeedId(feedId);
                break;
            case constants_1.RegistryLocation.External:
                tl.debug(tl.loc('PublishExternal'));
                let endpointId = tl.getInput(constants_1.NpmTaskInput.PublishEndpoint, true);
                npmRegistry = yield npmregistry_1.NpmRegistry.FromServiceEndpoint(endpointId);
                break;
        }
        return npmRegistry;
    });
}
exports.getPublishRegistry = getPublishRegistry;

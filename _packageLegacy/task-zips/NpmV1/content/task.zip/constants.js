"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class NpmCommand {
}
NpmCommand.Install = 'install';
NpmCommand.Publish = 'publish';
NpmCommand.Custom = 'custom';
exports.NpmCommand = NpmCommand;
class RegistryLocation {
}
RegistryLocation.Npmrc = 'useNpmrc';
RegistryLocation.Feed = 'useFeed';
RegistryLocation.External = 'useExternalRegistry';
exports.RegistryLocation = RegistryLocation;
class NpmTaskInput {
}
NpmTaskInput.Command = 'command';
NpmTaskInput.WorkingDir = 'workingDir';
NpmTaskInput.CustomCommand = 'customCommand';
NpmTaskInput.Verbose = 'verbose';
NpmTaskInput.CustomRegistry = 'customRegistry';
NpmTaskInput.CustomFeed = 'customFeed';
NpmTaskInput.CustomEndpoint = 'customEndpoint';
NpmTaskInput.PublishRegistry = 'publishRegistry';
NpmTaskInput.PublishFeed = 'publishFeed';
NpmTaskInput.PublishEndpoint = 'publishEndpoint';
exports.NpmTaskInput = NpmTaskInput;

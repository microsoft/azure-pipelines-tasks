"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const fs = require("fs");
const toolLib = require("vsts-task-tool-lib/tool");
const utils = require("./utils");
const os = require("os");
const util = require("util");
const uuidV4 = require('uuid/v4');
const downloadutility = require("utility-common/downloadutility");
const helmToolName = "helm";
const helmLatestReleaseUrl = "https://api.github.com/repos/kubernetes/helm/releases/latest";
const stableHelmVersion = "v2.8.2";
function getHelmVersion() {
    return __awaiter(this, void 0, void 0, function* () {
        var checkLatestHelmVersion = tl.getBoolInput('checkLatestHelmVersion', false);
        if (checkLatestHelmVersion) {
            return yield getStableHelmVersion();
        }
        return utils.sanitizeVersionString(tl.getInput("helmVersion", true));
    });
}
exports.getHelmVersion = getHelmVersion;
function downloadHelm(version) {
    return __awaiter(this, void 0, void 0, function* () {
        var cachedToolpath = toolLib.findLocalTool(helmToolName, version);
        if (!cachedToolpath) {
            try {
                var helmDownloadPath = yield toolLib.downloadTool(getHelmDownloadURL(version), helmToolName + "-" + version + "-" + uuidV4() + ".zip");
            }
            catch (exception) {
                throw new Error(tl.loc("HelmDownloadFailed", getHelmDownloadURL(version), exception));
            }
            var unzipedHelmPath = yield toolLib.extractZip(helmDownloadPath);
            cachedToolpath = yield toolLib.cacheDir(unzipedHelmPath, helmToolName, version);
        }
        var helmpath = findHelm(cachedToolpath);
        if (!helmpath) {
            throw new Error(tl.loc("HelmNotFoundInFolder", cachedToolpath));
        }
        fs.chmod(helmpath, "777");
        return helmpath;
    });
}
exports.downloadHelm = downloadHelm;
function findHelm(rootFolder) {
    var helmPath = path.join(rootFolder, "*", helmToolName + getExecutableExtention());
    var allPaths = tl.find(rootFolder);
    var matchingResultsFiles = tl.match(allPaths, helmPath, rootFolder);
    return matchingResultsFiles[0];
}
function getHelmDownloadURL(version) {
    switch (os.type()) {
        case 'Linux':
            return util.format("https://storage.googleapis.com/kubernetes-helm/helm-%s-linux-amd64.zip", version);
        case 'Darwin':
            return util.format("https://storage.googleapis.com/kubernetes-helm/helm-%s-darwin-amd64.zip", version);
        default:
        case 'Windows_NT':
            return util.format("https://storage.googleapis.com/kubernetes-helm/helm-%s-windows-amd64.zip", version);
    }
}
function getStableHelmVersion() {
    return __awaiter(this, void 0, void 0, function* () {
        var downloadPath = path.join(getTempDirectory(), uuidV4() + ".json");
        var options = {
            hostname: 'api.github.com',
            port: 443,
            path: '/repos/kubernetes/helm/releases/latest',
            method: 'GET',
            secureProtocol: "TLSv1_2_method",
            headers: {
                'User-Agent': 'vsts'
            }
        };
        try {
            yield downloadutility.download(options, downloadPath, true, true);
            var version = yield getReleaseVersion(downloadPath);
            return version;
        }
        catch (error) {
            tl.warning(tl.loc("HelmLatestNotKnown", helmLatestReleaseUrl, error, stableHelmVersion));
        }
        return stableHelmVersion;
    });
}
function getExecutableExtention() {
    if (os.type().match(/^Win/)) {
        return ".exe";
    }
    return "";
}
function getTempDirectory() {
    return tl.getVariable('agent.tempDirectory') || os.tmpdir();
}
function getReleaseVersion(jsonFilePath) {
    return new Promise(function (fulfill, reject) {
        fs.readFile(jsonFilePath, { encoding: 'utf8' }, function (err, data) {
            if (err) {
                reject(err);
            }
            var latestVersionInfo = JSON.parse(data);
            fulfill(latestVersionInfo.tag_name);
        });
    });
}

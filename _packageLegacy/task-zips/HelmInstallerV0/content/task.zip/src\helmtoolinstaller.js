"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const toolLib = require("vsts-task-tool-lib/tool");
const kubectlinstaller = require("./kubectlinstaller");
const helminstaller = require("./helminstaller");
tl.setResourcePath(path.join(__dirname, '..', 'task.json'));
function configureKubectl() {
    return __awaiter(this, void 0, void 0, function* () {
        var version = yield kubectlinstaller.getKuberctlVersion();
        var kubectlPath = yield kubectlinstaller.downloadKubectl(version);
        // prepend the tools path. instructs the agent to prepend for future tasks
        if (!process.env['PATH'].startsWith(path.dirname(kubectlPath))) {
            toolLib.prependPath(path.dirname(kubectlPath));
        }
    });
}
function configureHelm() {
    return __awaiter(this, void 0, void 0, function* () {
        var version = yield helminstaller.getHelmVersion();
        var helmPath = yield helminstaller.downloadHelm(version);
        // prepend the tools path. instructs the agent to prepend for future tasks
        if (!process.env['PATH'].startsWith(path.dirname(helmPath))) {
            toolLib.prependPath(path.dirname(helmPath));
        }
    });
}
configureHelm().then(() => {
    if (tl.getBoolInput("installKubeCtl", true)) {
        return configureKubectl();
    }
}).then(() => {
    tl.setResult(tl.TaskResult.Succeeded, "");
}, (reason) => {
    tl.setResult(tl.TaskResult.Failed, reason);
}).catch((error) => {
    tl.setResult(tl.TaskResult.Failed, error);
});

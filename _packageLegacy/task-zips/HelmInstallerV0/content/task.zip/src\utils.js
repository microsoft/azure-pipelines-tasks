"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const toolLib = require("vsts-task-tool-lib/tool");
const tl = require("vsts-task-lib/task");
// handle user input scenerios
function sanitizeVersionString(inputVersion) {
    var version = toolLib.cleanVersion(inputVersion);
    if (!version) {
        throw new Error(tl.loc("NotAValidSemverVersion"));
    }
    return "v" + version;
}
exports.sanitizeVersionString = sanitizeVersionString;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const ngToolRunner = require("nuget-task-common/NuGetToolRunner");
const nutil = require("nuget-task-common/Utility");
const tl = require("vsts-task-lib/task");
// Remove once task lib 2.0.4 releases
global['_vsts_task_lib_loaded'] = true;
const path = require("path");
const auth = require("nuget-task-common/Authentication");
const locationHelpers = require("nuget-task-common/LocationHelpers");
const nuGetGetter = require("nuget-task-common/NuGetToolGetter");
const peParser = require("nuget-task-common/pe-parser/index");
class NuGetExecutionOptions {
    constructor(nuGetPath, environment, command, args) {
        this.nuGetPath = nuGetPath;
        this.environment = environment;
        this.command = command;
        this.args = args;
    }
}
function main() {
    return __awaiter(this, void 0, void 0, function* () {
        tl.setResourcePath(path.join(__dirname, "task.json"));
        let buildIdentityDisplayName = null;
        let buildIdentityAccount = null;
        let command = tl.getInput("command", true);
        let args = tl.getInput("arguments", false);
        // Getting NuGet
        tl.debug('Getting NuGet');
        let nuGetPath = undefined;
        try {
            nuGetPath = process.env[nuGetGetter.NUGET_EXE_TOOL_PATH_ENV_VAR];
            if (!nuGetPath) {
                nuGetPath = yield nuGetGetter.getNuGet("4.0.0");
            }
        }
        catch (error) {
            tl.setResult(tl.TaskResult.Failed, error.message);
            return;
        }
        const version = yield peParser.getFileVersionInfoAsync(nuGetPath);
        if (version.productVersion.a < 3 || (version.productVersion.a <= 3 && version.productVersion.b < 5)) {
            tl.setResult(tl.TaskResult.Failed, tl.loc("Info_NuGetSupportedAfter3_5", version.strings.ProductVersion));
            return;
        }
        try {
            nutil.setConsoleCodePage();
            let credProviderPath = nutil.locateCredentialProvider();
            // Clauses ordered in this way to avoid short-circuit evaluation, so the debug info printed by the functions
            // is unconditionally displayed
            const quirks = yield ngToolRunner.getNuGetQuirksAsync(nuGetPath);
            const useCredProvider = ngToolRunner.isCredentialProviderEnabled(quirks) && credProviderPath;
            // useCredConfig not placed here: This task will only support NuGet versions >= 3.5.0 which support credProvider both hosted and OnPrem
            let accessToken = auth.getSystemAccessToken();
            let serviceUri = tl.getEndpointUrl("SYSTEMVSSCONNECTION", false);
            let urlPrefixes = yield locationHelpers.assumeNuGetUriPrefixes(serviceUri);
            tl.debug(`Discovered URL prefixes: ${urlPrefixes}`);
            // Note to readers: This variable will be going away once we have a fix for the location service for
            // customers behind proxies
            let testPrefixes = tl.getVariable("NuGetTasks.ExtraUrlPrefixesForTesting");
            if (testPrefixes) {
                urlPrefixes = urlPrefixes.concat(testPrefixes.split(";"));
                tl.debug(`All URL prefixes: ${urlPrefixes}`);
            }
            const authInfo = new auth.NuGetAuthInfo(urlPrefixes, accessToken);
            let environmentSettings = {
                authInfo: authInfo,
                credProviderFolder: useCredProvider ? path.dirname(credProviderPath) : null,
                extensionsDisabled: true
            };
            let executionOptions = new NuGetExecutionOptions(nuGetPath, environmentSettings, command, args);
            yield runNuGetAsync(executionOptions);
        }
        catch (err) {
            tl.error(err);
            if (buildIdentityDisplayName || buildIdentityAccount) {
                tl.warning(tl.loc("BuildIdentityPermissionsHint", buildIdentityDisplayName, buildIdentityAccount));
            }
            tl.setResult(tl.TaskResult.Failed, "");
        }
    });
}
main();
function runNuGetAsync(executionOptions) {
    let nugetTool = ngToolRunner.createNuGetToolRunner(executionOptions.nuGetPath, executionOptions.environment);
    nugetTool.arg(executionOptions.command);
    nugetTool.arg("-NonInteractive");
    if (executionOptions.args) {
        nugetTool.line(executionOptions.args);
    }
    return nugetTool.exec();
}

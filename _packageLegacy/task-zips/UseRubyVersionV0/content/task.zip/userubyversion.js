"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const os = require("os");
const path = require("path");
const task = require("vsts-task-lib/task");
const tool = require("vsts-task-tool-lib/tool");
var Platform;
(function (Platform) {
    Platform[Platform["Windows"] = 0] = "Windows";
    Platform[Platform["MacOS"] = 1] = "MacOS";
    Platform[Platform["Linux"] = 2] = "Linux";
})(Platform = exports.Platform || (exports.Platform = {}));
function getPlatform() {
    switch (process.platform) {
        case 'win32': return Platform.Windows;
        case 'darwin': return Platform.MacOS;
        case 'linux': return Platform.Linux;
        default: throw Error(task.loc('PlatformNotRecognized'));
    }
}
exports.getPlatform = getPlatform;
function useRubyVersion(parameters, platform) {
    return __awaiter(this, void 0, void 0, function* () {
        const toolName = 'Ruby';
        const installDir = tool.findLocalTool(toolName, parameters.versionSpec);
        if (!installDir) {
            // Fail and list available versions
            throw new Error([
                task.loc('VersionNotFound', parameters.versionSpec),
                task.loc('ListAvailableVersions'),
                tool.findLocalToolVersions('Ruby')
            ].join(os.EOL));
        }
        const toolPath = path.join(installDir, 'bin');
        if (platform !== Platform.Windows) {
            // replace the default
            const dest = '/usr/bin/ruby';
            if (fs.existsSync(dest)) {
                task.debug('removing ' + dest);
                fs.unlinkSync(dest);
            }
            fs.symlinkSync(path.join(toolPath, 'ruby'), dest);
        }
        task.setVariable('rubyLocation', toolPath);
        if (parameters.addToPath) {
            tool.prependPath(toolPath);
        }
    });
}
exports.useRubyVersion = useRubyVersion;

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const msRestAzure = require("azure-arm-rest/azure-arm-common");
const armStorage = require("azure-arm-rest/azure-arm-storage");
const BlobService = require("azure-blobstorage-artifactProvider/blobservice");
class AzureStorageArtifactDownloader {
    constructor(connectedService, azureStorageAccountName, containerName, commonVirtualPath) {
        this.connectedService = connectedService;
        this.azureStorageAccountName = azureStorageAccountName;
        this.containerName = containerName;
        this.commonVirtualPath = commonVirtualPath;
    }
    downloadArtifacts(downloadToPath, fileType) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(tl.loc('DownloadFromAzureBlobStorage', this.containerName));
            const storageAccount = yield this._getStorageAccountDetails();
            const blobService = new BlobService.BlobService(storageAccount.name, storageAccount.primaryAccessKey);
            yield blobService.downloadBlobs(downloadToPath, this.containerName, this.commonVirtualPath, fileType || "**");
        });
    }
    _getStorageAccountDetails() {
        return __awaiter(this, void 0, void 0, function* () {
            tl.debug("Getting storage account details for " + this.azureStorageAccountName);
            const subscriptionId = tl.getEndpointDataParameter(this.connectedService, "subscriptionId", false);
            const credentials = this._getARMCredentials();
            const storageArmClient = new armStorage.StorageManagementClient(credentials, subscriptionId);
            const storageAccount = yield this._getStorageAccount(storageArmClient);
            const storageAccountResourceGroupName = armStorage.StorageAccounts.getResourceGroupNameFromUri(storageAccount.id);
            tl.debug("Listing storage access keys...");
            const accessKeys = yield storageArmClient.storageAccounts.listKeys(storageAccountResourceGroupName, this.azureStorageAccountName, null, storageAccount.type);
            return {
                name: this.azureStorageAccountName,
                resourceGroupName: storageAccountResourceGroupName,
                primaryAccessKey: accessKeys[0]
            };
        });
    }
    _getStorageAccount(storageArmClient) {
        return __awaiter(this, void 0, void 0, function* () {
            const storageAccounts = yield storageArmClient.storageAccounts.listClassicAndRMAccounts(null);
            const index = storageAccounts.findIndex(account => account.name.toLowerCase() == this.azureStorageAccountName.toLowerCase());
            if (index < 0) {
                throw new Error(tl.loc("StorageAccountDoesNotExist", this.azureStorageAccountName));
            }
            return storageAccounts[index];
        });
    }
    _getARMCredentials() {
        const servicePrincipalId = tl.getEndpointAuthorizationParameter(this.connectedService, "serviceprincipalid", false);
        const servicePrincipalKey = tl.getEndpointAuthorizationParameter(this.connectedService, "serviceprincipalkey", false);
        const tenantId = tl.getEndpointAuthorizationParameter(this.connectedService, "tenantid", false);
        const armUrl = tl.getEndpointUrl(this.connectedService, true);
        let envAuthorityUrl = tl.getEndpointDataParameter(this.connectedService, 'environmentAuthorityUrl', true);
        envAuthorityUrl = (envAuthorityUrl != null) ? envAuthorityUrl : "https://login.windows.net/";
        let activeDirectoryResourceId = tl.getEndpointDataParameter(this.connectedService, 'activeDirectoryServiceEndpointResourceId', false);
        activeDirectoryResourceId = (activeDirectoryResourceId != null) ? activeDirectoryResourceId : armUrl;
        const credentials = new msRestAzure.ApplicationTokenCredentials(servicePrincipalId, tenantId, servicePrincipalKey, armUrl, envAuthorityUrl, activeDirectoryResourceId, false);
        return credentials;
    }
}
exports.AzureStorageArtifactDownloader = AzureStorageArtifactDownloader;

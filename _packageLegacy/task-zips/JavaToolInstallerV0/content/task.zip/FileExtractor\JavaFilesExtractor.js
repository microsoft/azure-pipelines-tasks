"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const taskLib = require("vsts-task-lib/task");
class JavaFilesExtractor {
    constructor() {
        this.winSevenZipLocation = path.join(__dirname, '7zip/7z.exe');
        this.win = taskLib.osType().match(/^Win/);
        taskLib.debug('win: ' + this.win);
    }
    getSevenZipLocation() {
        if (this.win) {
            return this.winSevenZipLocation;
        }
        else {
            if (typeof this.xpSevenZipLocation === "undefined") {
                this.xpSevenZipLocation = taskLib.which('7z', true);
            }
            return this.xpSevenZipLocation;
        }
    }
    unzipExtract(file, destinationFolder) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(taskLib.loc('UnzipExtractFile', file));
            if (process.platform === 'win32') {
                // build the powershell command
                const escapedFile = file.replace(/'/g, "''").replace(/"|\n|\r/g, ''); // double-up single quotes, remove double quotes and newlines
                const escapedDest = destinationFolder.replace(/'/g, "''").replace(/"|\n|\r/g, '');
                const command = `$ErrorActionPreference = 'Stop' ; try { Add-Type -AssemblyName System.IO.Compression.FileSystem } catch { } ; [System.IO.Compression.ZipFile]::ExtractToDirectory('${escapedFile}', '${escapedDest}')`;
                // change the console output code page to UTF-8.
                const chcpPath = path.join(process.env.windir, "system32", "chcp.com");
                yield taskLib.exec(chcpPath, '65001');
                // run powershell
                const powershell = taskLib.tool('powershell')
                    .line('-NoLogo -Sta -NoProfile -NonInteractive -ExecutionPolicy Unrestricted -Command')
                    .arg(command);
                yield powershell.exec();
            }
            else {
                const unzip = taskLib.tool('unzip')
                    .arg(file);
                yield unzip.exec({ cwd: destinationFolder });
            }
        });
    }
    sevenZipExtract(file, destinationFolder) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(taskLib.loc('SevenZipExtractFile', file));
            const sevenZip = taskLib.tool(this.getSevenZipLocation());
            sevenZip.arg('x');
            sevenZip.arg('-o' + destinationFolder);
            sevenZip.arg(file);
            const execResult = sevenZip.execSync();
            if (execResult.code != taskLib.TaskResult.Succeeded) {
                taskLib.debug('execResult: ' + JSON.stringify(execResult));
            }
        });
    }
    tarExtract(file, destinationFolder) {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(taskLib.loc('TarExtractFile', file));
            const tr = taskLib.tool('tar');
            tr.arg(['xzC', destinationFolder, '-f', file]);
            tr.exec();
        });
    }
    extractFiles(file, fileEnding) {
        return __awaiter(this, void 0, void 0, function* () {
            const stats = taskLib.stats(file);
            if (!stats) {
                throw new Error(taskLib.loc('ExtractNonExistFile', file));
            }
            else if (stats.isDirectory()) {
                throw new Error(taskLib.loc('ExtractDirFailed', file));
            }
            if (this.win) {
                if ('.tar' === fileEnding) {
                    this.sevenZipExtract(file, this.destinationFolder);
                }
                else if ('.tar.gz' === fileEnding) {
                    // e.g. 'fullFilePath/test.tar.gz' --> 'test.tar.gz'
                    const shortFileName = file.substring(file.lastIndexOf(path.sep) + 1, file.length);
                    // e.g. 'destinationFolder/_test.tar.gz_'
                    const tempFolder = path.normalize(this.destinationFolder + path.sep + '_' + shortFileName + '_');
                    console.log(taskLib.loc('CreateTempDir', tempFolder, file));
                    // 0 create temp folder
                    taskLib.mkdirP(tempFolder);
                    // 1 extract compressed tar
                    this.sevenZipExtract(file, tempFolder);
                    console.log(taskLib.loc('TempDir', tempFolder));
                    const tempTar = tempFolder + path.sep + taskLib.ls('-A', [tempFolder])[0]; // should be only one
                    console.log(taskLib.loc('DecompressedTempTar', file, tempTar));
                    // 2 expand extracted tar
                    this.sevenZipExtract(tempTar, this.destinationFolder);
                    // 3 cleanup temp folder
                    console.log(taskLib.loc('RemoveTempDir', tempFolder));
                    taskLib.rmRF(tempFolder);
                }
                else if ('.zip' === fileEnding) {
                    yield this.unzipExtract(file, this.destinationFolder);
                }
                else {
                    this.sevenZipExtract(file, this.destinationFolder);
                }
            }
            else {
                if ('.tar' === fileEnding || '.tar.gz' === fileEnding) {
                    this.tarExtract(file, this.destinationFolder);
                }
                else if ('.zip' === fileEnding) {
                    this.unzipExtract(file, this.destinationFolder);
                }
                else {
                    this.sevenZipExtract(file, this.destinationFolder);
                }
            }
        });
    }
    // This method recursively finds all .pack files under fsPath and unpacks them with the unpack200 tool
    unpackJars(fsPath, javaBinPath) {
        if (fs.existsSync(fsPath)) {
            if (fs.lstatSync(fsPath).isDirectory()) {
                let self = this;
                fs.readdirSync(fsPath).forEach(function (file, index) {
                    const curPath = path.join(fsPath, file);
                    self.unpackJars(curPath, javaBinPath);
                });
            }
            else if (path.extname(fsPath).toLowerCase() === '.pack') {
                // Unpack the pack file synchonously
                const p = path.parse(fsPath);
                const toolName = process.platform.match(/^win/i) ? 'unpack200.exe' : 'unpack200';
                const args = process.platform.match(/^win/i) ? '-r -v -l ""' : '';
                const name = path.join(p.dir, p.name);
                taskLib.execSync(path.join(javaBinPath, toolName), `${args} "${name}.pack" "${name}.jar"`);
            }
        }
    }
    unzipJavaDownload(repoRoot, fileEnding, extractLocation) {
        return __awaiter(this, void 0, void 0, function* () {
            this.destinationFolder = extractLocation;
            let initialDirectoriesList;
            let finalDirectoriesList;
            let jdkDirectory;
            // Create the destination folder if it doesn't exist
            if (!taskLib.exist(this.destinationFolder)) {
                console.log(taskLib.loc('CreateDestDir', this.destinationFolder));
                taskLib.mkdirP(this.destinationFolder);
            }
            initialDirectoriesList = taskLib.find(this.destinationFolder).filter(x => taskLib.stats(x).isDirectory());
            const jdkFile = path.normalize(repoRoot);
            const stats = taskLib.stats(jdkFile);
            if (stats.isFile()) {
                yield this.extractFiles(jdkFile, fileEnding);
                finalDirectoriesList = taskLib.find(this.destinationFolder).filter(x => taskLib.stats(x).isDirectory());
                taskLib.setResult(taskLib.TaskResult.Succeeded, taskLib.loc('SucceedMsg'));
                jdkDirectory = finalDirectoriesList.filter(dir => initialDirectoriesList.indexOf(dir) < 0)[0];
                this.unpackJars(jdkDirectory, path.join(jdkDirectory, 'bin'));
                return jdkDirectory;
            }
        });
    }
}
exports.JavaFilesExtractor = JavaFilesExtractor;

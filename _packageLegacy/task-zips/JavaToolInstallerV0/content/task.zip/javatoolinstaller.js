"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const taskLib = require("vsts-task-lib/task");
const toolLib = require("vsts-task-tool-lib/tool");
const AzureStorageArtifactDownloader_1 = require("./AzureStorageArtifacts/AzureStorageArtifactDownloader");
const JavaFilesExtractor_1 = require("./FileExtractor/JavaFilesExtractor");
taskLib.setResourcePath(path.join(__dirname, 'task.json'));
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            let versionSpec = taskLib.getInput('versionSpec', true);
            yield getJava(versionSpec);
        }
        catch (error) {
            taskLib.error(error.message);
            taskLib.setResult(taskLib.TaskResult.Failed, error.message);
        }
    });
}
function getJava(versionSpec) {
    return __awaiter(this, void 0, void 0, function* () {
        const fromAzure = ('AzureStorage' == taskLib.getInput('jdkSourceOption', true));
        const extractLocation = taskLib.getPathInput('jdkDestinationDirectory', true);
        const cleanDestinationDirectory = taskLib.getBoolInput('cleanDestinationDirectory', false);
        let compressedFileExtension;
        let jdkDirectory;
        toolLib.debug('Trying to get tool from local cache first');
        const localVersions = toolLib.findLocalToolVersions('Java');
        const version = toolLib.evaluateVersions(localVersions, versionSpec);
        // Clean the destination folder before downloading and extracting?
        if (cleanDestinationDirectory && taskLib.exist(extractLocation) && taskLib.stats(extractLocation).isDirectory) {
            console.log(taskLib.loc('CleanDestDir', extractLocation));
            // delete the contents of the destination directory but leave the directory in place
            fs.readdirSync(extractLocation)
                .forEach((item) => {
                const itemPath = path.join(extractLocation, item);
                taskLib.rmRF(itemPath);
            });
        }
        if (version) {
            console.log(taskLib.loc('Info_ResolvedToolFromCache', version));
        }
        else if (fromAzure) {
            console.log(taskLib.loc('RetrievingJdkFromAzure'));
            const fileNameAndPath = taskLib.getInput('azureCommonVirtualFile', false);
            compressedFileExtension = getFileEnding(fileNameAndPath);
            const azureDownloader = new AzureStorageArtifactDownloader_1.AzureStorageArtifactDownloader(taskLib.getInput('azureResourceManagerEndpoint', true), taskLib.getInput('azureStorageAccountName', true), taskLib.getInput('azureContainerName', true), "");
            yield azureDownloader.downloadArtifacts(extractLocation, '*' + fileNameAndPath);
            yield sleepFor(250); //Wait for the file to be released before extracting it.
            const extractSource = buildFilePath(extractLocation, compressedFileExtension, fileNameAndPath);
            const javaFilesExtractor = new JavaFilesExtractor_1.JavaFilesExtractor();
            jdkDirectory = yield javaFilesExtractor.unzipJavaDownload(extractSource, compressedFileExtension, extractLocation);
        }
        else {
            console.log(taskLib.loc('RetrievingJdkFromLocalPath'));
            compressedFileExtension = getFileEnding(taskLib.getInput('jdkFile', true));
            const javaFilesExtractor = new JavaFilesExtractor_1.JavaFilesExtractor();
            jdkDirectory = yield javaFilesExtractor.unzipJavaDownload(taskLib.getInput('jdkFile', true), compressedFileExtension, extractLocation);
        }
        let extendedJavaHome = 'JAVA_HOME_' + versionSpec + '_' + taskLib.getInput('jdkArchitectureOption', true);
        console.log(taskLib.loc('SetJavaHome', jdkDirectory));
        console.log(taskLib.loc('SetExtendedJavaHome', extendedJavaHome, jdkDirectory));
        taskLib.setVariable('JAVA_HOME', jdkDirectory);
        taskLib.setVariable(extendedJavaHome, jdkDirectory);
    });
}
function sleepFor(sleepDurationInMillisecondsSeconds) {
    return new Promise((resolve, reeject) => {
        setTimeout(resolve, sleepDurationInMillisecondsSeconds);
    });
}
function buildFilePath(localPathRoot, fileEnding, fileNameAndPath) {
    const fileName = fileNameAndPath.split(/[\\\/]/).pop();
    const extractSource = path.join(localPathRoot, fileName);
    return extractSource;
}
function getFileEnding(file) {
    let fileEnding = '';
    if (file.endsWith('.tar')) {
        fileEnding = '.tar';
    }
    else if (file.endsWith('.tar.gz')) {
        fileEnding = '.tar.gz';
    }
    else if (file.endsWith('.zip')) {
        fileEnding = '.zip';
    }
    else if (file.endsWith('.7z')) {
        fileEnding = '.7z';
    }
    else {
        throw new Error(taskLib.loc('UnsupportedFileExtension'));
    }
    return fileEnding;
}
run();

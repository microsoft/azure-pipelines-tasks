"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const stream = require('stream');
const tl = require('vsts-task-lib/task');
const Q = require('q');
var request = require('request');
const job = require('./job');
const url = require('url');
function getFullErrorMessage(httpResponse, message) {
    var fullMessage = message +
        '\nHttpResponse.statusCode=' + httpResponse.statusCode +
        '\nHttpResponse.statusMessage=' + httpResponse.statusMessage +
        '\nHttpResponse=\n' + JSON.stringify(httpResponse);
    return fullMessage;
}
exports.getFullErrorMessage = getFullErrorMessage;
function failReturnCode(httpResponse, message) {
    var fullMessage = message +
        '\nHttpResponse.statusCode=' + httpResponse.statusCode +
        '\nHttpResponse.statusMessage=' + httpResponse.statusMessage +
        '\nHttpResponse=\n' + JSON.stringify(httpResponse);
    fail(fullMessage);
}
exports.failReturnCode = failReturnCode;
function handleConnectionResetError(err) {
    if (err.code == 'ECONNRESET') {
        tl.debug(err);
    }
    else {
        fail(err);
    }
}
exports.handleConnectionResetError = handleConnectionResetError;
function fail(message) {
    throw new FailTaskError(message);
}
exports.fail = fail;
class FailTaskError extends Error {
}
exports.FailTaskError = FailTaskError;
function convertJobName(jobName) {
    return '/job/' + jobName.replace('/', '/job/');
}
exports.convertJobName = convertJobName;
function addUrlSegment(baseUrl, segment) {
    var resultUrl = null;
    if (baseUrl.endsWith('/') && segment.startsWith('/')) {
        resultUrl = baseUrl + segment.slice(1);
    }
    else if (baseUrl.endsWith('/') || segment.startsWith('/')) {
        resultUrl = baseUrl + segment;
    }
    else {
        resultUrl = baseUrl + '/' + segment;
    }
    return resultUrl;
}
exports.addUrlSegment = addUrlSegment;
function isPipelineJob(job, taskOptions) {
    let deferred = Q.defer();
    let wfapiUrl = `${job.taskUrl}/wfapi`;
    request.get({ url: wfapiUrl, strictSSL: taskOptions.strictSSL }, (err, response, body) => {
        if (response.statusCode === 200) {
            deferred.resolve(true);
        }
        else {
            deferred.resolve(false);
        }
    });
    return deferred.promise;
}
exports.isPipelineJob = isPipelineJob;
function getPipelineReport(job, taskOptions) {
    let deferred = Q.defer();
    let wfapiUrl = `${job.taskUrl}/${job.executableNumber}/wfapi/describe`;
    request.get({ url: wfapiUrl, strictSSL: taskOptions.strictSSL }, (err, response, body) => {
        if (response.statusCode === 200) {
            deferred.resolve(body);
        }
        else {
            deferred.reject(err);
        }
    });
    return deferred.promise;
}
exports.getPipelineReport = getPipelineReport;
function getUrlAuthority(myUrl) {
    let parsed = url.parse(myUrl);
    let result = '';
    if (parsed.auth) {
        result += parsed.auth;
    }
    else {
        if (parsed.protocol && parsed.host) {
            result = `${parsed.protocol}//${parsed.host}`;
        }
    }
    return result;
}
exports.getUrlAuthority = getUrlAuthority;
function pollCreateRootJob(queueUri, jobQueue, taskOptions) {
    var defer = Q.defer();
    var poll = () => __awaiter(this, void 0, void 0, function* () {
        yield createRootJob(queueUri, jobQueue, taskOptions).then((job) => {
            if (job != null) {
                defer.resolve(job);
            }
            else {
                // no job yet, but no failure either, so keep trying
                setTimeout(poll, taskOptions.pollIntervalMillis);
            }
        }).fail((err) => {
            defer.reject(err);
        });
    });
    poll();
    return defer.promise;
}
exports.pollCreateRootJob = pollCreateRootJob;
function createRootJob(queueUri, jobQueue, taskOptions) {
    var defer = Q.defer();
    tl.debug('createRootJob(): ' + queueUri);
    request.get({ url: queueUri, strictSSL: taskOptions.strictSSL }, function requestCallback(err, httpResponse, body) {
        tl.debug('createRootJob().requestCallback()');
        if (err) {
            if (err.code == 'ECONNRESET') {
                tl.debug(err);
                defer.resolve(null);
            }
            else {
                defer.reject(err);
            }
        }
        else if (httpResponse.statusCode != 200) {
            defer.reject(getFullErrorMessage(httpResponse, 'Job progress tracking failed to read job queue'));
        }
        else {
            var parsedBody = JSON.parse(body);
            tl.debug("parsedBody for: " + queueUri + ": " + JSON.stringify(parsedBody));
            // canceled is spelled wrong in the body with 2 Ls (checking correct spelling also in case they fix it)
            if (parsedBody.cancelled || parsedBody.canceled) {
                defer.reject('Jenkins job canceled.');
            }
            else {
                var executable = parsedBody.executable;
                if (!executable) {
                    // job has not actually been queued yet
                    defer.resolve(null);
                }
                else {
                    var rootJob = new job.Job(jobQueue, null, parsedBody.task.url, parsedBody.executable.url, parsedBody.executable.number, parsedBody.task.name);
                    defer.resolve(rootJob);
                }
            }
        }
    }).auth(taskOptions.username, taskOptions.password, true);
    return defer.promise;
}
function pollSubmitJob(taskOptions) {
    var defer = Q.defer();
    var poll = () => __awaiter(this, void 0, void 0, function* () {
        yield getCrumb(taskOptions).then((crumb) => __awaiter(this, void 0, void 0, function* () {
            if (crumb != null) {
                yield submitJob(taskOptions).then((queueUri) => {
                    if (queueUri != null) {
                        defer.resolve(queueUri);
                    }
                    else {
                        // no queueUri yet, but no failure either, so keep trying
                        setTimeout(poll, taskOptions.pollIntervalMillis);
                    }
                }).fail((err) => {
                    defer.reject(err);
                });
            }
            else {
                // no crumb yet, but no failure either, so keep trying
                setTimeout(poll, taskOptions.pollIntervalMillis);
            }
        })).fail((err) => {
            defer.reject(err);
        });
    });
    poll();
    return defer.promise;
}
exports.pollSubmitJob = pollSubmitJob;
function submitJob(taskOptions) {
    var defer = Q.defer();
    tl.debug('submitJob(): ' + JSON.stringify(taskOptions));
    function addCrumb(json) {
        if (taskOptions.crumb && taskOptions.crumb != taskOptions.NO_CRUMB) {
            json.headers = {};
            let splitIndex = taskOptions.crumb.indexOf(':');
            let crumbName = taskOptions.crumb.substr(0, splitIndex);
            let crumbValue = taskOptions.crumb.slice(splitIndex + 1);
            json.headers[crumbName] = crumbValue;
        }
        return json;
    }
    let teamBuildPostData = addCrumb({
        url: taskOptions.teamJobQueueUrl,
        form: {
            json: JSON.stringify({
                "team-build": getTeamParameters(taskOptions),
                "parameter": parseJobParametersTeamBuild(taskOptions.jobParameters)
            })
        },
        strictSSL: taskOptions.strictSSL
    });
    tl.debug('teamBuildPostData = ' + JSON.stringify(teamBuildPostData));
    // first try team-build plugin endpoint, if that fails, then try the default endpoint
    request.post(teamBuildPostData, function teamBuildRequestCallback(err, httpResponse, body) {
        tl.debug('submitJob().teamBuildRequestCallback(teamBuildPostData)');
        if (err) {
            if (err.code == 'ECONNRESET') {
                tl.debug(err);
                defer.resolve(null);
            }
            else {
                defer.reject(err);
            }
        }
        else if (httpResponse.statusCode == 404) {
            console.log('Install the "Team Foundation Server Plug-in" for improved Jenkins integration\n' + taskOptions.teamPluginUrl);
            taskOptions.teamBuildPluginAvailable = false;
            tl.debug('httpResponse: ' + JSON.stringify(httpResponse));
            let jobQueuePostData = addCrumb(taskOptions.parameterizedJob ?
                {
                    url: taskOptions.jobQueueUrl,
                    formData: parseJobParameters(taskOptions.jobParameters),
                    strictSSL: taskOptions.strictSSL
                } :
                {
                    url: taskOptions.jobQueueUrl,
                    strictSSL: taskOptions.strictSSL
                });
            tl.debug('jobQueuePostData = ' + JSON.stringify(jobQueuePostData));
            request.post(jobQueuePostData, function jobQueueRequestCallback(err, httpResponse, body) {
                tl.debug('submitJob().jobQueueRequestCallback(jobQueuePostData)');
                if (err) {
                    if (err.code == 'ECONNRESET') {
                        tl.debug(err);
                        defer.resolve(null);
                    }
                    else {
                        defer.reject(err);
                    }
                }
                else if (httpResponse.statusCode != 201) {
                    defer.reject(getFullErrorMessage(httpResponse, 'Job creation failed.'));
                }
                else {
                    var queueUri = addUrlSegment(httpResponse.headers.location, 'api/json');
                    defer.resolve(queueUri);
                }
            }).auth(taskOptions.username, taskOptions.password, true);
        }
        else if (httpResponse.statusCode != 201) {
            defer.reject(getFullErrorMessage(httpResponse, 'Job creation failed.'));
        }
        else {
            taskOptions.teamBuildPluginAvailable = true;
            let jsonBody = JSON.parse(body);
            let queueUri = addUrlSegment(jsonBody.created, 'api/json');
            defer.resolve(queueUri);
        }
    }).auth(taskOptions.username, taskOptions.password, true);
    return defer.promise;
}
function getCrumb(taskOptions) {
    let defer = Q.defer();
    let crumbRequestUrl = addUrlSegment(taskOptions.serverEndpointUrl, '/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,%22:%22,//crumb)');
    tl.debug('crumbRequestUrl: ' + crumbRequestUrl);
    request.get({ url: crumbRequestUrl, strictSSL: taskOptions.strictSSL }, function (err, httpResponse, body) {
        if (err) {
            if (err.code == 'ECONNRESET') {
                tl.debug(err);
                defer.resolve(null);
            }
            else {
                defer.reject(err);
            }
        }
        else if (httpResponse.statusCode == 404) {
            tl.debug('crumb endpoint not found');
            taskOptions.crumb = taskOptions.NO_CRUMB;
            defer.resolve(taskOptions.NO_CRUMB);
        }
        else if (httpResponse.statusCode != 200) {
            failReturnCode(httpResponse, 'crumb request failed.');
            defer.reject(getFullErrorMessage(httpResponse, 'Crumb request failed.'));
        }
        else {
            taskOptions.crumb = body;
            tl.debug('crumb: ' + taskOptions.crumb);
            defer.resolve(taskOptions.crumb);
        }
    }).auth(taskOptions.username, taskOptions.password, true);
    return defer.promise;
}
class StringWritable extends stream.Writable {
    constructor(options) {
        super(options);
        this.value = "";
    }
    _write(data, encoding, callback) {
        tl.debug(data);
        this.value += data;
        if (callback) {
            callback();
        }
    }
    toString() {
        return this.value;
    }
}
exports.StringWritable = StringWritable;
;
/**
 * Supported parameter types: boolean, string, choice, password
 *
 * - If a parameter is not defined by Jenkins it is fine to pass it anyway
 * - Anything passed to a boolean parameter other than 'true' (case insenstive) becomes false.
 * - Invalid choice parameters result in a 500 response.
 *
 */
function parseJobParameters(jobParameters) {
    var formData = {};
    for (var i = 0; i < jobParameters.length; i++) {
        var paramLine = jobParameters[i].trim();
        var splitIndex = paramLine.indexOf('=');
        if (splitIndex <= 0) {
            throw 'Job parameters should be specified as "parameterName=parameterValue" with one name, value pair per line. Invalid parameter line: ' + jobParameters[i];
        }
        var paramName = paramLine.substr(0, splitIndex).trim();
        var paramValue = paramLine.slice(splitIndex + 1).trim();
        formData[paramName] = paramValue;
    }
    return formData;
}
function parseJobParametersTeamBuild(jobParameters) {
    let formData = parseJobParameters(jobParameters);
    let jsonArray = [];
    for (var paramName in formData) {
        let json = {};
        json['name'] = paramName;
        json['value'] = formData[paramName];
        jsonArray.push(json);
    }
    return jsonArray;
}
function getTeamParameters(taskOptions) {
    var formData = {};
    allTeamBuildVariables.forEach(variableName => {
        let paramValue = tl.getVariable(variableName);
        if (paramValue) {
            formData[variableName] = paramValue;
        }
    });
    // add task specific options
    if (taskOptions.isMultibranchPipelineJob) {
        formData['QueueJobTask.MultibranchPipelineBranch'] = taskOptions.multibranchPipelineBranch;
    }
    return formData;
}
//https://www.visualstudio.com/docs/build/define/variables
var allTeamBuildVariables = [
    //control variables
    'Build.Clean',
    'Build.SyncSources',
    'System.Debug',
    //predefined variables
    'Agent.BuildDirectory',
    'Agent.HomeDirectory',
    'Agent.Id',
    'Agent.MachineName',
    'Agent.Name',
    'Agent.WorkFolder',
    'Build.ArtifactStagingDirectory',
    'Build.BuildId',
    'Build.BuildNumber',
    'Build.BuildUri',
    'Build.BinariesDirectory',
    'Build.DefinitionName',
    'Build.DefinitionVersion',
    'Build.QueuedBy',
    'Build.QueuedById',
    'Build.Repository.Clean',
    'Build.Repository.LocalPath',
    'Build.Repository.Name',
    'Build.Repository.Provider',
    'Build.Repository.Tfvc.Workspace',
    'Build.Repository.Uri',
    'Build.RequestedFor',
    'Build.RequestedForId',
    'Build.SourceBranch',
    'Build.SourceBranchName',
    'Build.SourcesDirectory',
    'Build.SourceVersion',
    'Build.StagingDirectory',
    'Build.Repository.Git.SubmoduleCheckout',
    'Build.SourceTfvcShelveset',
    'Common.TestResultsDirectory',
    //'System.AccessToken', -- holding this one back, Jenkins has it's own access mechamisms to TFS
    'System.CollectionId',
    'System.DefaultWorkingDirectory',
    'System.DefinitionId',
    'System.TeamFoundationCollectionUri',
    'System.TeamProject',
    'System.TeamProjectId',
    'TF_BUILD'
];

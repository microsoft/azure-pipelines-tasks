// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const tl = require('vsts-task-lib/task');
const path = require('path');
const jobqueue = require('./jobqueue');
var JobQueue = jobqueue.JobQueue;
const util = require('./util');
class TaskOptions {
    constructor() {
        this.serverEndpoint = tl.getInput('serverEndpoint', true);
        this.serverEndpointUrl = tl.getEndpointUrl(this.serverEndpoint, false);
        tl.debug('serverEndpointUrl=' + this.serverEndpointUrl);
        this.serverEndpointAuth = tl.getEndpointAuthorization(this.serverEndpoint, false);
        this.username = this.serverEndpointAuth['parameters']['username'];
        this.password = this.serverEndpointAuth['parameters']['password'];
        this.jobName = tl.getInput('jobName', true);
        this.isMultibranchPipelineJob = tl.getBoolInput('isMultibranchJob', false);
        if (this.isMultibranchPipelineJob) {
            this.multibranchPipelineBranch = tl.getInput('multibranchPipelineBranch', true);
        }
        this.captureConsole = tl.getBoolInput('captureConsole', true);
        // capturePipeline is only possible if captureConsole mode is enabled
        this.capturePipeline = this.captureConsole ? tl.getBoolInput('capturePipeline', true) : false;
        this.pollIntervalMillis = 5000; // five seconds is what the Jenkins Web UI uses
        this.parameterizedJob = tl.getBoolInput('parameterizedJob', true);
        // jobParameters are only possible if parameterizedJob is enabled
        this.jobParameters = this.parameterizedJob ? tl.getDelimitedInput('jobParameters', '\n', false) : [];
        this.jobQueueUrl = util.addUrlSegment(this.serverEndpointUrl, util.convertJobName(this.jobName)) + ((this.parameterizedJob) ? '/buildWithParameters?delay=0sec' : '/build?delay=0sec');
        tl.debug('jobQueueUrl=' + this.jobQueueUrl);
        this.teamJobQueueUrl = util.addUrlSegment(this.serverEndpointUrl, '/team-build/build/' + this.jobName + '?delay=0sec');
        tl.debug('teamJobQueueUrl=' + this.teamJobQueueUrl);
        this.teamPluginUrl = util.addUrlSegment(this.serverEndpointUrl, '/pluginManager/available');
        tl.debug('teamPluginUrl=' + this.teamPluginUrl);
        this.teamBuildPluginAvailable = false;
        // 'Build.StagingDirectory' is available during build.
        // It is kept here (different than what is used during release) to maintain
        // compatibility with other tasks relying on Jenkins results being placed in this folder.
        var resultsDirectory = tl.getVariable('Build.StagingDirectory');
        if (!resultsDirectory) {
            // 'System.DefaultWorkingDirectory' is available during build and release
            resultsDirectory = tl.getVariable('System.DefaultWorkingDirectory');
        }
        this.saveResultsTo = path.join(resultsDirectory, 'jenkinsResults');
        this.strictSSL = ("true" !== tl.getEndpointDataParameter(this.serverEndpoint, "acceptUntrustedCerts", true));
        tl.debug('strictSSL=' + this.strictSSL);
        this.NO_CRUMB = 'NO_CRUMB';
        this.crumb = this.NO_CRUMB;
    }
}
exports.TaskOptions = TaskOptions;
function doWork() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            var taskOptions = new TaskOptions();
            var jobQueue = new JobQueue(taskOptions);
            var queueUri = yield util.pollSubmitJob(taskOptions);
            console.log(tl.loc('JenkinsJobQueued'));
            var rootJob = yield util.pollCreateRootJob(queueUri, jobQueue, taskOptions);
            //start the job queue
            jobQueue.start();
        }
        catch (e) {
            tl.debug(e.message);
            tl._writeError(e);
            tl.setResult(tl.TaskResult.Failed, e.message);
        }
    });
}
doWork();

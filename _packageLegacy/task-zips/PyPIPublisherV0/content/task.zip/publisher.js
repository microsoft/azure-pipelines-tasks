var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var tl = require('vsts-task-lib/task');
var os = require('os');
var path = require('path');
var util = require("util");
var workingDirectory = tl.getInput('wd', true);
var serviceEndpointId = tl.getInput('serviceEndpoint', true);
var wheel = tl.getBoolInput('wheel');
var homedir = os.homedir();
var pypircFilePath = path.join(homedir, ".pypirc");
var pythonToolPath = tl.which('python', true);
var error = '';
//Generic service endpoint
var pythonServer = tl.getEndpointUrl(serviceEndpointId, false);
var username = tl.getEndpointAuthorizationParameter(serviceEndpointId, 'username', false);
var password = tl.getEndpointAuthorizationParameter(serviceEndpointId, 'password', false);
//Create .pypirc file
var text = util.format("[distutils] \nindex-servers =\n    pypi \n[pypi] \nrepository=%s \nusername=%s \npassword=%s", pythonServer, username, password);
tl.writeFile(pypircFilePath, text, 'utf8');
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        //PyPI upload
        try {
            tl.cd(workingDirectory);
            yield executePythonTool("-m pip install twine --user");
            yield executePythonTool("setup.py sdist");
            if (wheel) {
                yield executePythonTool("-m pip install wheel --user");
                yield executePythonTool("setup.py bdist_wheel --universal");
            }
            yield executePythonTool("-m twine upload dist/*");
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, error);
        }
        finally {
            //Delete .pypirc file
            tl.rmRF(pypircFilePath);
            tl.setResult(tl.TaskResult.Succeeded);
        }
        ;
    });
}
function executePythonTool(commandToExecute) {
    return __awaiter(this, void 0, void 0, function* () {
        var pythonTool = tl.tool(pythonToolPath);
        pythonTool.on('stderr', function (data) {
            error += (data || '').toString();
        });
        yield pythonTool.line(commandToExecute).exec();
    });
}
run();

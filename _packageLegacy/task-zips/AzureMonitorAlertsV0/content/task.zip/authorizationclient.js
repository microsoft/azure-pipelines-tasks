"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const Q = require("q");
const querystring = require("querystring");
const defaultAuthUrl = "https://login.windows.net/";
class AuthorizationClient {
    constructor(endpoint, httpClient) {
        this._httpClient = httpClient;
        this._endpoint = endpoint;
        let envAuthUrl = (this._endpoint.envAuthUrl) ? (this._endpoint.envAuthUrl) : defaultAuthUrl;
        this._authorityUrl = envAuthUrl + this._endpoint.tenantID + "/oauth2/token/";
    }
    getBearerToken() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this._accessToken) {
                let tokenExpiryTimeInUTCSeconds = parseInt(this._accessToken.expires_on);
                let currentTimeInUTCSeconds = this._getCurrentTimeInUTCSeconds();
                if (tokenExpiryTimeInUTCSeconds > currentTimeInUTCSeconds + 60) {
                    // keeping time window of 60 seconds for fetching new token
                    tl.debug(`Returning authorization token from cache.`);
                    return this._accessToken.access_token;
                }
            }
            tl.debug(`Authorization token not found in cache.`);
            this._accessToken = yield this._refreshAccessToken();
            return this._accessToken.access_token;
        });
    }
    _refreshAccessToken() {
        return __awaiter(this, void 0, void 0, function* () {
            let deferred = Q.defer();
            let requestData = querystring.stringify({
                resource: this._endpoint.activeDirectoryResourceId,
                client_id: this._endpoint.servicePrincipalClientID,
                grant_type: "client_credentials",
                client_secret: this._endpoint.servicePrincipalKey
            });
            let requestHeader = {
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
            };
            tl.debug('Requesting for Auth Token: ' + this._authorityUrl);
            this._httpClient.post(this._authorityUrl, requestData, requestHeader)
                .then((response) => __awaiter(this, void 0, void 0, function* () {
                try {
                    let contents = yield response.readBody();
                    if (response.message.statusCode == 200) {
                        if (!!contents) {
                            deferred.resolve(JSON.parse(contents));
                        }
                    }
                    else {
                        let errorMessage = tl.loc('Couldnotfetchaccesstoken', response.message.statusCode, response.message.statusMessage, contents);
                        if (response.message.statusCode === 401 || response.message.statusCode === 403) {
                            errorMessage += tl.loc("SPNExpiredCheck");
                        }
                        deferred.reject(errorMessage);
                    }
                }
                catch (error) {
                    deferred.reject(error);
                }
            }), (error) => {
                deferred.reject(error);
            });
            return deferred.promise;
        });
    }
    _getCurrentTimeInUTCSeconds() {
        return Math.floor(new Date().getTime() / 1000);
    }
}
exports.AuthorizationClient = AuthorizationClient;

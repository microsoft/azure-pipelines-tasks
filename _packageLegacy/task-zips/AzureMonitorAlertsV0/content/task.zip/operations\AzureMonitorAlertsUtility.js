"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const azure_arm_appinsigths_alerts_1 = require("azure-arm-rest/azure-arm-appinsigths-alerts");
const azure_arm_resource_1 = require("azure-arm-rest/azure-arm-resource");
const Q = require("q");
class AzureMonitorAlertsUtility {
    constructor(azureEndpoint, resourceGroupName, resourceType, resourceName) {
        this._azureEndpoint = azureEndpoint;
        this._resourceGroupName = resourceGroupName;
        this._resourceType = resourceType;
        this._resourceName = resourceName;
    }
    addOrUpdateAlertRules(alertRules, notifyServiceOwners, notifyEmails) {
        return __awaiter(this, void 0, void 0, function* () {
            let resourceId = `/subscriptions/${this._azureEndpoint.subscriptionID}/resourceGroups/${this._resourceGroupName}/providers/${this._resourceType}/${this._resourceName}`;
            let azureMetricAlerts = new azure_arm_appinsigths_alerts_1.AzureMonitorAlerts(this._azureEndpoint, this._resourceGroupName);
            for (let rule of alertRules) {
                let requestBody = yield this._getRequestBodyForAddingAlertRule(azureMetricAlerts, this._resourceGroupName, resourceId, rule, notifyServiceOwners, notifyEmails);
                yield azureMetricAlerts.update(rule.alertName, requestBody);
            }
        });
    }
    _getRequestBodyForAddingAlertRule(azureMetricAlerts, resourceGroupName, resourceUri, rule, notifyServiceOwners, notifyEmails) {
        return __awaiter(this, void 0, void 0, function* () {
            let existingAlertRule;
            let notifyViaEmails = notifyServiceOwners || !!notifyEmails;
            try {
                console.log(tl.loc("AlertRuleCheck", rule.alertName, resourceGroupName));
                existingAlertRule = yield azureMetricAlerts.get(rule.alertName);
                let existingAlertRuleTargetResourceUri = existingAlertRule["properties"] && existingAlertRule["properties"].condition
                    && existingAlertRule["properties"].condition.dataSource ? existingAlertRule["properties"].condition.dataSource.resourceUri : "";
                if (existingAlertRuleTargetResourceUri && existingAlertRuleTargetResourceUri.toLowerCase() !== resourceUri.toLowerCase()) {
                    return Q.reject(tl.loc("AlertRuleTargetResourceIdMismatchError", rule.alertName, existingAlertRuleTargetResourceUri));
                }
                console.log(tl.loc("AlertRuleExists", rule.alertName, resourceGroupName));
            }
            catch (error) {
                if (error.toString().indexOf("404") != -1) {
                    console.log(tl.loc("AlertRuleDoesNotExist", rule.alertName, resourceGroupName));
                }
            }
            let alertRuleResourceLocation = "";
            let alertRuleResourceTags = {};
            let alertRuleActions = [];
            if (existingAlertRule) {
                // if the alert rule already exists, use the location, tags and actions of the existing alert rule
                alertRuleResourceLocation = existingAlertRule.location;
                alertRuleResourceTags = existingAlertRule.tags || {};
                alertRuleActions = existingAlertRule["properties"] && existingAlertRule["properties"].actions || [];
                if (notifyViaEmails) {
                    alertRuleActions = alertRuleActions.filter((action) => {
                        // remove email action which will be updated later
                        if (action["odata.type"]) {
                            return action["odata.type"].toLowerCase() !== "microsoft.azure.management.insights.models.ruleemailaction";
                        }
                        return true;
                    });
                }
            }
            else {
                // For new alert rules, create the alert rule in the same location as the target resource
                let resourceMetadataResponse = yield this.getAzureRmResourceDetails(resourceUri);
                alertRuleResourceLocation = resourceMetadataResponse.location;
            }
            // Add the hidden link resource tag 
            alertRuleResourceTags["hidden-link:" + resourceUri] = "Resource";
            // Add email action
            if (notifyViaEmails) {
                let notifyEmailsList = !!notifyEmails ? notifyEmails.split(";") : [];
                notifyEmailsList.forEach((value, index, array) => {
                    array[index] = value.trim();
                });
                notifyEmailsList = notifyEmailsList.filter((value) => !!value);
                alertRuleActions.push({
                    "odata.type": "Microsoft.Azure.Management.Insights.Models.RuleEmailAction",
                    "sendToServiceOwners": notifyServiceOwners,
                    "customEmails": notifyEmailsList
                });
            }
            return {
                location: alertRuleResourceLocation,
                tags: alertRuleResourceTags,
                properties: {
                    name: rule.alertName,
                    description: `Updated via ${getDeploymentUri()}`,
                    isEnabled: true,
                    condition: {
                        "odata.type": "Microsoft.Azure.Management.Insights.Models.ThresholdRuleCondition",
                        "dataSource": {
                            "odata.type": "Microsoft.Azure.Management.Insights.Models.RuleMetricDataSource",
                            "resourceUri": resourceUri,
                            "metricName": rule.metric.value
                        },
                        "operator": getThresholdConditionForMetricAlertRule(rule.thresholdCondition),
                        "threshold": rule.thresholdValue,
                        "windowSize": getWindowSizeForMetricAlertRule(rule.timePeriod)
                    },
                    actions: alertRuleActions
                }
            };
        });
    }
    getAzureRmResourceDetails(resourceUri) {
        return __awaiter(this, void 0, void 0, function* () {
            let deferred = Q.defer();
            let splittedResourceUri = resourceUri.split("/");
            let resourceGroupName = splittedResourceUri[4];
            let resourceType = splittedResourceUri[6] + "/" + splittedResourceUri[7];
            let resourceName = splittedResourceUri[8];
            tl.debug(`Getting AzureRm resource details - '${resourceName}' in resource group '${resourceGroupName}'`);
            let resources = new azure_arm_resource_1.Resources(this._azureEndpoint);
            let resourceValues = yield resources.getResources(resourceType, resourceName);
            return resourceValues[0];
        });
    }
}
exports.AzureMonitorAlertsUtility = AzureMonitorAlertsUtility;
function getDeploymentUri() {
    let buildUri = tl.getVariable("Build.BuildUri");
    let releaseWebUrl = tl.getVariable("Release.ReleaseWebUrl");
    let collectionUrl = tl.getVariable('System.TeamFoundationCollectionUri');
    let teamProject = tl.getVariable('System.TeamProjectId');
    let buildId = tl.getVariable('build.buildId');
    if (!!releaseWebUrl) {
        return releaseWebUrl;
    }
    if (!!buildUri) {
        return `${collectionUrl}${teamProject}/_build?buildId=${buildId}&_a=summary`;
    }
    return "";
}
exports.getDeploymentUri = getDeploymentUri;
function getWindowSizeForMetricAlertRule(key) {
    let timePeriodMap = {
        "over the last 5 minutes": "PT5M",
        "over the last 10 minutes": "PT10M",
        "over the last 15 minutes": "PT15M",
        "over the last 30 minutes": "PT30M",
        "over the last 45 minutes": "PT45M",
        "over the last hour": "PT1H",
        "over the last 2 hours": "PT2H",
        "over the last 3 hours": "PT3H",
        "over the last 4 hours": "PT4H",
        "over the last 5 hours": "PT5H",
        "over the last 6 hours": "PT6H",
        "over the last 24 hours": "P1D"
    };
    return timePeriodMap[key] || "";
}
exports.getWindowSizeForMetricAlertRule = getWindowSizeForMetricAlertRule;
function getThresholdConditionForMetricAlertRule(operator) {
    let operatorMap = {
        ">": "GreaterThan",
        ">=": "GreaterThanOrEqual",
        "<": "LessThan",
        "<=": "LessThanOrEqual"
    };
    return operatorMap[operator] || "";
}
exports.getThresholdConditionForMetricAlertRule = getThresholdConditionForMetricAlertRule;

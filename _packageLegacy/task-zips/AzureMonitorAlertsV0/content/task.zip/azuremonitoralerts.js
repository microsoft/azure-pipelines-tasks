"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const azure_arm_endpoint_1 = require("azure-arm-rest/azure-arm-endpoint");
const AzureMonitorAlertsUtility_1 = require("./operations/AzureMonitorAlertsUtility");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, "task.json"));
            let connectedServiceName = tl.getInput("ConnectedServiceName", true);
            let resourceGroupName = tl.getInput("ResourceGroupName", true);
            let resourceType = tl.getInput("ResourceType", true);
            let resourceName = tl.getInput("ResourceName", true);
            let alertRules = JSON.parse(tl.getInput("AlertRules", true));
            let notifyServiceOwners = tl.getInput("NotifyServiceOwners") && tl.getInput("NotifyServiceOwners").toLowerCase() === "true" ? true : false;
            let notifyEmails = tl.getInput("NotifyEmails");
            var azureEndpoint = yield new azure_arm_endpoint_1.AzureRMEndpoint(connectedServiceName).getEndpoint();
            let azureMonitorAlertsUtility = new AzureMonitorAlertsUtility_1.AzureMonitorAlertsUtility(azureEndpoint, resourceGroupName, resourceType, resourceName);
            yield azureMonitorAlertsUtility.addOrUpdateAlertRules(alertRules.rules, notifyServiceOwners, notifyEmails);
        }
        catch (error) {
            tl.setResult(tl.TaskResult.Failed, error);
        }
    });
}
run();

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
function run(connection, kubecommand, outputUpdate) {
    var command = connection.createCommand();
    command.on("stdout", output => {
        outputUpdate(output);
    });
    command.arg(kubecommand);
    command.arg(getNameSpace());
    command.arg(getCommandConfigurationFile());
    command.line(getCommandArguments());
    command.arg(getCommandOutputFormat());
    return connection.execCommand(command);
}
exports.run = run;
function getCommandOutputFormat() {
    var args = [];
    var outputFormat = tl.getInput("outputFormat", false);
    if (outputFormat) {
        args[0] = "-o";
        args[1] = outputFormat;
    }
    return args;
}
function getCommandConfigurationFile() {
    var args = [];
    var useConfigurationFile = tl.getBoolInput("useConfigurationFile", false);
    if (useConfigurationFile) {
        var configurationPath = tl.getInput("configuration", true);
        if (configurationPath && tl.exist(configurationPath)) {
            args[0] = "-f";
            args[1] = configurationPath;
        }
        else {
            throw new Error(tl.loc('ConfigurationFileNotFound', configurationPath));
        }
    }
    return args;
}
function getCommandArguments() {
    return tl.getInput("arguments", false);
}
function getNameSpace() {
    var args = [];
    var namespace = tl.getInput("namespace", false);
    if (namespace) {
        args[0] = "-n";
        args[1] = namespace;
    }
    return args;
}
exports.getNameSpace = getNameSpace;

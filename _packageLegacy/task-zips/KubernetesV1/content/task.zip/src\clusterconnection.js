"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const tl = require("vsts-task-lib/task");
const utils = require("./utilities");
const toolLib = require("vsts-task-tool-lib/tool");
class ClusterConnection {
    constructor() {
        this.kubectlPath = tl.which("kubectl", false);
        this.userDir = utils.getNewUserDirPath();
    }
    loadClusterType(connectionType) {
        if (connectionType === "Azure Resource Manager") {
            return require("./clusters/armkubernetescluster");
        }
        else {
            return require("./clusters/generickubernetescluster");
        }
    }
    // get kubeconfig file path
    getKubeConfig() {
        return __awaiter(this, void 0, void 0, function* () {
            var connectionType = tl.getInput("connectionType", true);
            return this.loadClusterType(connectionType).getKubeConfig().then((config) => {
                return config;
            });
        });
    }
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.kubectlPath || !fs.existsSync(this.kubectlPath)) {
                return this.getKubectl().then((kubectlpath) => {
                    this.kubectlPath = kubectlpath;
                    // prepend the tools path. instructs the agent to prepend for future tasks
                    if (!process.env['PATH'].toLowerCase().startsWith(path.dirname(this.kubectlPath.toLowerCase()))) {
                        toolLib.prependPath(path.dirname(this.kubectlPath));
                    }
                });
            }
        });
    }
    createCommand() {
        var command = tl.tool(this.kubectlPath);
        if (this.kubeconfigFile) {
            command.arg("--kubeconfig");
            command.arg(this.kubeconfigFile);
        }
        return command;
    }
    // open kubernetes connection
    open() {
        return __awaiter(this, void 0, void 0, function* () {
            var kubeconfig = yield this.getKubeConfig();
            return this.initialize().then(() => {
                if (kubeconfig != null) {
                    this.kubeconfigFile = path.join(this.userDir, "config");
                    fs.writeFileSync(this.kubeconfigFile, kubeconfig);
                }
            });
        });
    }
    // close kubernetes connection
    close() {
        if (this.kubeconfigFile != null && fs.exists(this.kubeconfigFile)) {
            fs.rmdirSync(this.kubeconfigFile);
        }
    }
    //excute kubernetes command
    execCommand(command, options) {
        var errlines = [];
        command.on("errline", line => {
            errlines.push(line);
        });
        return command.exec(options).fail(error => {
            errlines.forEach(line => tl.error(line));
            throw error;
        });
    }
    getKubectl() {
        return __awaiter(this, void 0, void 0, function* () {
            let versionOrLocation = tl.getInput("versionOrLocation");
            if (versionOrLocation === "location") {
                let pathToKubectl = tl.getPathInput("specifyLocation", true, true);
                fs.chmod(pathToKubectl, "777");
                return pathToKubectl;
            }
            else if (versionOrLocation === "version") {
                tl.debug(tl.loc("DownloadingClient"));
                let versionSpec = tl.getInput("versionSpec");
                let checkLatest = tl.getBoolInput('checkLatest', false);
                var version = yield utils.getKubectlVersion(versionSpec, checkLatest);
                return yield utils.downloadKubectl(version);
            }
        });
    }
}
exports.default = ClusterConnection;

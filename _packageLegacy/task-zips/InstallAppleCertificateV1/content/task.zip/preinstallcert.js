"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const sign = require("ios-signing-common/ios-signing-common");
const secureFilesCommon = require("securefiles-common/securefiles-common");
const tl = require("vsts-task-lib/task");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        let secureFileId;
        let secureFileHelpers;
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // download decrypted contents
            secureFileId = tl.getInput('certSecureFile', true);
            secureFileHelpers = new secureFilesCommon.SecureFileHelpers();
            let certPath = yield secureFileHelpers.downloadSecureFile(secureFileId);
            let certPwd = tl.getInput('certPwd');
            // get the P12 details - SHA1 hash and common name (CN)
            let p12Hash = yield sign.getP12SHA1Hash(certPath, certPwd);
            // give user an option to override the CN as a workaround if we can't parse the certificate
            let p12CN = tl.getInput('certSigningIdentity', false);
            if (!p12CN) {
                p12CN = yield sign.getP12CommonName(certPath, certPwd);
            }
            if (!p12Hash || !p12CN) {
                throw tl.loc('INVALID_P12');
            }
            tl.setTaskVariable('APPLE_CERTIFICATE_SHA1HASH', p12Hash);
            // set the signing identity output variable.
            tl.setVariable('signingIdentity', p12CN);
            // install the certificate in specified keychain, keychain is created if required
            let keychain = tl.getInput('keychain');
            let keychainPwd = tl.getInput('keychainPassword');
            let keychainPath;
            if (keychain === 'temp') {
                keychainPath = sign.getTempKeychainPath();
                if (!keychainPwd) {
                    // generate a keychain password for the temporary keychain since user did not provide one
                    keychainPwd = Math.random().toString(36);
                }
            }
            else if (keychain === 'default') {
                keychainPath = yield sign.getDefaultKeychainPath();
            }
            else if (keychain === 'custom') {
                keychainPath = tl.getInput('customKeychainPath', true);
            }
            tl.setTaskVariable('APPLE_CERTIFICATE_KEYCHAIN', keychainPath);
            yield sign.installCertInTemporaryKeychain(keychainPath, keychainPwd, certPath, certPwd, true);
            // set the keychain output variable.
            tl.setVariable('keychainPath', keychainPath);
            // Set the legacy variables that doesn't use the task's refName, unlike our output variables.
            // If there are multiple InstallAppleCertificate tasks, the last one wins.
            tl.setVariable('APPLE_CERTIFICATE_SIGNING_IDENTITY', p12CN);
            tl.setVariable('APPLE_CERTIFICATE_KEYCHAIN', keychainPath);
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
        finally {
            // delete certificate from temp location after installing
            if (secureFileId && secureFileHelpers) {
                secureFileHelpers.deleteSecureFile(secureFileId);
            }
        }
    });
}
run();

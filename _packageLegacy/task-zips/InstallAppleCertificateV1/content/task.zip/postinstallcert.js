"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const sign = require("ios-signing-common/ios-signing-common");
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            let keychain = tl.getInput('keychain');
            let keychainPath = tl.getTaskVariable('APPLE_CERTIFICATE_KEYCHAIN');
            let deleteCert = tl.getBoolInput('deleteCert');
            let hash = tl.getTaskVariable('APPLE_CERTIFICATE_SHA1HASH');
            if (deleteCert && hash) {
                sign.deleteCert(keychainPath, hash);
            }
            let deleteKeychain = false;
            if (keychain === 'temp') {
                deleteKeychain = true;
            }
            else if (keychain === 'custom') {
                deleteKeychain = tl.getBoolInput('deleteCustomKeychain');
            }
            if (deleteKeychain && keychainPath) {
                yield sign.deleteKeychain(keychainPath);
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err);
        }
    });
}
run();

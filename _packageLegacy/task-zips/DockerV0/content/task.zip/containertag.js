"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const utils = require("./utils");
function dockerTag(connection, sourceImage, targetImage) {
    let command = connection.createCommand();
    command.arg("tag");
    command.arg(sourceImage);
    command.arg(targetImage);
    tl.debug(`Tagging image ${sourceImage} with ${targetImage}.`);
    return connection.execCommand(command);
}
function run(connection) {
    let imageNames = utils.getImageNames();
    let imageMappings = utils.getImageMappings(connection, imageNames);
    let firstMapping = imageMappings.shift();
    let promise = dockerTag(connection, firstMapping.sourceImageName, firstMapping.targetImageName);
    imageMappings.forEach(mapping => {
        promise = promise.then(() => dockerTag(connection, mapping.sourceImageName, mapping.targetImageName));
    });
    return promise;
}
exports.run = run;

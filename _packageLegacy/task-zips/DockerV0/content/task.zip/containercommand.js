"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
function run(connection) {
    var command = connection.createCommand();
    command.line(tl.getInput("customCommand", true));
    return connection.execCommand(command);
}
exports.run = run;

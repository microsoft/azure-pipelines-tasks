"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path = require("path");
const tl = require("vsts-task-lib/task");
const containerconnection_1 = require("docker-common/containerconnection");
const acrauthenticationtokenprovider_1 = require("docker-common/registryauthenticationprovider/acrauthenticationtokenprovider");
const genericauthenticationtokenprovider_1 = require("docker-common/registryauthenticationprovider/genericauthenticationtokenprovider");
tl.setResourcePath(path.join(__dirname, 'task.json'));
// Change to any specified working directory
tl.cd(tl.getInput("cwd"));
// get the registry server authentication provider 
var registryType = tl.getInput("containerregistrytype", true);
var authenticationProvider;
if (registryType == "Azure Container Registry") {
    authenticationProvider = new acrauthenticationtokenprovider_1.default(tl.getInput("azureSubscriptionEndpoint"), tl.getInput("azureContainerRegistry"));
}
else {
    authenticationProvider = new genericauthenticationtokenprovider_1.default(tl.getInput("dockerRegistryEndpoint"));
}
var registryAuthenticationToken = authenticationProvider.getAuthenticationToken();
// Connect to any specified container host and/or registry 
var connection = new containerconnection_1.default();
connection.open(tl.getInput("dockerHostEndpoint"), registryAuthenticationToken);
// Run the specified action
var action = tl.getInput("action", true);
/* tslint:disable:no-var-requires */
require({
    "Build an image": "./containerbuild",
    "Tag images": "./containertag",
    "Push an image": "./containerpush",
    "Push images": "./containerpush",
    "Run an image": "./containerrun",
    "Run a Docker command": "./containercommand"
}[action]).run(connection)
    .fin(function cleanup() {
    connection.close();
})
    .then(function success() {
    tl.setResult(tl.TaskResult.Succeeded, "");
}, function failure(err) {
    tl.setResult(tl.TaskResult.Failed, err.message);
})
    .done();

"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator.throw(value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments)).next());
    });
};
const path = require('path');
const tl = require('vsts-task-lib/task');
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            var tool = tl.which(tl.getInput('filename', true), true);
            var tr = tl.tool(tool);
            var cwd = tl.getPathInput('workingFolder', true, false);
            tl.mkdirP(cwd);
            tl.cd(cwd);
            tr.line(tl.getInput('arguments', false));
            var failOnStdErr = tl.getBoolInput('failOnStandardError', false);
            var code = yield tr.exec({ failOnStdErr: failOnStdErr });
            tl.setResult(tl.TaskResult.Succeeded, tl.loc('CmdLineReturnCode', tool, code));
        }
        catch (err) {
            tl.error(err.message);
            tl.setResult(tl.TaskResult.Failed, tl.loc('CmdLineFailed', tool, err.message));
        }
    });
}
run();

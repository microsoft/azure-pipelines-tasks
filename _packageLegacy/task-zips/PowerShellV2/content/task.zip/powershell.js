"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const os = require("os");
const tl = require("vsts-task-lib/task");
var uuidV4 = require('uuid/v4');
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            tl.setResourcePath(path.join(__dirname, 'task.json'));
            // Get inputs.
            let input_errorActionPreference = tl.getInput('errorActionPreference', false) || 'Stop';
            switch (input_errorActionPreference.toUpperCase()) {
                case 'STOP':
                case 'CONTINUE':
                case 'SILENTLYCONTINUE':
                    break;
                default:
                    throw new Error(tl.loc('JS_InvalidErrorActionPreference', input_errorActionPreference));
            }
            let input_failOnStderr = tl.getBoolInput('failOnStderr', false);
            let input_ignoreLASTEXITCODE = tl.getBoolInput('ignoreLASTEXITCODE', false);
            let input_workingDirectory = tl.getPathInput('workingDirectory', /*required*/ true, /*check*/ true);
            let input_filePath;
            let input_arguments;
            let input_script;
            let input_targetType = tl.getInput('targetType') || '';
            if (input_targetType.toUpperCase() == 'FILEPATH') {
                input_filePath = tl.getPathInput('filePath', /*required*/ true);
                if (!tl.stats(input_filePath).isFile() || !input_filePath.toUpperCase().match(/\.PS1$/)) {
                    throw new Error(tl.loc('JS_InvalidFilePath', input_filePath));
                }
                input_arguments = tl.getInput('arguments') || '';
            }
            else {
                input_script = tl.getInput('script', false) || '';
            }
            // Generate the script contents.
            console.log(tl.loc('GeneratingScript'));
            let contents = [];
            contents.push(`$ErrorActionPreference = '${input_errorActionPreference}'`);
            if (input_targetType.toUpperCase() == 'FILEPATH') {
                contents.push(`. '${input_filePath.replace("'", "''")}' ${input_arguments}`.trim());
                console.log(tl.loc('JS_FormattedCommand', contents[contents.length - 1]));
            }
            else {
                contents.push(input_script);
            }
            if (!input_ignoreLASTEXITCODE) {
                contents.push(`if (!(Test-Path -LiteralPath variable:\LASTEXITCODE)) {`);
                contents.push(`    Write-Host '##vso[task.debug]$LASTEXITCODE is not set.'`);
                contents.push(`} else {`);
                contents.push(`    Write-Host ('##vso[task.debug]$LASTEXITCODE: {0}' -f $LASTEXITCODE)`);
                contents.push(`    exit $LASTEXITCODE`);
                contents.push(`}`);
            }
            // Write the script to disk.
            tl.assertAgent('2.115.0');
            let tempDirectory = tl.getVariable('agent.tempDirectory');
            tl.checkPath(tempDirectory, `${tempDirectory} (agent.tempDirectory)`);
            let filePath = path.join(tempDirectory, uuidV4() + '.ps1');
            yield fs.writeFile(filePath, '\ufeff' + contents.join(os.EOL), // Prepend the Unicode BOM character.
            { encoding: 'utf8' }); // Since UTF8 encoding is specified, node will
            //                                    // encode the BOM into its UTF8 binary sequence.
            // Run the script.
            //
            // Note, prefer "pwsh" over "powershell". At some point we can remove support for "powershell".
            //
            // Note, use "-Command" instead of "-File" to match the Windows implementation. Refer to
            // comment on Windows implementation for an explanation why "-Command" is preferred.
            let powershell = tl.tool(tl.which('pwsh') || tl.which('powershell') || tl.which('pwsh', true))
                .arg('-NoLogo')
                .arg('-NoProfile')
                .arg('-NonInteractive')
                .arg('-Command')
                .arg(`. '${filePath.replace("'", "''")}'`);
            let options = {
                cwd: input_workingDirectory,
                failOnStdErr: false,
                errStream: process.stdout,
                outStream: process.stdout,
                ignoreReturnCode: true
            };
            // Listen for stderr.
            let stderrFailure = false;
            if (input_failOnStderr) {
                powershell.on('stderr', (data) => {
                    stderrFailure = true;
                });
            }
            // Run bash.
            let exitCode = yield powershell.exec(options);
            // Fail on exit code.
            if (exitCode !== 0) {
                tl.setResult(tl.TaskResult.Failed, tl.loc('JS_ExitCode', exitCode));
            }
            // Fail on stderr.
            if (stderrFailure) {
                tl.setResult(tl.TaskResult.Failed, tl.loc('JS_Stderr'));
            }
        }
        catch (err) {
            tl.setResult(tl.TaskResult.Failed, err.message || 'run() failed');
        }
    });
}
run();

"use strict";
// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const Q = require("q");
const request = require("request");
const job_1 = require("./job");
const util = require("./util");
class JobSearch {
    constructor(queue, taskUrl, identifier) {
        this.searchingFor = [];
        this.foundCauses = []; // all found causes indexed by executableNumber
        this.Initialized = false;
        this.initialSearchBuildNumber = -1; // the intial, most likely build number for child jobs
        this.nextSearchBuildNumber = -1; // the next build number to check
        this.searchDirection = -1; // the direction to search, start by searching backwards
        this.working = false;
        this.workDelay = 0;
        this.queue = queue;
        this.taskUrl = taskUrl;
        this.identifier = identifier;
        this.Initialize().fail((err) => {
            throw err;
        });
    }
    Initialize() {
        const defer = Q.defer();
        const thisSearch = this;
        if (!thisSearch.Initialized) {
            const apiTaskUrl = util.addUrlSegment(thisSearch.taskUrl, '/api/json');
            tl.debug('getting job task URL:' + apiTaskUrl);
            request.get({ url: apiTaskUrl, strictSSL: thisSearch.queue.TaskOptions.strictSSL }, function requestCallBack(err, httpResponse, body) {
                if (!thisSearch.Initialized) {
                    if (err) {
                        if (err.code == 'ECONNRESET') {
                            tl.debug(err);
                            // resolve but do not initialize -- a job will trigger this again
                            defer.resolve(null);
                        }
                        else {
                            defer.reject(err);
                        }
                    }
                    else if (httpResponse.statusCode !== 200) {
                        defer.reject(util.getFullErrorMessage(httpResponse, 'Unable to retrieve job: ' + thisSearch.identifier));
                    }
                    else {
                        const parsedBody = JSON.parse(body);
                        tl.debug(`parsedBody for: ${apiTaskUrl} : ${JSON.stringify(parsedBody)}`);
                        thisSearch.Initialized = true;
                        thisSearch.ParsedTaskBody = parsedBody;
                        // if this is the first time this job is triggered, there will be no lastBuild information, and we assume the
                        // build number is 1 in this case
                        thisSearch.initialSearchBuildNumber = (parsedBody.lastBuild) ? parsedBody.lastBuild.number : 1;
                        thisSearch.nextSearchBuildNumber = thisSearch.initialSearchBuildNumber;
                        thisSearch.searchDirection = -1; // start searching backwards
                        defer.resolve(null);
                    }
                }
                else {
                    defer.resolve(null);
                }
            }).auth(thisSearch.queue.TaskOptions.username, thisSearch.queue.TaskOptions.password, true);
        }
        else {
            defer.resolve(null);
        }
        return defer.promise;
    }
    DoWork() {
        if (this.working) {
            return;
        }
        else {
            this.working = true;
            setTimeout(() => {
                this.locateExecution();
            }, this.workDelay);
        }
    }
    stopWork(delay) {
        this.workDelay = delay;
        this.working = false;
        this.searchingFor = [];
    }
    searchFor(job) {
        if (this.working) {
            return;
        }
        else {
            this.searchingFor.push(job);
        }
    }
    DetermineMainJob(executableNumber, callback) {
        const thisSearch = this;
        if (!thisSearch.foundCauses[executableNumber]) {
            util.fail('No known exeuction number: ' + executableNumber + ' for job: ' + thisSearch.identifier);
        }
        else {
            const causes = thisSearch.foundCauses[executableNumber];
            const causesThatRan = []; // these are all the causes for this executableNumber that are running/ran
            const causesThatMayRun = []; // these are the causes for this executableNumber that could run in the future
            const causesThatWontRun = []; // these are the causes for this executableNumber that will never run
            for (const i in causes) {
                const job = thisSearch.queue.FindJob(causes[i].upstreamUrl, causes[i].upstreamBuild);
                if (job) {
                    if (job.State === job_1.JobState.Streaming ||
                        job.State === job_1.JobState.Finishing ||
                        job.State === job_1.JobState.Downloading ||
                        job.State === job_1.JobState.Queued ||
                        job.State === job_1.JobState.Done) {
                        causesThatRan.push(job);
                    }
                    else if (job.State === job_1.JobState.New || job.State === job_1.JobState.Locating) {
                        causesThatMayRun.push(job);
                    }
                    else if (job.State === job_1.JobState.Joined || job.State === job_1.JobState.Cut) {
                        causesThatWontRun.push(job);
                    }
                    else {
                        util.fail('Illegal state: ' + job);
                    }
                }
            }
            let masterJob = null; // there can be only one
            let potentialMasterJobs = []; // the list of all potential jobs that could be master
            for (const i in causesThatRan) {
                const causeThatRan = causesThatRan[i];
                const child = findChild(causeThatRan);
                if (child != null) {
                    if (child.State === job_1.JobState.Streaming || child.State === job_1.JobState.Finishing || child.State === job_1.JobState.Done) {
                        if (masterJob == null) {
                            masterJob = child;
                        }
                        else {
                            util.fail('Can not have more than one master: ' + child);
                        }
                    }
                    else {
                        potentialMasterJobs.push(child);
                    }
                }
            }
            if (masterJob == null && potentialMasterJobs.length > 0) {
                masterJob = potentialMasterJobs[0]; // simply assign the first one to master
                potentialMasterJobs = potentialMasterJobs.slice(1); // and remove it from here
            }
            let secondaryJobs = [];
            if (masterJob != null) {
                secondaryJobs = potentialMasterJobs;
                for (const i in causesThatWontRun) {
                    const causeThatWontRun = causesThatWontRun[i];
                    const child = findChild(causeThatWontRun);
                    if (child != null) {
                        secondaryJobs.push(child);
                    }
                }
            }
            callback(masterJob, secondaryJobs);
            function findChild(parent) {
                for (const i in parent.Children) {
                    const child = parent.Children[i];
                    if (thisSearch.identifier === child.Identifier) {
                        return child;
                    }
                }
                return null;
            }
        }
    }
    ResolveIfKnown(job) {
        const thisSearch = this;
        if (job.State !== job_1.JobState.New && job.State !== job_1.JobState.Locating) {
            return true; // some other callback found it
        }
        else if (job.Parent == null) {
            job.SetStreaming(job.ExecutableNumber);
            return true;
        }
        else if (job.Parent.State === job_1.JobState.Joined || job.Parent.State === job_1.JobState.Cut) {
            job.Cut(); // the parent was joined or cut, so cut the child
            return true;
        }
        else {
            for (const executableNumber in thisSearch.foundCauses) {
                let resolved = false;
                thisSearch.DetermineMainJob(parseInt(executableNumber), function (mainJob, secondaryJobs) {
                    if (job == mainJob) {
                        job.SetStreaming(parseInt(executableNumber));
                        resolved = true;
                        return;
                    }
                    else {
                        for (const i in secondaryJobs) {
                            if (job == secondaryJobs[i]) {
                                job.SetJoined(mainJob);
                                resolved = true;
                                return;
                            }
                        }
                    }
                });
                if (resolved) {
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * Search for a pipelined job starting with a best guess for the build number, and a direction to search.
     * First the search is done backwards and terminates when either finding the specified job, or the job's
     * timestamp is earlier than the timestamp of the parent job that queued it.  Then the restarts from the
     * intial start point and searches forward until the job is found, or a 404 is reached and no more jobs
     * are queued.  At any point, the search also ends if the job is joined to another job.
     */
    locateExecution() {
        const thisSearch = this;
        tl.debug('locateExecution()');
        // first see if we already know about everything we are searching for
        let foundAll = true;
        for (const i in thisSearch.searchingFor) {
            const job = thisSearch.searchingFor[i];
            const found = thisSearch.ResolveIfKnown(job);
            foundAll = foundAll && found;
        }
        if (foundAll) {
            thisSearch.stopWork(0); // found everything we were looking for
            return;
        }
        else {
            const url = util.addUrlSegment(thisSearch.taskUrl, thisSearch.nextSearchBuildNumber + '/api/json');
            tl.debug('pipeline, locating child execution URL:' + url);
            request.get({ url: url, strictSSL: thisSearch.queue.TaskOptions.strictSSL }, function requestCallback(err, httpResponse, body) {
                tl.debug('locateExecution().requestCallback()');
                if (err) {
                    util.handleConnectionResetError(err); // something went bad
                    thisSearch.stopWork(thisSearch.queue.TaskOptions.pollIntervalMillis);
                    return;
                }
                else if (httpResponse.statusCode === 404) {
                    // try again in the future
                    thisSearch.stopWork(thisSearch.queue.TaskOptions.pollIntervalMillis);
                }
                else if (httpResponse.statusCode !== 200) {
                    util.failReturnCode(httpResponse, 'Job pipeline tracking failed to read downstream project');
                }
                else {
                    const parsedBody = JSON.parse(body);
                    tl.debug(`parsedBody for: ${url} : ${JSON.stringify(parsedBody)}`);
                    /**
                     * This is the list of all reasons for this job execution to be running.
                     * Jenkins may 'join' several pipelined jobs so all will be listed here.
                     * e.g. suppose A -> C and B -> C.  If both A & B scheduled C around the same time before C actually started,
                     * Jenkins will join these requests and only run C once.
                     * So, for all jobs being tracked (within this code), one is consisdered the main job (which will be followed), and
                     * all others are considered joined and will not be tracked further.
                     */
                    const findCauses = function (actions) {
                        for (const i in actions) {
                            if (actions[i].causes) {
                                return actions[i].causes;
                            }
                        }
                        return null;
                    };
                    const causes = findCauses(parsedBody.actions);
                    thisSearch.foundCauses[thisSearch.nextSearchBuildNumber] = causes;
                    thisSearch.DetermineMainJob(thisSearch.nextSearchBuildNumber, function (mainJob, secondaryJobs) {
                        if (mainJob != null) {
                            //found the mainJob, so make sure it's running!
                            mainJob.SetStreaming(thisSearch.nextSearchBuildNumber);
                        }
                    });
                    if (thisSearch.searchDirection < 0) {
                        if (thisSearch.nextSearchBuildNumber <= 1 || parsedBody.timestamp < thisSearch.queue.RootJob.ParsedExecutionResult.timestamp) {
                            //either found the very first job, or one that was triggered before the root job was; need to change search directions
                            thisSearch.searchDirection = 1;
                            thisSearch.nextSearchBuildNumber = thisSearch.initialSearchBuildNumber + 1;
                        }
                        else {
                            thisSearch.nextSearchBuildNumber--;
                        }
                    }
                    else {
                        thisSearch.nextSearchBuildNumber++;
                    }
                    return thisSearch.stopWork(0); // immediately poll again because there might be more jobs
                }
            }).auth(thisSearch.queue.TaskOptions.username, thisSearch.queue.TaskOptions.password, true);
        }
    }
}
exports.JobSearch = JobSearch;

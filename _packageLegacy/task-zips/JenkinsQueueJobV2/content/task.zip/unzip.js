"use strict";
// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const Util = require("./util");
const win = tl.osType().match(/^Win/);
tl.debug('win: ' + win);
// extractors
let xpUnzipLocation = win ? null : tl.which('unzip', false);
let winSevenZipLocation = path.join(__dirname, '7zip/7z.exe');
function unzip(file, destinationFolder) {
    if (win) {
        sevenZipExtract(file, destinationFolder);
    }
    else {
        unzipExtract(file, destinationFolder);
    }
}
exports.unzip = unzip;
function unzipExtract(file, destinationFolder) {
    tl.debug('Extracting file: ' + file);
    if (typeof xpUnzipLocation == 'undefined') {
        xpUnzipLocation = tl.which('unzip', true);
    }
    const unzip = tl.tool(xpUnzipLocation);
    unzip.arg(file);
    unzip.arg('-d');
    unzip.arg(destinationFolder);
    return handleExecResult(unzip.execSync(getOptions()), file);
}
function sevenZipExtract(file, destinationFolder) {
    tl.debug('Extracting file: ' + file);
    const sevenZip = tl.tool(winSevenZipLocation);
    sevenZip.arg('x');
    sevenZip.arg('-o' + destinationFolder);
    sevenZip.arg(file);
    return handleExecResult(sevenZip.execSync(getOptions()), file);
}
function handleExecResult(execResult, file) {
    if (execResult.code != tl.TaskResult.Succeeded) {
        tl.debug('execResult: ' + JSON.stringify(execResult));
        const message = 'Extraction failed for file: ' + file +
            '\ncode: ' + execResult.code +
            '\nstdout: ' + execResult.stdout +
            '\nstderr: ' + execResult.stderr +
            '\nerror: ' + execResult.error;
        throw new UnzipError(message);
    }
}
function getOptions() {
    const execOptions = {
        silent: true,
        outStream: new Util.StringWritable({ decodeStrings: false }),
        errStream: new Util.StringWritable({ decodeStrings: false }),
    };
    return execOptions;
}
class UnzipError extends Error {
}
exports.UnzipError = UnzipError;

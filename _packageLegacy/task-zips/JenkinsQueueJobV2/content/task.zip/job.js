"use strict";
// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const fs = require("fs");
const path = require("path");
const url = require("url");
const request = require("request");
const unzip_1 = require("./unzip");
const Util = require("./util");
// Jobs transition between states as follows:
// ------------------------------------------
// BEGINNING STATE: New
// New →            Locating, Streaming, Joined, Cut
// Locating →       Streaming, Joined, Cut
// Streaming →      Finishing
// Finishing →      Downloading, Queued, Done
// Downloading →    Done
// TERMINAL STATES: Done, Queued, Joined, Cut
var JobState;
(function (JobState) {
    JobState[JobState["New"] = 0] = "New";
    JobState[JobState["Locating"] = 1] = "Locating";
    JobState[JobState["Streaming"] = 2] = "Streaming";
    JobState[JobState["Finishing"] = 3] = "Finishing";
    JobState[JobState["Done"] = 4] = "Done";
    JobState[JobState["Joined"] = 5] = "Joined";
    JobState[JobState["Queued"] = 6] = "Queued";
    JobState[JobState["Cut"] = 7] = "Cut";
    JobState[JobState["Downloading"] = 8] = "Downloading"; // 8 - The job has run and its results are being downloaded (occurs when the TFS Plugin for Jenkins is installed)
})(JobState = exports.JobState || (exports.JobState = {}));
class Job {
    constructor(jobQueue, parent, taskUrl, executableUrl, executableNumber, name) {
        this.Children = []; // any pipelined jobs
        this.State = JobState.New;
        this.jobConsole = '';
        this.jobConsoleOffset = 0;
        this.jobConsoleEnabled = false;
        this.working = true; // initially mark it as working
        this.workDelay = 0;
        this.Parent = parent;
        this.TaskUrl = taskUrl;
        this.ExecutableUrl = executableUrl;
        this.ExecutableNumber = executableNumber;
        this.Name = name;
        if (this.Parent != null) {
            this.Parent.Children.push(this);
        }
        this.queue = jobQueue;
        if (this.TaskUrl.startsWith(this.queue.TaskOptions.serverEndpointUrl)) {
            // simplest case (jobs run on the same server name as the endpoint)
            this.Identifier = this.TaskUrl.substr(this.queue.TaskOptions.serverEndpointUrl.length);
        }
        else {
            // backup check in case job is running on a different server name than the endpoint
            this.Identifier = url.parse(this.TaskUrl).path.substr(1);
            const jobStringIndex = this.Identifier.indexOf('job/');
            if (jobStringIndex > 0) {
                // can fall into here if the jenkins endpoint is not at the server root; e.g. serverUrl/jenkins instead of serverUrl
                this.Identifier = this.Identifier.substr(jobStringIndex);
            }
        }
        this.queue.AddJob(this);
        this.debug('created');
        this.initialize();
    }
    /**
     * All changes to the job state should be routed through here.
     * This defines all and validates all state transitions.
     */
    changeState(newState) {
        const oldState = this.State;
        this.State = newState;
        if (oldState !== newState) {
            this.debug('state changed from: ' + oldState);
            let validStateChange = false;
            if (oldState === JobState.New) {
                validStateChange = (newState === JobState.Locating || newState === JobState.Streaming || newState === JobState.Joined || newState === JobState.Cut);
            }
            else if (oldState === JobState.Locating) {
                validStateChange = (newState === JobState.Streaming || newState === JobState.Joined || newState === JobState.Cut);
            }
            else if (oldState === JobState.Streaming) {
                validStateChange = (newState === JobState.Finishing);
            }
            else if (oldState === JobState.Finishing) {
                validStateChange = (newState === JobState.Downloading || newState === JobState.Queued || newState === JobState.Done);
            }
            else if (oldState === JobState.Downloading) {
                validStateChange = (newState === JobState.Done);
            }
            else if (oldState === JobState.Done || oldState === JobState.Joined || oldState === JobState.Cut) {
                validStateChange = false; // these are terminal states
            }
            if (!validStateChange) {
                Util.fail('Invalid state change from: ' + oldState + ' ' + this);
            }
        }
    }
    DoWork() {
        if (this.working) {
            return;
        }
        else {
            this.working = true;
            setTimeout(() => {
                if (this.State === JobState.New) {
                    this.initialize();
                }
                else if (this.State === JobState.Streaming) {
                    this.streamConsole();
                }
                else if (this.State === JobState.Downloading) {
                    this.downloadResults();
                }
                else if (this.State === JobState.Finishing) {
                    this.finish();
                }
                else {
                    // usually do not get here, but this can happen if another callback caused this job to be joined
                    this.stopWork(this.queue.TaskOptions.pollIntervalMillis, null);
                }
            }, this.workDelay);
        }
    }
    stopWork(delay, jobState) {
        if (jobState && jobState !== this.State) {
            this.changeState(jobState);
            if (!this.IsActive()) {
                this.queue.FlushJobConsolesSafely();
            }
        }
        this.workDelay = delay;
        this.working = false;
    }
    IsActive() {
        return this.State === JobState.New ||
            this.State === JobState.Locating ||
            this.State === JobState.Streaming ||
            this.State === JobState.Downloading ||
            this.State === JobState.Finishing;
    }
    getBlockMessage(message) {
        const divider = '******************************************************************************';
        const blockMessage = divider + '\n' + message + ' \n' + divider;
        return blockMessage;
    }
    SetStreaming(executableNumber) {
        // If we aren't waiting for the job to finish then we should end it now
        if (!this.queue.TaskOptions.captureConsole) {
            this.changeState(JobState.Streaming);
            this.changeState(JobState.Finishing);
            return;
        }
        if (this.State === JobState.New || this.State === JobState.Locating) {
            this.ExecutableNumber = executableNumber;
            this.ExecutableUrl = Util.addUrlSegment(this.TaskUrl, this.ExecutableNumber.toString());
            this.changeState(JobState.Streaming);
            // log the jobs starting block
            this.consoleLog(this.getBlockMessage('Jenkins job started: ' + this.Name + '\n' + this.ExecutableUrl));
            // log any pending jobs
            if (this.queue.FindActiveConsoleJob() == null) {
                console.log('Jenkins job pending: ' + this.ExecutableUrl);
            }
        }
        else if (this.State === JobState.Joined || this.State === JobState.Cut) {
            Util.fail('Can not be set to streaming: ' + this);
        }
        this.joinOthersToMe();
    }
    joinOthersToMe() {
        //join all other siblings to this same job (as long as it's not root)
        const thisJob = this;
        if (thisJob.Parent != null) {
            thisJob.Search.DetermineMainJob(thisJob.ExecutableNumber, function (mainJob, secondaryJobs) {
                if (mainJob != thisJob) {
                    Util.fail('Illegal call in joinOthersToMe(), job:' + thisJob);
                }
                for (const i in secondaryJobs) {
                    const secondaryJob = secondaryJobs[i];
                    if (secondaryJob.State !== JobState.Cut) {
                        secondaryJob.SetJoined(thisJob);
                    }
                }
            });
        }
    }
    SetJoined(joinedJob) {
        tl.debug(this + '.setJoined(' + joinedJob + ')');
        this.Joined = joinedJob;
        this.changeState(JobState.Joined);
        if (joinedJob.State === JobState.Joined || joinedJob.State === JobState.Cut) {
            Util.fail('Invalid join: ' + this);
        }
        // recursively cut all children
        for (const i in this.Children) {
            this.Children[i].Cut();
        }
    }
    Cut() {
        this.changeState(JobState.Cut);
        for (const i in this.Children) {
            this.Children[i].Cut();
        }
    }
    setParsedExecutionResult(parsedExecutionResult) {
        this.ParsedExecutionResult = parsedExecutionResult;
        //log the job's closing block
        this.consoleLog(this.getBlockMessage('Jenkins job finished: ' + this.Name + '\n' + this.ExecutableUrl));
    }
    GetTaskResult() {
        if (this.State === JobState.Queued) {
            return tl.TaskResult.Succeeded;
        }
        else if (this.State === JobState.Done) {
            const resultCode = this.ParsedExecutionResult.result.toUpperCase();
            if (resultCode == 'SUCCESS' || resultCode == 'UNSTABLE') {
                return tl.TaskResult.Succeeded;
            }
            else {
                return tl.TaskResult.Failed;
            }
        }
        return tl.TaskResult.Failed;
    }
    GetResultString() {
        if (this.State === JobState.Queued) {
            return 'Queued';
        }
        else if (this.State === JobState.Done) {
            const resultCode = this.ParsedExecutionResult.result.toUpperCase();
            // codes map to fields in http://hudson-ci.org/javadoc/hudson/model/Result.html
            if (resultCode == 'SUCCESS') {
                return tl.loc('succeeded');
            }
            else if (resultCode == 'UNSTABLE') {
                return tl.loc('unstable');
            }
            else if (resultCode == 'FAILURE') {
                return tl.loc('failed');
            }
            else if (resultCode == 'NOT_BUILT') {
                return tl.loc('notbuilt');
            }
            else if (resultCode == 'ABORTED') {
                return tl.loc('aborted');
            }
            else {
                return resultCode;
            }
        }
        else {
            return tl.loc('unknown');
        }
    }
    initialize() {
        const thisJob = this;
        thisJob.Search.Initialize().then(() => {
            if (thisJob.Search.Initialized) {
                if (thisJob.queue.TaskOptions.capturePipeline) {
                    const downstreamProjects = thisJob.Search.ParsedTaskBody.downstreamProjects || [];
                    downstreamProjects.forEach((project) => {
                        new Job(thisJob.queue, thisJob, project.url, null, -1, project.name); // will add a new child to the tree
                    });
                }
                thisJob.Search.ResolveIfKnown(thisJob); // could change state
                const newState = (thisJob.State === JobState.New) ? JobState.Locating : thisJob.State; // another call back could also change state
                const nextWorkDelay = (newState === JobState.Locating) ? thisJob.queue.TaskOptions.pollIntervalMillis : thisJob.workDelay;
                thisJob.stopWork(nextWorkDelay, newState);
            }
            else {
                //search not initialized, so try again
                thisJob.stopWork(thisJob.queue.TaskOptions.pollIntervalMillis, thisJob.State);
            }
        }).fail((err) => {
            throw err;
        });
    }
    /**
     * Checks the success of the job
     *
     * JobState = Finishing, transition to Downloading, Done, or Queued possible
     */
    finish() {
        const thisJob = this;
        tl.debug('finish()');
        if (!thisJob.queue.TaskOptions.captureConsole) {
            thisJob.stopWork(0, JobState.Queued);
        }
        else {
            const resultUrl = Util.addUrlSegment(thisJob.ExecutableUrl, 'api/json');
            thisJob.debug('Tracking completion status of job: ' + resultUrl);
            request.get({ url: resultUrl, strictSSL: thisJob.queue.TaskOptions.strictSSL }, function requestCallback(err, httpResponse, body) {
                tl.debug('finish().requestCallback()');
                if (err) {
                    Util.handleConnectionResetError(err); // something went bad
                    thisJob.stopWork(thisJob.queue.TaskOptions.pollIntervalMillis, thisJob.State);
                    return;
                }
                else if (httpResponse.statusCode != 200) {
                    Util.failReturnCode(httpResponse, 'Job progress tracking failed to read job result');
                }
                else {
                    const parsedBody = JSON.parse(body);
                    thisJob.debug(`parsedBody for: ${resultUrl} : ${JSON.stringify(parsedBody)}`);
                    if (parsedBody.result) {
                        thisJob.setParsedExecutionResult(parsedBody);
                        if (thisJob.queue.TaskOptions.teamBuildPluginAvailable) {
                            thisJob.stopWork(0, JobState.Downloading);
                        }
                        else {
                            thisJob.stopWork(0, JobState.Done);
                        }
                    }
                    else {
                        // result not updated yet -- keep trying
                        thisJob.stopWork(thisJob.queue.TaskOptions.pollIntervalMillis, thisJob.State);
                    }
                }
            }).auth(thisJob.queue.TaskOptions.username, thisJob.queue.TaskOptions.password, true);
        }
    }
    downloadResults() {
        const thisJob = this;
        const downloadUrl = Util.addUrlSegment(thisJob.ExecutableUrl, 'team-results/zip');
        tl.debug('downloadResults(), url:' + downloadUrl);
        const downloadRequest = request.get({ url: downloadUrl, strictSSL: thisJob.queue.TaskOptions.strictSSL })
            .auth(thisJob.queue.TaskOptions.username, thisJob.queue.TaskOptions.password, true)
            .on('error', (err) => {
            Util.handleConnectionResetError(err); // something went bad
            thisJob.stopWork(thisJob.queue.TaskOptions.pollIntervalMillis, thisJob.State);
        })
            .on('response', (response) => {
            tl.debug('downloadResults(), url:' + downloadUrl + ' , response.statusCode: ' + response.statusCode + ', response.statusMessage: ' + response.statusMessage);
            if (response.statusCode == 404) {
                tl.debug('no results to download');
                thisJob.stopWork(0, JobState.Done);
            }
            else if (response.statusCode == 200) {
                const destinationFolder = path.join(thisJob.queue.TaskOptions.saveResultsTo, thisJob.Name + '/');
                const fileName = path.join(destinationFolder, 'team-results.zip');
                try {
                    // Create the destination folder if it doesn't exist
                    if (!tl.exist(destinationFolder)) {
                        tl.debug('creating results destination folder: ' + destinationFolder);
                        tl.mkdirP(destinationFolder);
                    }
                    tl.debug('downloading results file: ' + fileName);
                    const file = fs.createWriteStream(fileName);
                    downloadRequest.pipe(file)
                        .on('error', (err) => { throw err; })
                        .on('finish', function fileFinished() {
                        tl.debug('successfully downloaded results to: ' + fileName);
                        try {
                            unzip_1.unzip(fileName, destinationFolder);
                            thisJob.stopWork(0, JobState.Done);
                        }
                        catch (e) {
                            tl.warning('unable to extract results file');
                            tl.debug(e.message);
                            tl._writeError(e);
                            thisJob.stopWork(0, JobState.Done);
                        }
                    });
                }
                catch (err) {
                    // don't fail the job if the results can not be downloaded successfully
                    tl.warning('unable to download results to file: ' + fileName + ' for Jenkins Job: ' + thisJob.ExecutableUrl);
                    tl.warning(err.message);
                    tl._writeError(err);
                    thisJob.stopWork(0, JobState.Done);
                }
            }
            else {
                try {
                    const warningMessage = (response.statusCode >= 500) ?
                        'A Jenkins error occurred while retrieving results. Results could not be downloaded.' :
                        'Jenkins results could not be downloaded.'; // Any other error
                    tl.warning(warningMessage);
                    const warningStream = new Util.StringWritable({ decodeStrings: false });
                    downloadRequest.pipe(warningStream)
                        .on('error', (err) => { throw err; })
                        .on('finish', function finished() {
                        tl.warning(warningStream);
                        thisJob.stopWork(0, JobState.Done);
                    });
                }
                catch (err) {
                    // don't fail the job if the results can not be downloaded successfully
                    tl.warning(err.message);
                    tl._writeError(err);
                    thisJob.stopWork(0, JobState.Done);
                }
            }
        });
    }
    /**
     * Streams the Jenkins console.
     *
     * JobState = Streaming, transition to Finishing possible.
     */
    streamConsole() {
        const thisJob = this;
        const fullUrl = Util.addUrlSegment(thisJob.ExecutableUrl, '/logText/progressiveText/?start=' + thisJob.jobConsoleOffset);
        thisJob.debug('Tracking progress of job URL: ' + fullUrl);
        request.get({ url: fullUrl, strictSSL: thisJob.queue.TaskOptions.strictSSL }, function requestCallback(err, httpResponse, body) {
            tl.debug('streamConsole().requestCallback()');
            if (err) {
                Util.handleConnectionResetError(err); // something went bad
                thisJob.stopWork(thisJob.queue.TaskOptions.pollIntervalMillis, thisJob.State);
                return;
            }
            else if (httpResponse.statusCode === 404) {
                // got here too fast, stream not yet available, try again in the future
                thisJob.stopWork(thisJob.queue.TaskOptions.pollIntervalMillis, thisJob.State);
            }
            else if (httpResponse.statusCode === 401) {
                Util.failReturnCode(httpResponse, 'Job progress tracking failed to read job progress');
                thisJob.queue.TaskOptions.captureConsole = false;
                thisJob.queue.TaskOptions.capturePipeline = false;
                thisJob.queue.TaskOptions.shouldFail = true;
                thisJob.queue.TaskOptions.failureMsg = 'Job progress tracking failed to read job progress';
                thisJob.stopWork(0, JobState.Finishing);
            }
            else if (httpResponse.statusCode !== 200) {
                Util.failReturnCode(httpResponse, 'Job progress tracking failed to read job progress');
                thisJob.stopWork(thisJob.queue.TaskOptions.pollIntervalMillis, thisJob.State);
            }
            else {
                thisJob.consoleLog(body); // redirect Jenkins console to task console
                const xMoreData = httpResponse.headers['x-more-data'];
                if (xMoreData && xMoreData == 'true') {
                    const offset = httpResponse.headers['x-text-size'];
                    thisJob.jobConsoleOffset = Number.parseInt(offset);
                    thisJob.stopWork(thisJob.queue.TaskOptions.pollIntervalMillis, thisJob.State);
                }
                else {
                    thisJob.stopWork(0, JobState.Finishing);
                }
            }
        }).auth(thisJob.queue.TaskOptions.username, thisJob.queue.TaskOptions.password, true)
            .on('error', (err) => {
            throw err;
        });
    }
    EnableConsole() {
        const thisJob = this;
        if (thisJob.queue.TaskOptions.captureConsole) {
            if (!this.jobConsoleEnabled) {
                if (this.jobConsole != '') {
                    console.log(this.jobConsole);
                }
                this.jobConsoleEnabled = true;
            }
        }
    }
    IsConsoleEnabled() {
        return this.jobConsoleEnabled;
    }
    consoleLog(message) {
        if (this.jobConsoleEnabled) {
            //only log it if the console is enabled.
            console.log(message);
        }
        this.jobConsole += message;
    }
    debug(message) {
        const fullMessage = this.toString() + ' debug: ' + message;
        tl.debug(fullMessage);
    }
    toString() {
        let fullMessage = '(' + this.State + ':' + this.Name + ':' + this.ExecutableNumber;
        if (this.Parent != null) {
            fullMessage += ', p:' + this.Parent;
        }
        if (this.Joined != null) {
            fullMessage += ', j:' + this.Joined;
        }
        fullMessage += ')';
        return fullMessage;
    }
}
exports.Job = Job;

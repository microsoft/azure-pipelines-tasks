"use strict";
// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const fs = require("fs");
const path = require("path");
const shell = require("shelljs");
const job_1 = require("./job");
const jobsearch_1 = require("./jobsearch");
const util = require("./util");
class JobQueue {
    constructor(taskOptions) {
        this.allJobs = [];
        this.searches = [];
        this.intervalMillis = 100;
        this.TaskOptions = taskOptions;
    }
    Start() {
        tl.debug('jobQueue.start()');
        this.intervalId = setInterval(() => {
            try {
                const nextSearches = this.findNextJobSearches();
                for (const i in nextSearches) {
                    nextSearches[i].DoWork();
                }
                const running = this.findRunningJobs();
                for (const i in running) {
                    running[i].DoWork();
                }
                if (this.hasFailedJobs()) {
                    this.stop(false);
                }
                else if (this.getActiveJobs().length === 0) {
                    this.stop(true);
                }
                else {
                    this.FlushJobConsolesSafely();
                }
            }
            catch (err) {
                tl.debug(err.message);
                tl.setResult(tl.TaskResult.Failed, err.message);
                this.stop(false);
            }
        }, this.intervalMillis);
    }
    stop(complete) {
        tl.debug('jobQueue.stop()');
        clearInterval(this.intervalId);
        this.FlushJobConsolesSafely();
        this.writeFinalMarkdown(complete);
    }
    hasFailedJobs() {
        for (const i in this.allJobs) {
            const job = this.allJobs[i];
            if (job.State === job_1.JobState.Done) {
                if (job.GetTaskResult() === tl.TaskResult.Failed) {
                    return true;
                }
            }
        }
        return false;
    }
    findRunningJobs() {
        const running = [];
        for (const i in this.allJobs) {
            const job = this.allJobs[i];
            if (job.State === job_1.JobState.Streaming || job.State === job_1.JobState.Downloading || job.State === job_1.JobState.Finishing) {
                running.push(job);
            }
        }
        return running;
    }
    findNextJobSearches() {
        const nextSearches = [];
        for (const i in this.allJobs) {
            const job = this.allJobs[i];
            // the parent must be finished (or null for root) in order for a job to possibly be started
            if (job.State === job_1.JobState.Locating && (job.Parent === null || job.Parent.State === job_1.JobState.Done)) {
                // group these together so only search is done per job.identifier
                if (!nextSearches[job.Identifier]) {
                    nextSearches[job.Identifier] = this.searches[job.Identifier];
                }
                nextSearches[job.Identifier].searchFor(job);
            }
        }
        return nextSearches;
    }
    getActiveJobs() {
        const active = [];
        for (const i in this.allJobs) {
            const job = this.allJobs[i];
            if (job.IsActive()) {
                active.push(job);
            }
        }
        return active;
    }
    AddJob(job) {
        if (this.allJobs.length === 0) {
            this.RootJob = job;
        }
        this.allJobs.push(job);
        if (this.searches[job.Identifier] == null) {
            this.searches[job.Identifier] = new jobsearch_1.JobSearch(this, job.TaskUrl, job.Identifier);
        }
        job.Search = this.searches[job.Identifier];
    }
    FlushJobConsolesSafely() {
        if (this.FindActiveConsoleJob() == null) {
            const streamingJobs = [];
            let addedToConsole = false;
            for (const i in this.allJobs) {
                const job = this.allJobs[i];
                if (job.State === job_1.JobState.Done) {
                    if (!job.IsConsoleEnabled()) {
                        job.EnableConsole(); // flush the finished ones
                        addedToConsole = true;
                    }
                }
                else if (job.State === job_1.JobState.Streaming || job.State === job_1.JobState.Finishing) {
                    streamingJobs.push(job); // these are the ones that could be running
                }
            }
            // finally, if there is only one remaining, it is safe to enable its console
            if (streamingJobs.length === 1) {
                streamingJobs[0].EnableConsole();
            }
            else if (addedToConsole) {
                for (const i in streamingJobs) {
                    const job = streamingJobs[i];
                    console.log('Jenkins job pending: ' + job.ExecutableUrl);
                }
            }
        }
    }
    /**
     * If there is a job currently writing to the console, find it.
     */
    FindActiveConsoleJob() {
        const activeJobs = this.getActiveJobs();
        for (const i in activeJobs) {
            const job = activeJobs[i];
            if (job.IsConsoleEnabled()) {
                return job;
            }
        }
        return null;
    }
    FindJob(identifier, executableNumber) {
        for (const i in this.allJobs) {
            const job = this.allJobs[i];
            if (job.Identifier === identifier && job.ExecutableNumber === executableNumber) {
                return job;
            }
        }
        return null;
    }
    writeFinalMarkdown(complete) {
        const colorize = (s) => {
            // 'Success' is green, everything else is red
            let color = 'red';
            if (s === tl.loc('succeeded')) {
                color = 'green';
            }
            return `<font color='${color}'>${s}</font>`;
        };
        function walkHierarchy(job, indent, padding) {
            let jobContents = indent;
            // if this job was joined to another follow that one instead
            job = findWorkingJob(job);
            if (job.ExecutableNumber === -1) {
                jobContents += indent + job.Name + ' ' + colorize(job.GetResultString()) + '<br />';
            }
            else {
                const url = job.ExecutableUrl && job.ExecutableUrl.replace('"', '%22');
                jobContents += indent + '[' + job.Name + ' #' + job.ExecutableNumber + '](' + url + ') ' + colorize(job.GetResultString()) + '<br />';
            }
            let childContents = '';
            for (const i in job.Children) {
                const child = job.Children[i];
                childContents += walkHierarchy(child, indent + tab, padding + paddingTab);
            }
            return jobContents + childContents + indent;
        }
        function findWorkingJob(job) {
            if (job.State !== job_1.JobState.Joined) {
                return job;
            }
            else {
                return findWorkingJob(job.Joined);
            }
        }
        function createPipelineReport(job, taskOptions, report) {
            const authority = util.getUrlAuthority(job.ExecutableUrl);
            const getStageUrl = (authority, stage) => {
                let result = '';
                if (stage && stage['_links']
                    && stage['_links']['self']
                    && stage['_links']['self']['href']) {
                    result = stage['_links']['self']['href'];
                    //remove the api link
                    result = result.replace('/wfapi/describe', '');
                }
                return `${authority}${result}`;
            };
            const convertStatus = (s) => {
                let status = s.toLowerCase();
                if (status === 'success') {
                    status = tl.loc('succeeded');
                }
                return status;
            };
            // Top level pipeline job status
            let jobContent = '';
            let jobName = taskOptions.jobName;
            if (taskOptions.isMultibranchPipelineJob) {
                jobName = `${jobName}/${taskOptions.multibranchPipelineBranch}`;
            }
            jobContent += '[' + jobName + ' #' + job.ExecutableNumber + '](' + job.ExecutableUrl + ') ' + colorize(job.GetResultString());
            if (job.GetResultString() !== tl.loc('succeeded')) {
                jobContent += ` ([${tl.loc('console')}](${job.ExecutableUrl}/console))`;
            }
            jobContent += '<br />';
            // For each stage, write its status
            let stageContents = '';
            for (let stage of report['stages']) {
                const stageUrl = getStageUrl(authority, stage);
                stageContents += '[' + stage['name'] + '](' + stageUrl + ') ' + colorize(convertStatus(stage.status)) + '<br />';
            }
            if (stageContents) {
                jobContent += '<ul style="padding-left: 4">\n';
                jobContent += stageContents;
                jobContent += '</ul>';
            }
            return jobContent;
        }
        function generatePipelineReport(job, taskOptions, callback) {
            util.getPipelineReport(job, taskOptions)
                .then((body) => {
                if (body) {
                    const parsedBody = JSON.parse(body);
                    callback(createPipelineReport(job, taskOptions, parsedBody));
                }
                else {
                    callback(tl.loc('FailedToGenerateSummary'));
                }
            });
        }
        function generateMarkdownContent(job, taskOptions, callback) {
            util.isPipelineJob(job, taskOptions)
                .then((isPipeline) => {
                if (isPipeline) {
                    generatePipelineReport(job, taskOptions, callback);
                }
                else {
                    callback(walkHierarchy(job, '', 0));
                }
            });
        }
        tl.debug('writing summary markdown');
        const thisQueue = this;
        const tempDir = shell.tempdir();
        const linkMarkdownFile = path.join(tempDir, 'JenkinsJob_' + this.RootJob.Name + '_' + this.RootJob.ExecutableNumber + '.md');
        tl.debug('markdown location: ' + linkMarkdownFile);
        const tab = '  ';
        const paddingTab = 4;
        generateMarkdownContent(this.RootJob, thisQueue.TaskOptions, (markdownContents) => {
            fs.writeFile(linkMarkdownFile, markdownContents, function callback(err) {
                tl.debug('writeFinalMarkdown().writeFile().callback()');
                if (err) {
                    //don't fail the build -- there just won't be a link
                    console.log('Error creating link to Jenkins job: ' + err);
                }
                else {
                    console.log('##vso[task.addattachment type=Distributedtask.Core.Summary;name=Jenkins Results;]' + linkMarkdownFile);
                }
                let message = null;
                if (complete) {
                    if (thisQueue.TaskOptions.capturePipeline) {
                        message = tl.loc('JenkinsPipelineComplete');
                    }
                    else if (thisQueue.TaskOptions.captureConsole) {
                        message = tl.loc('JenkinsJobComplete');
                    }
                    else {
                        message = tl.loc('JenkinsJobQueued');
                    }
                    if (thisQueue.TaskOptions.shouldFail) {
                        tl.setResult(tl.TaskResult.Failed, thisQueue.TaskOptions.failureMsg);
                    }
                    else {
                        tl.setResult(tl.TaskResult.Succeeded, message);
                    }
                }
                else {
                    if (thisQueue.TaskOptions.capturePipeline) {
                        message = tl.loc('JenkinsPipelineFailed');
                    }
                    else if (thisQueue.TaskOptions.captureConsole) {
                        message = tl.loc('JenkinsJobFailed');
                    }
                    else {
                        message = tl.loc('JenkinsJobFailedtoQueue');
                    }
                    tl.setResult(tl.TaskResult.Failed, message);
                }
            });
        });
    }
}
exports.JobQueue = JobQueue;

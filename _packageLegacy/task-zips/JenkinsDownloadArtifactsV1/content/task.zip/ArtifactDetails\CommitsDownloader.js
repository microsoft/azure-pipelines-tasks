"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Q = require("q");
const os = require("os");
const path = require("path");
const tl = require("vsts-task-lib/task");
const ArtifactDetailsDownloaderBase_1 = require("./ArtifactDetailsDownloaderBase");
const JenkinsRestClient_1 = require("./JenkinsRestClient");
var handlebars = require('handlebars');
const CommitTemplateBase = `{{#with changeSet as |changes|}}
  {{#each changes.items as |commit|}}
  {
    "Id": "{{commit.commitId}}",
    "Message": "{{commit.msg}}",
    "Author": {
      "displayName": "{{commit.author.fullName}}"
    },
    {{#caseIgnoreEqual changes.kind 'git'}}
    {{#with (lookupAction ../../actions 'remoteUrls') as |action|}}
    {{#if action.remoteUrls}}
    "DisplayUri": "{{#first action.remoteUrls}}{{/first}}/commit/{{commit.commitId}}",
    {{/if}}
    {{/with}}
    {{/caseIgnoreEqual}}
    "Timestamp": "{{commit.date}}"
  },
  {{/each}}
  {{/with}}`;
const CommitsTemplate = `[
  {{#each (lookup . buildParameter)}}
  {{> commit this}}
  {{/each}}
]`;
const CommitTemplate = `[
    ${CommitTemplateBase}
]`;
const GetCommitMessagesTemplate = `{{pluck . 'Message'}}`;
class CommitsDownloader extends ArtifactDetailsDownloaderBase_1.ArtifactDetailsDownloaderBase {
    constructor() {
        super();
        handlebars.registerPartial('commit', CommitTemplateBase);
        this.jenkinsClient = new JenkinsRestClient_1.JenkinsRestClient();
    }
    static GetCommitMessagesFromCommits(commits) {
        console.log(tl.loc("GetCommitMessages"));
        let template = handlebars.compile(GetCommitMessagesTemplate);
        try {
            var result = template(JSON.parse(commits));
        }
        catch (error) {
            console.log(tl.loc("GetCommitMessagesFailed", error, commits));
            throw error;
        }
        tl.debug(`Commit messages: ${result}`);
        return result.split(',');
    }
    DownloadFromSingleBuildAndSave(jenkinsJobDetails) {
        let defer = Q.defer();
        console.log(tl.loc("GettingCommitsFromSingleBuild", jenkinsJobDetails.buildId));
        this.GetCommitsFromSingleBuild(jenkinsJobDetails).then((commits) => {
            this.UploadCommits(commits).then(() => {
                defer.resolve(commits);
            }, (error) => {
                defer.reject(error);
            });
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    DownloadFromBuildRangeAndSave(jenkinsJobDetails, startIndex, endIndex) {
        let defer = Q.defer();
        this.GetCommits(jenkinsJobDetails, startIndex, endIndex).then((commits) => {
            this.UploadCommits(commits).then(() => {
                defer.resolve(commits);
            }, (error) => {
                defer.reject(error);
            });
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    GetCommitsFromSingleBuild(jenkinsJobDetails) {
        let defer = Q.defer();
        const commitsUrl = `${jenkinsJobDetails.multiBranchPipelineUrlInfix}/${jenkinsJobDetails.buildId}/api/json?tree=number,result,actions[remoteUrls],changeSet[kind,items[commitId,date,msg,author[fullName]]]`;
        this.jenkinsClient.DownloadJsonContent(commitsUrl, CommitTemplate, null).then((commitsResult) => {
            tl.debug(`Downloaded commits: ${commitsResult}`);
            var commits = this.TransformCommits(commitsResult);
            defer.resolve(commits);
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    GetCommits(jenkinsJobDetails, startIndex, endIndex) {
        let defer = Q.defer();
        const buildParameter = (startIndex >= 100 || endIndex >= 100) ? "allBuilds" : "builds"; // jenkins by default will return only 100 top builds. Have to use "allBuilds" if we are dealing with build which are older than 100 builds
        const commitsUrl = `${jenkinsJobDetails.multiBranchPipelineUrlInfix}/api/json?tree=${buildParameter}[number,result,actions[remoteUrls],changeSet[kind,items[commitId,date,msg,author[fullName]]]]{${endIndex},${startIndex}}`;
        tl.debug(`Downloading commits from startIndex ${startIndex} and endIndex ${endIndex}`);
        this.jenkinsClient.DownloadJsonContent(commitsUrl, CommitsTemplate, { 'buildParameter': buildParameter }).then((commitsResult) => {
            tl.debug(`Downloaded commits: ${commitsResult}`);
            var commits = this.TransformCommits(commitsResult);
            defer.resolve(commits);
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    UploadCommits(commits) {
        let defer = Q.defer();
        let commitsFilePath = path.join(os.tmpdir(), this.GetCommitsFileName());
        console.log(tl.loc("WritingCommitsTo", commitsFilePath));
        this.WriteContentToFileAndUploadAsAttachment(commits, commitsFilePath).then(() => {
            console.log(tl.loc("SuccessfullyUploadedCommitsAttachment"));
            defer.resolve(null);
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    GetCommitsFileName() {
        let fileName = "commits.json";
        let commitfileName = tl.getInput("artifactDetailsFileNameSuffix", false);
        if (commitfileName) {
            fileName = `commits_${commitfileName}`;
        }
        return fileName;
    }
    TransformCommits(commits) {
        if (!!commits) {
            // remove the extra comma at the end of the commit item
            let index = commits.lastIndexOf(",");
            if (index > -1) {
                commits = commits.substring(0, index) + commits.substring(index + 1);
            }
            try {
                var commitMessages = JSON.parse(commits);
                commitMessages.forEach((commit) => {
                    tl.debug('Normalizing url' + commit.DisplayUri);
                    commit.DisplayUri = this.ConvertGitProtocolUrlToHttpProtocol(commit.DisplayUri);
                });
                return JSON.stringify(commitMessages);
            }
            catch (error) {
                console.log(tl.loc("CannotParseCommits", commits, error));
                throw error;
            }
        }
        return '';
    }
    ;
    ConvertGitProtocolUrlToHttpProtocol(commitUrl) {
        var result = '';
        if (!!commitUrl) {
            if (commitUrl.startsWith('git@')) {
                tl.debug('repo url is a git protocol url');
                if (commitUrl.startsWith('git@gitlab.com')) {
                    result = commitUrl.replace('git@gitlab.com:', 'https://gitlab.com/').replace('.git/', '/');
                }
                else if (commitUrl.startsWith('git@github.com')) {
                    result = commitUrl.replace('git@github.com:', 'https://github.com/').replace('.git/', '/');
                }
            }
            else if (commitUrl.startsWith('http')) {
                // if its http return the url as is.
                result = commitUrl;
            }
        }
        tl.debug(`Translated url ${commitUrl} to ${result}`);
        return result;
    }
}
exports.CommitsDownloader = CommitsDownloader;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Q = require("q");
const tl = require("vsts-task-lib/task");
const JenkinsRestClient_1 = require("./JenkinsRestClient");
const CommitsDownloader_1 = require("./CommitsDownloader");
const WorkItemsDownloader_1 = require("./WorkItemsDownloader");
var handlebars = require('handlebars');
class ArtifactDetailsDownloader {
    DownloadCommitsAndWorkItems(jenkinsJobDetails) {
        let defer = Q.defer();
        console.log(tl.loc("DownloadingCommitsAndWorkItems"));
        let jenkinsBuild = tl.getInput('jenkinsBuild', true);
        let startBuildIdStr = tl.getInput("startJenkinsBuildNumber", false) || "";
        let startBuildId = this.GetBuildIdFromVersion(startBuildIdStr, jenkinsJobDetails.isMultiBranchPipeline);
        let endBuildId = jenkinsJobDetails.buildId;
        let commitsDownloader = new CommitsDownloader_1.CommitsDownloader();
        // validate endBuildId which is a mandatory parameter
        if (isNaN(endBuildId) || !endBuildId) {
            defer.reject(new Error(tl.loc("InvalidJenkinsBuildNumber")));
            return defer.promise;
        }
        // validate the start build only if its required.
        if (startBuildIdStr.trim().length > 0 && isNaN(startBuildId) && jenkinsBuild !== 'LastSuccessfulBuild') {
            defer.reject(new Error(tl.loc("InvalidJenkinsStartBuildNumber", startBuildIdStr)));
            return defer.promise;
        }
        // if you have a valid start and end buildId and then switch to LastSuccessfulBuild
        //  previous start build still exists though its not visible. Hence check the jenkinsBuild input 
        //  and if its set to LastSuccessfulBuild consider startBuild is not mentioned.
        if (!startBuildId || isNaN(startBuildId) || jenkinsBuild === 'LastSuccessfulBuild') {
            console.log(tl.loc("JenkinsDownloadingChangeFromCurrentBuild", jenkinsJobDetails.buildId));
            commitsDownloader.DownloadFromSingleBuildAndSave(jenkinsJobDetails).then((commits) => {
                let commitMessages = CommitsDownloader_1.CommitsDownloader.GetCommitMessagesFromCommits(commits);
                let workItemsDownloader = new WorkItemsDownloader_1.WorkItemsDownloader(commitMessages);
                workItemsDownloader.DownloadFromSingleBuildAndSave(jenkinsJobDetails).then(() => {
                    defer.resolve(null);
                }, (error) => {
                    defer.reject(error);
                });
            }, (error) => {
                defer.reject(error);
            });
        }
        else {
            if (jenkinsJobDetails.isMultiBranchPipeline) {
                // if multibranch validate if the branch names are same.
                let startBuildBranchName = this.GetBranchNameFromVersion(startBuildIdStr, jenkinsJobDetails.isMultiBranchPipeline);
                if (startBuildBranchName.toLowerCase() !== jenkinsJobDetails.multiBranchPipelineName.toLowerCase()) {
                    defer.reject(new Error(tl.loc("InvalidMultiBranchPipelineName", startBuildBranchName, jenkinsJobDetails.multiBranchPipelineName)));
                    return defer.promise;
                }
            }
            if (startBuildId < endBuildId) {
                console.log(tl.loc("DownloadingJenkinsChangeBetween", startBuildId, endBuildId));
            }
            else if (startBuildId > endBuildId) {
                console.log(tl.loc("DownloadingJenkinsChangeBetween", endBuildId, startBuildId));
                tl.debug(`Start build ${startBuildId} is greater than end build ${endBuildId}`);
                // swap the Build IDs to fetch the roll back commits
                let temp = startBuildId;
                startBuildId = endBuildId;
                endBuildId = temp;
            }
            else if (startBuildId == endBuildId) {
                console.log(tl.loc("JenkinsNoCommitsToFetch"));
                defer.resolve(null);
                return defer.promise;
            }
            // #1. Since we have two builds, we need to figure the build index
            this.GetBuildIdIndex(jenkinsJobDetails, startBuildId, endBuildId).then((buildIndex) => {
                let startIndex = buildIndex['startIndex'];
                let endIndex = buildIndex['endIndex'];
                //#2. Download the commits using range and save
                commitsDownloader.DownloadFromBuildRangeAndSave(jenkinsJobDetails, startIndex, endIndex).then((commits) => {
                    //#3. download workitems
                    let commitMessages = CommitsDownloader_1.CommitsDownloader.GetCommitMessagesFromCommits(commits);
                    let workItemsDownloader = new WorkItemsDownloader_1.WorkItemsDownloader(commitMessages);
                    workItemsDownloader.DownloadFromBuildRangeAndSave(jenkinsJobDetails, startIndex, endIndex).then(() => {
                        defer.resolve(null);
                    }, (error) => {
                        defer.reject(error);
                    });
                }, (error) => {
                    defer.reject(error);
                });
            }, (error) => {
                defer.reject(error);
            });
        }
        return defer.promise;
    }
    GetBuildIdFromVersion(version, isMultiBranchPipeline) {
        let buildId = NaN;
        if (!!version) {
            if (!isMultiBranchPipeline) {
                buildId = parseInt(version);
            }
            else {
                buildId = parseInt(version.substring(version.lastIndexOf(JenkinsRestClient_1.JenkinsRestClient.JenkinsBranchPathSeparator) + 1));
            }
        }
        return buildId;
    }
    GetBranchNameFromVersion(version, isMultibranchPipeline) {
        let branchName = version;
        if (!!version && isMultibranchPipeline) {
            branchName = version.substring(0, version.lastIndexOf(JenkinsRestClient_1.JenkinsRestClient.JenkinsBranchPathSeparator));
        }
        return branchName;
    }
    GetBuildIdIndex(jenkinsJobDetails, startBuildId, endBuildId) {
        let defer = Q.defer();
        let buildUrl = `${jenkinsJobDetails.multiBranchPipelineUrlInfix}/api/json?tree=allBuilds[number]`;
        let startIndex = -1;
        let endIndex = -1;
        console.log(tl.loc("FindBuildIndex"));
        handlebars.registerHelper('BuildIndex', function (buildId, index, options) {
            if (buildId == startBuildId) {
                startIndex = index;
            }
            else if (buildId == endBuildId) {
                endIndex = index;
            }
            return options.fn(this);
        });
        let source = '{{#each allBuilds}}{{#BuildIndex this.number @index}}{{/BuildIndex}}{{/each}}';
        let downloadHelper = new JenkinsRestClient_1.JenkinsRestClient();
        downloadHelper.DownloadJsonContent(buildUrl, source, null).then(() => {
            console.log(tl.loc("FoundBuildIndex", startIndex, endIndex));
            if (startIndex === -1 || endIndex === -1) {
                tl.debug(`cannot find valid startIndex ${startIndex} or endIndex ${endIndex}`);
                defer.reject(tl.loc("CannotFindBuilds"));
            }
            else {
                defer.resolve({ startIndex: startIndex, endIndex: endIndex });
            }
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
}
exports.ArtifactDetailsDownloader = ArtifactDetailsDownloader;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Q = require("q");
const tl = require("vsts-task-lib/task");
const handlers = require("artifact-engine/Providers/typed-rest-client/Handlers");
const HttpClient_1 = require("artifact-engine/Providers/typed-rest-client/HttpClient");
var handlebars = require('handlebars');
class JenkinsJobDetails {
    constructor(jobName, buildId, jenkinsJobType, multibranchPipelineName) {
        if (isNaN(buildId)) {
            throw new Error(tl.loc("InvalidBuildId", buildId));
        }
        if (!jobName || jobName.trim().length < 1) {
            throw new Error(tl.loc("InvalidJobName", jobName));
        }
        this.jobName = jobName;
        this.jobUrlInfix = JenkinsJobDetails.GetJobUrlInfix(this.jobName);
        this.buildId = buildId;
        this.jobType = jenkinsJobType;
        this.multiBranchPipelineName = multibranchPipelineName;
        this.isMultiBranchPipeline = this.jobType.toLowerCase() === JenkinsJobTypes.MultiBranchPipeline.toLowerCase();
        this.multiBranchPipelineUrlInfix = this.isMultiBranchPipeline ? `/job/${this.multiBranchPipelineName}` : "";
    }
    static GetJobUrlInfix(jenkinsJobName) {
        jenkinsJobName = jenkinsJobName.replace(/\/$/, '').replace(/^\//, '');
        let result = "";
        jenkinsJobName.split('/').forEach((token) => {
            if (!!token && token.length > 0) {
                result = `${result}/job/${token}`;
            }
        });
        return result;
    }
}
exports.JenkinsJobDetails = JenkinsJobDetails;
class JenkinsJobTypes {
}
JenkinsJobTypes.Folder = "com.cloudbees.hudson.plugins.folder.Folder";
JenkinsJobTypes.MultiBranchPipeline = "org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject";
exports.JenkinsJobTypes = JenkinsJobTypes;
class JenkinsRestClient {
    constructor() {
        this.RegisterCustomerHandleBars();
    }
    RegisterCustomerHandleBars() {
        handlebars.registerHelper('caseIgnoreEqual', function (lhs, rhs, options) {
            if (!lhs && !rhs) {
                return options.fn(this);
            }
            if ((lhs && !rhs) || (!lhs && rhs)) {
                return options.inverse(this);
            }
            if (lhs.toUpperCase() != rhs.toUpperCase()) {
                return options.inverse(this);
            }
            else {
                return options.fn(this);
            }
        });
        handlebars.registerHelper('lookupAction', function (list, key, options) {
            if (!!list) {
                for (let i = 0, len = list.length; i < len; i++) {
                    if (list[i][key]) {
                        return list[i];
                    }
                }
            }
            return null;
        });
        handlebars.registerHelper('first', function (array) {
            if (!!array) {
                return array[0];
            }
            return '';
        });
        handlebars.registerHelper('pluck', function (array, key) {
            if (!!array) {
                var result = [];
                for (var i = 0; i < array.length; i++) {
                    var value = array[i][key];
                    if (!!value) {
                        result.push(value);
                    }
                }
                return result;
            }
            return [];
        });
        handlebars.registerHelper('containsInArray', function (array, value, options) {
            if (!!array) {
                for (let i = 0, len = array.length; i < len; i++) {
                    tl.debug(`checking ${array[i]} ${value}`);
                    if (!!array[i] && array[i].indexOf(value) > -1) {
                        return options.fn(this);
                    }
                }
            }
            return options.inverse(this);
        });
        handlebars.registerHelper('chopTrailingSlash', function (value, options) {
            var result = value;
            if (!!value && value.substr(-1) === '/') {
                result = value.substr(0, value.length - 1);
            }
            return result;
        });
        handlebars.registerHelper('selectMaxOf', function (array, property) {
            function GetJsonProperty(jsonObject, property) {
                let properties = property.split('.'); // if property has dot in it, we want to access the nested property of the objects.
                let element = jsonObject;
                let found = false;
                for (let propertyIndex = 0; propertyIndex < properties.length; propertyIndex++) {
                    if (!!element) {
                        element = element[properties[propertyIndex]];
                        if (!!element && propertyIndex + 1 === properties.length) {
                            found = true;
                        }
                    }
                }
                return found == true ? element : null;
            }
            let result = null;
            if (!!array && !!property) {
                let maxValue = parseInt(GetJsonProperty(array[0], property));
                if (!isNaN(maxValue)) {
                    result = array[0]; //consider first as result until we figure out if there are any other max available
                    for (let i = 1; i < array.length; i++) {
                        let value = parseInt(GetJsonProperty(array[i], property));
                        tl.debug(`#selectMaxOf comparing values ${maxValue} and ${value}`);
                        if (!isNaN(value) && value > maxValue) {
                            result = array[i];
                            maxValue = value;
                        }
                    }
                    tl.debug(`Found maxvalue ${maxValue}`);
                }
            }
            return result;
        });
    }
    GetClient() {
        tl.debug(`Creating http client`);
        const endpoint = tl.getInput("serverEndpoint", true);
        const strictSSL = ('true' !== tl.getEndpointDataParameter(endpoint, 'acceptUntrustedCerts', true));
        let requestOptions = {
            ignoreSslError: !strictSSL
        };
        let proxyUrl = tl.getVariable("agent.proxyurl");
        if (!!proxyUrl) {
            requestOptions.proxy = tl.getHttpProxyConfiguration();
        }
        const username = tl.getEndpointAuthorizationParameter(endpoint, 'username', false);
        const password = tl.getEndpointAuthorizationParameter(endpoint, 'password', false);
        var handler = new handlers.BasicCredentialHandler(username, password);
        return new HttpClient_1.HttpClient("JenkinsRestClient", [handler], requestOptions);
    }
    DownloadJsonContent(urlPath, handlebarSource, additionalHandlebarContext) {
        let defer = Q.defer();
        const endpoint = tl.getInput("serverEndpoint", true);
        const endpointUrl = tl.getEndpointUrl(endpoint, false);
        const jobName = tl.getInput("jobName", true);
        const strictSSL = ('true' !== tl.getEndpointDataParameter(endpoint, 'acceptUntrustedCerts', true));
        const jobUrlInfix = JenkinsJobDetails.GetJobUrlInfix(jobName);
        let requestUrl = `${endpointUrl}${jobUrlInfix}/${urlPath}`;
        console.log(tl.loc("DownloadingContentFromJenkinsServer", requestUrl, strictSSL));
        let httpClient = this.GetClient();
        httpClient.get(requestUrl).then((response) => {
            response.readBody().then((body) => {
                if (!!body && response.message.statusCode === 200) {
                    tl.debug(`Content received from server ${body}`);
                    let jsonResult;
                    try {
                        jsonResult = JSON.parse(body);
                    }
                    catch (error) {
                        jsonResult = "";
                        defer.reject(error);
                    }
                    if (jsonResult != "") {
                        if (!handlebarSource) {
                            defer.resolve(jsonResult);
                        }
                        else {
                            try {
                                tl.debug(`Applying the handlebar source ${handlebarSource} on the result`);
                                let template = handlebars.compile(handlebarSource);
                                if (additionalHandlebarContext) {
                                    for (let key in additionalHandlebarContext) {
                                        tl.debug(`Adding additional context {${key} --> ${additionalHandlebarContext[key]}} to the original context`);
                                        jsonResult[key] = additionalHandlebarContext[key];
                                    }
                                    ;
                                }
                                var result = template(jsonResult);
                                // back slash is an illegal character in json.
                                // when we downloaded the api output has \\, but the previous parse method will strip of a single \. Adding it back.
                                result = result.replace(/\\/g, "\\\\");
                                defer.resolve(result);
                            }
                            catch (err) {
                                defer.reject(new Error(tl.loc("JenkinsArtifactDetailsParsingError", err)));
                            }
                        }
                    }
                }
                else {
                    if (response.message.statusCode) {
                        console.log(tl.loc('ServerCallErrorCode', response.message.statusCode));
                    }
                    if (body) {
                        tl.debug(body);
                    }
                    defer.reject(new Error(tl.loc('ServerCallFailed')));
                }
            }, (err) => {
                defer.reject(err);
            });
        }, (err) => {
            defer.reject(err);
        });
        return defer.promise;
    }
    GetJobType() {
        let defer = Q.defer();
        const jobTypeApiUrlSuffix = "/api/json";
        const handlerbarSource = "{{_class}}";
        tl.debug("Trying to get job type");
        this.DownloadJsonContent(jobTypeApiUrlSuffix, handlerbarSource, null).then((result) => {
            console.log(tl.loc("FoundJobType", result));
            defer.resolve(result.trim());
        }, (error) => {
            console.log(tl.loc("CannotFindJobType"));
            defer.resolve("");
        });
        return defer.promise;
    }
    GetJobDetails() {
        const jenkinsBuild = tl.getInput('jenkinsBuild', true);
        if (jenkinsBuild === 'LastSuccessfulBuild') {
            return this.GetLastSuccessfulBuild();
        }
        else {
            let defer = Q.defer();
            const jobName = tl.getInput('jobName', true);
            let jobType = "";
            let buildIdStr = tl.getInput('jenkinsBuildNumber');
            let branchName;
            this.GetJobType().then((result) => {
                jobType = result;
            }).fin(() => {
                let isMultibranchPipeline = jobType.toLowerCase() === JenkinsJobTypes.MultiBranchPipeline.toLowerCase();
                tl.debug(`Found Jenkins Job type ${jobType} and isMultibranchPipeline ${isMultibranchPipeline}`);
                // if its multibranch pipeline extract the branch name and buildId from the buildNumber input
                if (isMultibranchPipeline && !!buildIdStr && buildIdStr.indexOf(JenkinsRestClient.JenkinsBranchPathSeparator) != -1) {
                    tl.debug(`Extracting branchName and buildId from selected version`);
                    let position = buildIdStr.indexOf(JenkinsRestClient.JenkinsBranchPathSeparator);
                    branchName = buildIdStr.substring(0, position);
                    buildIdStr = buildIdStr.substring(position + 1);
                }
                const buildId = parseInt(buildIdStr);
                if (!this.IsValidBuildId(buildId, branchName, isMultibranchPipeline)) {
                    defer.reject(new Error(tl.loc("InvalidBuildId", buildIdStr)));
                }
                else {
                    let jobDetail = new JenkinsJobDetails(jobName, buildId, jobType, branchName);
                    tl.debug(`Found Jenkins job details jobName:${jobDetail.jobName}, jobType:${jobDetail.jobType}, buildId:${jobDetail.buildId}, IsMultiBranchPipeline:${jobDetail.isMultiBranchPipeline}, MultiBranchPipelineName:${jobDetail.multiBranchPipelineName}`);
                    defer.resolve(jobDetail);
                }
            });
            return defer.promise;
        }
    }
    GetLastSuccessfulBuild() {
        let defer = Q.defer();
        let jobType = "";
        const jobName = tl.getInput('jobName', true);
        this.GetJobType().then((result) => {
            jobType = result;
        }).fin(() => {
            let jenkinsTreeParameter = "lastSuccessfulBuild[id,displayname]";
            let handlerbarSource = "{{lastSuccessfulBuild.id}}";
            const isMultibranchPipeline = jobType.toLowerCase() === JenkinsJobTypes.MultiBranchPipeline.toLowerCase();
            tl.debug(`Found Jenkins Job type ${jobType} and isMultibranchPipeline ${isMultibranchPipeline}`);
            if (isMultibranchPipeline) {
                jenkinsTreeParameter = "jobs[name,lastSuccessfulBuild[id,displayName,timestamp]]";
                handlerbarSource = "{{#with (selectMaxOf jobs 'lastSuccessfulBuild.timestamp') as |job|}}{ \"branchName\": \"{{job.name}}\", \"buildId\": \"{{job.lastSuccessfulBuild.id}}\" }{{/with}}";
            }
            const lastSuccessfulUrlSuffix = `/api/json?tree=${jenkinsTreeParameter}`;
            this.DownloadJsonContent(lastSuccessfulUrlSuffix, handlerbarSource, null).then((result) => {
                let buildId;
                let branchName;
                let succeeded = false;
                if (isMultibranchPipeline) {
                    try {
                        let jsonResult = JSON.parse(result);
                        branchName = jsonResult["branchName"];
                        buildId = parseInt(jsonResult["buildId"]);
                        tl.debug(`Found branchName: ${branchName}, buildId: ${buildId}`);
                    }
                    catch (error) {
                        defer.reject(new Error(tl.loc("CouldNotGetLastSuccessfulBuildNumber", error)));
                    }
                }
                else {
                    buildId = parseInt(result);
                }
                if (!this.IsValidBuildId(buildId, branchName, isMultibranchPipeline)) {
                    defer.reject(new Error(tl.loc("InvalidBuildId", buildId)));
                }
                else {
                    let jobDetail = new JenkinsJobDetails(jobName, buildId, jobType, branchName);
                    tl.debug(`Found Jenkins job details jobName:${jobDetail.jobName}, jobType:${jobDetail.jobType}, buildId:${jobDetail.buildId}, IsMultiBranchPipeline:${jobDetail.isMultiBranchPipeline}, MultiBranchPipelineName:${jobDetail.multiBranchPipelineName}`);
                    defer.resolve(jobDetail);
                }
            }, (error) => {
                defer.reject(new Error(tl.loc("CouldNotGetLastSuccessfulBuildNumber", error)));
            });
        });
        console.log(tl.loc('GetArtifactsFromLastSuccessfulBuild', jobName));
        return defer.promise;
    }
    HasAssociatedArtifacts(artifactQueryUrl) {
        let defer = Q.defer();
        this.GetClient().get(artifactQueryUrl).then((response) => {
            response.readBody().then((body) => {
                if (!!body && response.message.statusCode === 200) {
                    let jsonResult;
                    try {
                        jsonResult = JSON.parse(body);
                        if (!!jsonResult.artifacts && jsonResult.artifacts.length > 0) {
                            defer.resolve(true);
                        }
                        else {
                            defer.resolve(false);
                        }
                    }
                    catch (error) {
                        defer.reject(error);
                    }
                }
                else {
                    if (response.message.statusCode) {
                        console.log(tl.loc('ServerCallErrorCode', response.message.statusCode));
                    }
                    if (body) {
                        tl.debug(body);
                    }
                    defer.reject(new Error(tl.loc('ServerCallFailed')));
                }
            });
        });
        return defer.promise;
    }
    IsValidBuildId(buildId, multiBranchName, isMultiBranch) {
        if (isNaN(buildId)) {
            return false;
        }
        if (isMultiBranch) {
            // if its multibranch, valid branchname should exist
            if (!multiBranchName || multiBranchName.trim().length === 0) {
                return false;
            }
        }
        else {
            // if its not multibranch there should not be a branch name
            if (!!multiBranchName && multiBranchName.trim().length > 0) {
                return false;
            }
        }
        return true;
    }
}
JenkinsRestClient.JenkinsBranchPathSeparator = "/";
exports.JenkinsRestClient = JenkinsRestClient;

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Q = require("q");
const fs = require("fs");
const path = require("path");
const tl = require("vsts-task-lib/task");
class ArtifactDetailsDownloaderBase {
    WriteContentToFileAndUploadAsAttachment(content, filePath) {
        let defer = Q.defer();
        // ensure it has .json extension
        if (path.extname(filePath) !== ".json") {
            filePath = `${filePath}.json`;
        }
        fs.writeFile(filePath, content, (err) => {
            if (err) {
                console.log(tl.loc("CouldNotWriteToFile", err));
                defer.reject(err);
                return;
            }
            console.log(tl.loc("UploadingAttachment", filePath));
            console.log(`##vso[task.uploadfile]${filePath}`);
            defer.resolve(null);
        });
        return defer.promise;
    }
}
exports.ArtifactDetailsDownloaderBase = ArtifactDetailsDownloaderBase;

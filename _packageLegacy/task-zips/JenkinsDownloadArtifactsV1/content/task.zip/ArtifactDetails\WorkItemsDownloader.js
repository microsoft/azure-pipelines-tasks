"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Q = require("q");
const os = require("os");
const path = require("path");
const tl = require("vsts-task-lib/task");
const ArtifactDetailsDownloaderBase_1 = require("./ArtifactDetailsDownloaderBase");
const JenkinsRestClient_1 = require("./JenkinsRestClient");
var handlebars = require('handlebars');
const WorkItemTemplateBase = `{{#with (lookupAction actions 'issues') as |action|}}
{{#each action.issues}}
{{#containsInArray @root.commits key}}
  {
    "id": "{{key}}",
    "title": "{{summary}}",
    {{#if assignee}}
    "assignee": "{{assignee}}",
    {{/if}}
    {{#if status}}
    "status": "{{status}}",
    {{/if}}
    {{#if type}}
    "type": "{{type}}",
    {{/if}}
    "url": "{{#chopTrailingSlash ../serverURL}}{{/chopTrailingSlash}}/browse/{{key}}"
  },
{{/containsInArray}}
{{/each}}
{{/with}}`;
const WorkItemTemplate = `[
    ${WorkItemTemplateBase}
]`;
const WorkItemsTemplate = `[
  {{#each (lookup . buildParameter)}}
  {{> workitem this}}
  {{/each}}
]`;
class WorkItemsDownloader extends ArtifactDetailsDownloaderBase_1.ArtifactDetailsDownloaderBase {
    constructor(commitMessages) {
        super();
        this.commitMessages = commitMessages;
        handlebars.registerPartial('workitem', WorkItemTemplateBase);
        this.jenkinsClient = new JenkinsRestClient_1.JenkinsRestClient();
    }
    DownloadFromSingleBuildAndSave(jenkinsJobDetails) {
        let defer = Q.defer();
        console.log(tl.loc("DownloadingWorkItemsFromSingleBuild", jenkinsJobDetails.buildId));
        this.GetWorkItemsFromSingleBuild(jenkinsJobDetails, this.commitMessages).then((workItems) => {
            this.UploadWorkItems(workItems).then(() => {
                defer.resolve(null);
            }, (error) => {
                defer.reject(error);
            });
        });
        return defer.promise;
    }
    DownloadFromBuildRangeAndSave(jenkinsJobDetails, startIndex, endIndex) {
        let defer = Q.defer();
        this.GetWorkItems(jenkinsJobDetails, startIndex, endIndex, this.commitMessages).then((workItems) => {
            this.UploadWorkItems(workItems).then(() => {
                defer.resolve(workItems);
            }, (error) => {
                defer.reject(error);
            });
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    GetWorkItemsFromSingleBuild(jenkinsJobDetails, commitMessages) {
        let defer = Q.defer();
        const workItemsUrl = `${jenkinsJobDetails.multiBranchPipelineUrlInfix}/${jenkinsJobDetails.buildId}/api/json?tree=actions[issues[*],serverURL]`;
        this.jenkinsClient.DownloadJsonContent(workItemsUrl, WorkItemTemplate, { 'commits': commitMessages }).then((workItemsResult) => {
            tl.debug(`Downloaded workItems: ${workItemsResult}`);
            defer.resolve(workItemsResult);
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    GetWorkItems(jenkinsJobDetails, startIndex, endIndex, commitMessages) {
        let defer = Q.defer();
        const buildParameter = (startIndex >= 100 || endIndex >= 100) ? "allBuilds" : "builds"; // jenkins by default will return only 100 top builds. Have to use "allBuilds" if we are dealing with build which are older than 100 builds
        const workItemsUrl = `${jenkinsJobDetails.multiBranchPipelineUrlInfix}/api/json?tree=${buildParameter}[actions[issues[*],serverURL]]{${endIndex},${startIndex}}`;
        tl.debug(`Downloading workItems from startIndex ${startIndex} and endIndex ${endIndex}`);
        this.jenkinsClient.DownloadJsonContent(workItemsUrl, WorkItemsTemplate, { 'buildParameter': buildParameter, 'commits': commitMessages }).then((workItemsResult) => {
            tl.debug(`Downloaded workItems: ${workItemsResult}`);
            defer.resolve(workItemsResult);
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    UploadWorkItems(workItems) {
        let defer = Q.defer();
        let workItemsFilePath = path.join(os.tmpdir(), this.GetWorkItemsFileName());
        console.log(tl.loc("WritingWorkItemsTo", workItemsFilePath));
        this.WriteContentToFileAndUploadAsAttachment(workItems, workItemsFilePath).then(() => {
            console.log(tl.loc("SuccessfullyUploadedWorkItemsAttachment"));
            defer.resolve(null);
        }, (error) => {
            defer.reject(error);
        });
        return defer.promise;
    }
    GetWorkItemsFileName() {
        let fileName = "workitems.json";
        let workItemsfileName = tl.getInput("artifactDetailsFileNameSuffix", false);
        if (workItemsfileName) {
            fileName = `workitems_${workItemsfileName}`;
        }
        return fileName;
    }
}
exports.WorkItemsDownloader = WorkItemsDownloader;

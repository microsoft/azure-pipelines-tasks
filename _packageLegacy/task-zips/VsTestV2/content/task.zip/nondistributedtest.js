"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("vsts-task-lib/task");
const path = require("path");
const utils = require("./helpers");
const outStream = require("./outputstream");
const os = require("os");
const uuid = require("uuid");
const fs = require("fs");
const process = require("process");
class NonDistributedTest {
    constructor(inputDataContract) {
        this.sourceFilter = tl.getDelimitedInput('testAssemblyVer2', '\n', true);
        this.inputDataContract = inputDataContract;
    }
    runNonDistributedTest() {
        this.invokeDtaExecutionHost();
    }
    invokeDtaExecutionHost() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                console.log(tl.loc('runTestsLocally', 'vstest.console.exe'));
                console.log('========================================================');
                this.testAssemblyFiles = this.getTestAssemblies();
                if (!this.testAssemblyFiles || this.testAssemblyFiles.length === 0) {
                    console.log('##vso[task.logissue type=warning;code=002004;]');
                    tl.warning(tl.loc('NoMatchingTestAssemblies', this.sourceFilter));
                    return;
                }
                const exitCode = yield this.startDtaExecutionHost();
                tl.debug('DtaExecutionHost finished');
                if (exitCode !== 0) {
                    tl.debug('Modules/DTAExecutionHost.exe process exited with code ' + exitCode);
                    tl.setResult(tl.TaskResult.Failed, tl.loc('VstestFailed'));
                    return;
                }
                else {
                    tl.debug(`Modules/DTAExecutionHost.exe exited with code ${exitCode}`);
                    tl.setResult(tl.TaskResult.Succeeded, 'Task succeeded');
                }
            }
            catch (err) {
                tl.error(err);
                tl.setResult(tl.TaskResult.Failed, tl.loc('VstestFailedReturnCode'));
            }
        });
    }
    startDtaExecutionHost() {
        return __awaiter(this, void 0, void 0, function* () {
            let dtaExecutionHostTool = tl.tool(path.join(this.inputDataContract.VsTestConsolePath, 'vstest.console.exe'));
            this.inputDataContract.TestSelectionSettings.TestSourcesFile = this.createTestSourcesFile();
            tl.cd(this.inputDataContract.TfsSpecificSettings.WorkFolder);
            let envVars = process.env;
            dtaExecutionHostTool = tl.tool(path.join(__dirname, 'Modules/DTAExecutionHost.exe'));
            // Invoke DtaExecutionHost with the input json file
            const inputFilePath = utils.Helper.GenerateTempFile('input_' + uuid.v1() + '.json');
            utils.Helper.removeEmptyNodes(this.inputDataContract);
            try {
                fs.writeFileSync(inputFilePath, JSON.stringify(this.inputDataContract));
            }
            catch (e) {
                tl.setResult(tl.TaskResult.Failed, `Failed to write to the input json file ${inputFilePath} with error ${e}`);
            }
            if (utils.Helper.isDebugEnabled()) {
                utils.Helper.uploadFile(inputFilePath);
            }
            dtaExecutionHostTool.arg(['--inputFile', inputFilePath]);
            utils.Helper.addToProcessEnvVars(envVars, 'DTA.AccessToken', tl.getEndpointAuthorization('SystemVssConnection', true).parameters.AccessToken);
            // hydra: See which of these are required in C# layer. Do we want this for telemetry??
            // utils.Helper.addToProcessEnvVars(envVars, 'DTA.AgentVersion', tl.getVariable('AGENT.VERSION'));
            if (this.inputDataContract.UsingXCopyTestPlatformPackage) {
                envVars = utils.Helper.setProfilerVariables(envVars);
            }
            const execOptions = {
                env: envVars,
                failOnStdErr: false,
                // In effect this will not be called as failOnStdErr is false
                // Keeping this code in case we want to change failOnStdErr
                errStream: new outStream.StringErrorWritable({ decodeStrings: false })
            };
            // The error codes return below are not the same as tl.TaskResult which follows a different convention.
            // Here we are returning the code as returned to us by vstest.console in case of complete run
            // In case of a failure 1 indicates error to our calling function
            try {
                return yield dtaExecutionHostTool.exec(execOptions);
            }
            catch (err) {
                tl.warning(tl.loc('VstestFailed'));
                tl.error(err);
                return 1;
            }
        });
    }
    getTestAssemblies() {
        tl.debug('Searching for test assemblies in: ' + this.inputDataContract.TestSelectionSettings.SearchFolder);
        return tl.findMatch(this.inputDataContract.TestSelectionSettings.SearchFolder, this.sourceFilter);
    }
    createTestSourcesFile() {
        try {
            console.log(tl.loc('UserProvidedSourceFilter', this.sourceFilter.toString()));
            const sources = tl.findMatch(this.inputDataContract.TestSelectionSettings.SearchFolder, this.sourceFilter);
            tl.debug('tl match count :' + sources.length);
            const filesMatching = [];
            sources.forEach(function (match) {
                if (!fs.lstatSync(match).isDirectory()) {
                    filesMatching.push(match);
                }
            });
            tl.debug('Files matching count :' + filesMatching.length);
            if (filesMatching.length === 0) {
                throw new Error(tl.loc('noTestSourcesFound', this.sourceFilter.toString()));
            }
            const tempFile = utils.Helper.GenerateTempFile('testSources_' + uuid.v1() + '.src');
            fs.writeFileSync(tempFile, filesMatching.join(os.EOL));
            tl.debug('Test Sources file :' + tempFile);
            return tempFile;
        }
        catch (error) {
            throw new Error(tl.loc('testSourcesFilteringFailed', error));
        }
    }
}
exports.NonDistributedTest = NonDistributedTest;

/**
 * Extracts a ZIP archive while preventing entries and symbolic links from escaping the destination.
 *
 * @param file Path to the ZIP archive.
 * @param destination Absolute path to the extraction directory.
 * @returns The canonical path to the extraction directory.
 */
export declare function extractZipSecure(file: string, destination: string): Promise<string>;
